class_name LuaTable
extends RefCounted
## Lua tablosu: dizi (1..n) ve sözlük kısmı tek Dictionary'de. Sayı anahtarlar tam sayıya normalize edilir.

var h: Dictionary = {}
var meta: LuaTable = null  # metatable (__index, __newindex, __call desteklenir)
var _n := 0


static func norm(k: Variant) -> Variant:
	if k is float:
		var f: float = k
		if f == floorf(f) and absf(f) < 1.0e15:
			return int(f)
	return k


func get_v(k: Variant) -> Variant:
	return h.get(norm(k))


func set_v(k: Variant, v: Variant) -> void:
	var nk: Variant = norm(k)
	if v == null:
		h.erase(nk)
	else:
		h[nk] = v


func length() -> int:
	while h.has(_n + 1):
		_n += 1
	while _n > 0 and not h.has(_n):
		_n -= 1
	return _n


func append(v: Variant) -> void:
	set_v(length() + 1, v)


func keys() -> Array:
	return h.keys()
