class_name TouchLayer
extends Control
## Tam ekran jest katmanı. UI düğmelerinin ARKASINA eklenir; düğmelerin yemediği
## dokunuşlar buraya düşer.
##   tapped(pos)                 : kısa dokunuş
##   drag_one(relative)          : tek parmak sürükleme (Play kamerası bunu kullanır)
##   drag_began(start, fresh)    : tek parmak sürükleme başladı (start = ilk dokunma noktası,
##                                 fresh = iki parmaktan kalan artık parmak DEĞİL)
##   drag_moved(pos, relative)   : sürükleme sürüyor
##   drag_ended()                : sürükleme bitti
##   drag_two(pan, zoom)         : iki parmak (pan = ortalama kayma, zoom = yakınlaştırma çarpanı)

signal tapped(pos: Vector2)
signal drag_one(relative: Vector2)
signal drag_began(start: Vector2, fresh: bool)
signal drag_moved(pos: Vector2, relative: Vector2)
signal drag_ended
signal drag_two(pan: Vector2, zoom: float)

const TAP_MAX_MOVE := 14.0
const TAP_MAX_MSEC := 350

var _pts: Dictionary = {}  # parmak index -> konum
var _start_pos := Vector2.ZERO
var _start_msec := 0
var _moved := 0.0
var _multi := false
var _dragging := false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func _end_drag() -> void:
	if _dragging:
		_dragging = false
		drag_ended.emit()


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed:
			_pts[t.index] = t.position
			if _pts.size() == 1:
				_start_pos = t.position
				_start_msec = Time.get_ticks_msec()
				_moved = 0.0
				_multi = false
			else:
				_multi = true
				_end_drag()
		else:
			if not _pts.has(t.index):
				return
			var was_single := _pts.size() == 1
			_pts.erase(t.index)
			_end_drag()
			var quick := (Time.get_ticks_msec() - _start_msec) < TAP_MAX_MSEC
			if was_single and not _multi and not t.canceled and _moved < TAP_MAX_MOVE and quick:
				tapped.emit(_start_pos)
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event
		if not _pts.has(d.index):
			return
		var old: Dictionary = _pts.duplicate()
		_pts[d.index] = d.position
		if _pts.size() == 1:
			_moved += d.relative.length()
			if _moved >= TAP_MAX_MOVE:
				if not _dragging:
					_dragging = true
					drag_began.emit(_start_pos, not _multi)
				drag_one.emit(d.relative)
				drag_moved.emit(d.position, d.relative)
		elif _pts.size() == 2:
			var ids := _pts.keys()
			var old_dist: float = (old[ids[0]] as Vector2).distance_to(old[ids[1]] as Vector2)
			var new_dist: float = (_pts[ids[0]] as Vector2).distance_to(_pts[ids[1]] as Vector2)
			var zoom := 1.0
			if new_dist > 8.0 and old_dist > 8.0:
				zoom = old_dist / new_dist
			drag_two.emit(d.relative * 0.5, zoom)
