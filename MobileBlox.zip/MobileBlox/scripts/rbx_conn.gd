class_name RbxConn
extends RefCounted
## Roblox bağlantısı (RBXScriptConnection): conn:Disconnect()

var connected := true
