class_name RbxBridge
extends RefCounted
## Roblox API köprüsü: game / workspace / Instance / Players / Humanoid / Touched / TweenService / Vector3 / Color3 / CFrame...
## Luau kodunun gördüğü "Roblox dünyası" ile Godot sahnesi (parçalar, oyuncu) arasındaki çeviri katmanı.

const SIGNAL_NAMES := [
	"Changed", "ChildAdded", "ChildRemoved", "DescendantAdded", "AncestryChanged", "Completed", "Died",
	"HealthChanged", "CharacterAdded", "PlayerAdded", "PlayerRemoving", "Touched", "TouchEnded", "Event",
]
const NOOP_CLASSES := [
	"Sound", "Fire", "Smoke", "Sparkles", "PointLight", "SpotLight", "SurfaceLight", "ParticleEmitter",
	"Decal", "Texture", "BillboardGui", "ScreenGui", "TextLabel", "TextButton", "Frame", "BodyVelocity",
	"BodyPosition", "Highlight", "Beam", "Trail", "ClickDetector", "ProximityPrompt", "Animation",
]
const BRICK := {
	"bright red": Color(0.77, 0.16, 0.11), "really red": Color(1.0, 0.0, 0.0), "bright blue": Color(0.05, 0.41, 0.67),
	"really blue": Color(0.0, 0.0, 1.0), "bright yellow": Color(0.98, 0.80, 0.18), "new yeller": Color(1.0, 1.0, 0.0),
	"bright green": Color(0.29, 0.59, 0.29), "lime green": Color(0.0, 1.0, 0.0), "black": Color(0.1, 0.1, 0.1),
	"really black": Color(0.0, 0.0, 0.0), "white": Color(0.95, 0.95, 0.95), "medium stone grey": Color(0.64, 0.64, 0.64),
	"dark stone grey": Color(0.39, 0.37, 0.38), "bright orange": Color(0.85, 0.52, 0.26), "hot pink": Color(1.0, 0.4, 0.7),
	"royal purple": Color(0.38, 0.0, 0.62), "cyan": Color(0.0, 1.0, 1.0), "brown": Color(0.49, 0.36, 0.28),
}

var interp  # LuauInterp (tür yazılmaz: döngüsel bağımlılığı önlemek için)
var player: Player
var parts_root: Node
var game_inst: RbxInst
var workspace: RbxInst
var players_svc: RbxInst
var lp: RbxInst
var character: RbxInst
var humanoid: RbxInst
var root_part: RbxInst
var services: Dictionary = {}
var node_map: Dictionary = {}
var heartbeat := RbxSignal.new()
var stepped := RbxSignal.new()
var _dummy_th := LuaThread.new()


func setup(p_interp, p_player: Player, p_parts_root: Node) -> void:
	interp = p_interp
	player = p_player
	parts_root = p_parts_root
	game_inst = _mk("DataModel", "Game", "service")
	workspace = _mk("Workspace", "Workspace", "workspace")
	players_svc = _mk("Players", "Players", "players")
	_attach(game_inst, workspace)
	_attach(game_inst, players_svc)
	services["Workspace"] = workspace
	services["Players"] = players_svc
	for sname in ["Lighting", "ReplicatedStorage", "ServerStorage", "ServerScriptService", "StarterGui",
			"StarterPlayer", "Debris", "RunService", "TweenService", "SoundService", "UserInputService"]:
		var s := _mk(sname, sname, "service")
		_attach(game_inst, s)
		services[sname] = s
	lp = _mk("Player", "Player1", "player")
	_attach(players_svc, lp)
	character = _mk("Model", "Player1", "character")
	_attach(workspace, character)
	humanoid = _mk("Humanoid", "Humanoid", "humanoid")
	_attach(character, humanoid)
	root_part = _mk("Part", "HumanoidRootPart", "root")
	_attach(character, root_part)
	lp.props["Character"] = character
	for body in parts_root.get_children():
		_make_part_inst(body)
	player.part_touched.connect(_on_part_touched)
	player.part_untouched.connect(_on_part_untouched)
	player.died.connect(_on_died)
	player.health_changed.connect(_on_health_changed)


func _mk(cls: String, nm: String, role: String) -> RbxInst:
	var i := RbxInst.new()
	i.cls = cls
	i.name = nm
	i.role = role
	return i


func _attach(parent: RbxInst, child: RbxInst) -> void:
	child.parent = parent
	parent.children.append(child)


func _sig(i: RbxInst, nm: String) -> RbxSignal:
	if not i.signals.has(nm):
		i.signals[nm] = RbxSignal.new()
	return i.signals[nm]


func _make_part_inst(node: Node) -> RbxInst:
	var d: Dictionary = node.get_meta("data")
	var nm := str(d.get("n", ""))
	var i := _mk("Part", nm if nm != "" else "Part", "part")
	i.node = node as Node3D
	node_map[node] = i
	_attach(workspace, i)
	return i


func _new_part_inst(d: Dictionary = {}) -> RbxInst:
	if d.is_empty():
		d = {"k": 0, "p": Vector3(0, 5, 0), "s": Vector3(4, 1, 2), "c": Color(0.64, 0.64, 0.64),
			"x": 0, "r": 0.0, "n": "", "a": 0.0, "b": 0, "sc": ""}
	var body := PartFactory.build(d)
	var i := _mk("Part", "Part", "part")
	i.node = body
	node_map[body] = i
	return i


func script_inst_for_part(node: Node3D) -> RbxInst:
	var s := _mk("Script", "Script", "inst")
	var pi: RbxInst = node_map.get(node)
	if pi != null:
		_attach(pi, s)
	return s


func script_inst_global(nm: String) -> RbxInst:
	var s := _mk("Script", nm, "inst")
	_attach(services["ServerScriptService"], s)
	return s


# ------------------------------------------------------------------ global tablolar
func install_globals(G: Dictionary) -> void:
	G["game"] = game_inst
	G["workspace"] = workspace
	G["Workspace"] = workspace
	G["Instance"] = interp.mk_lib({"new": _instance_new})
	var v3: LuaTable = interp.mk_lib({"new": _v3_new})
	v3.set_v("zero", Vector3.ZERO)
	v3.set_v("one", Vector3.ONE)
	v3.set_v("xAxis", Vector3.RIGHT)
	v3.set_v("yAxis", Vector3.UP)
	v3.set_v("zAxis", Vector3.BACK)
	G["Vector3"] = v3
	G["Color3"] = interp.mk_lib({"new": _c3_new, "fromRGB": _c3_rgb, "fromHSV": _c3_hsv, "fromHex": _c3_hex})
	G["BrickColor"] = interp.mk_lib({"new": _brick_new})
	G["CFrame"] = interp.mk_lib({"new": _cf_new, "Angles": _cf_angles})
	G["TweenInfo"] = interp.mk_lib({"new": _tweeninfo_new})
	G["Random"] = interp.mk_lib({"new": _random_new})
	G["Enum"] = _enum_table("Enum")


func _v3_new(a: Array, _th: LuaThread) -> Variant:
	return [Vector3(interp.num(interp.arg(a, 0)), interp.num(interp.arg(a, 1)), interp.num(interp.arg(a, 2)))]


func _c3_new(a: Array, _th: LuaThread) -> Variant:
	return [Color(interp.num(interp.arg(a, 0)), interp.num(interp.arg(a, 1)), interp.num(interp.arg(a, 2)))]


func _c3_rgb(a: Array, _th: LuaThread) -> Variant:
	return [Color(interp.num(interp.arg(a, 0)) / 255.0, interp.num(interp.arg(a, 1)) / 255.0, interp.num(interp.arg(a, 2)) / 255.0)]


func _c3_hsv(a: Array, _th: LuaThread) -> Variant:
	return [Color.from_hsv(interp.num(interp.arg(a, 0)), interp.num(interp.arg(a, 1)), interp.num(interp.arg(a, 2)))]


func _c3_hex(a: Array, _th: LuaThread) -> Variant:
	return [Color.html(interp.tostr(interp.arg(a, 0)))]


func _brick_new(a: Array, _th: LuaThread) -> Variant:
	var nm := interp.tostr(interp.arg(a, 0)).to_lower()
	return [BRICK.get(nm, Color(0.64, 0.64, 0.64))]


func _cf_new(a: Array, _th: LuaThread) -> Variant:
	if a.is_empty():
		return [Transform3D.IDENTITY]
	if a[0] is Vector3:
		return [Transform3D(Basis(), a[0])]
	return [Transform3D(Basis(), Vector3(interp.num(a[0]), interp.num(interp.arg(a, 1)), interp.num(interp.arg(a, 2))))]


func _cf_angles(a: Array, _th: LuaThread) -> Variant:
	var e := Vector3(interp.num(interp.arg(a, 0)), interp.num(interp.arg(a, 1)), interp.num(interp.arg(a, 2)))
	return [Transform3D(Basis.from_euler(e), Vector3.ZERO)]


func _tweeninfo_new(a: Array, _th: LuaThread) -> Variant:
	var t := LuaTable.new()
	t.set_v("Time", interp.num(a[0]) if a.size() > 0 and a[0] != null else 1.0)
	t.set_v("EasingStyle", interp.arg(a, 1))
	t.set_v("EasingDirection", interp.arg(a, 2))
	return [t]


func _random_new(a: Array, _th: LuaThread) -> Variant:
	var r := _mk("Random", "Random", "inst")
	var rng := RandomNumberGenerator.new()
	if a.size() > 0 and a[0] != null:
		rng.seed = int(interp.num(a[0]))
	else:
		rng.randomize()
	r.props["rng"] = rng
	return [r]


func _enum_table(path: String) -> LuaTable:
	var t := LuaTable.new()
	var m := LuaTable.new()
	m.set_v("__index", interp._fn("enum_index", _enum_index.bind(path)))
	t.meta = m
	return t


func _enum_index(a: Array, _th: LuaThread, path: String) -> Variant:
	var full := path + "." + interp.tostr(interp.arg(a, 1))
	if path.count(".") >= 1:
		return [full]
	return [_enum_table(full)]


func _instance_new(a: Array, th: LuaThread) -> Variant:
	var cls := interp.tostr(interp.arg(a, 0))
	var i: RbxInst
	match cls:
		"Part", "WedgePart", "SpawnLocation", "Seat", "MeshPart", "TrussPart", "BasePart", "CornerWedgePart":
			i = _new_part_inst()
		_:
			i = _mk(cls, cls, "inst")
			match cls:
				"IntValue", "NumberValue":
					i.props["Value"] = 0.0
				"StringValue":
					i.props["Value"] = ""
				"BoolValue":
					i.props["Value"] = false
	var pr: Variant = interp.arg(a, 1)
	if pr != null:
		set_prop(i, "Parent", pr, th)
	return [i]


# ------------------------------------------------------------------ özellik okuma
func index(obj: Variant, key: Variant, _th: LuaThread) -> Variant:
	var k := interp.tostr(key)
	if obj is RbxInst:
		var i: RbxInst = obj
		match i.role:
			"part":
				return _part_get(i, k)
			"root":
				return _root_get(i, k)
			"humanoid":
				return _hum_get(i, k)
			"player":
				return _player_get(i, k)
			"players":
				return _players_get(i, k)
			"workspace":
				return _ws_get(i, k)
			"service":
				return _service_get(i, k)
		return _generic_get(i, k)
	if obj is Vector3:
		return _v3_get(obj, k)
	if obj is Color:
		return _c3_get(obj, k)
	if obj is Transform3D:
		return _cf_get(obj, k)
	return null


func _generic_get(i: RbxInst, k: String) -> Variant:
	match k:
		"Name":
			return i.name
		"ClassName":
			return i.cls
		"Parent":
			return i.parent
	if SIGNAL_NAMES.has(k):
		return _sig(i, k)
	if i.props.has(k):
		return i.props[k]
	for c in i.children:
		if (c as RbxInst).name == k:
			return c
	return null


func _part_get(i: RbxInst, k: String) -> Variant:
	if i.destroyed or not is_instance_valid(i.node):
		return null
	var d: Dictionary = i.node.get_meta("data")
	match k:
		"Position":
			return i.node.position
		"Size":
			return d["s"]
		"Color", "BrickColor":
			return d["c"]
		"Transparency":
			return float(i.props.get("Transparency", 0.0))
		"CanCollide":
			return bool(i.props.get("CanCollide", true))
		"Anchored":
			return true
		"Orientation", "Rotation":
			return Vector3(0.0, float(d.get("r", 0.0)), 0.0)
		"CFrame":
			return Transform3D(Basis.from_euler(Vector3(0.0, deg_to_rad(float(d.get("r", 0.0))), 0.0)), i.node.position)
		"Material":
			return i.props.get("Material", "Enum.Material.Plastic")
	return _generic_get(i, k)


func _root_get(i: RbxInst, k: String) -> Variant:
	match k:
		"Position":
			return player.global_position + Vector3(0, 3, 0)
		"CFrame":
			return Transform3D(Basis(), player.global_position + Vector3(0, 3, 0))
		"Velocity", "AssemblyLinearVelocity":
			return player.velocity
		"Size":
			return Vector3(2, 2, 1)
	return _generic_get(i, k)


func _hum_get(i: RbxInst, k: String) -> Variant:
	match k:
		"Health":
			return player.health
		"MaxHealth":
			return Player.MAX_HEALTH
		"WalkSpeed":
			return player.speed * 2.0
		"JumpPower":
			return player.jump_velocity / 0.22
		"DisplayName":
			return "Player1"
	return _generic_get(i, k)


func _player_get(i: RbxInst, k: String) -> Variant:
	match k:
		"DisplayName":
			return i.name
		"UserId":
			return 1
		"Character":
			return character
		"Team", "TeamColor":
			return null
	return _generic_get(i, k)


func _players_get(i: RbxInst, k: String) -> Variant:
	match k:
		"LocalPlayer":
			return lp
		"MaxPlayers":
			return 1
	return _generic_get(i, k)


func _ws_get(i: RbxInst, k: String) -> Variant:
	match k:
		"Gravity":
			return 196.2
		"CurrentCamera", "Terrain":
			return null
	return _generic_get(i, k)


func _service_get(i: RbxInst, k: String) -> Variant:
	if i.cls == "RunService":
		match k:
			"Heartbeat", "PostSimulation":
				return heartbeat
			"RenderStepped", "Stepped", "PreSimulation", "PreRender":
				return stepped
	return _generic_get(i, k)


func _v3_get(v: Vector3, k: String) -> Variant:
	match k:
		"X", "x":
			return v.x
		"Y", "y":
			return v.y
		"Z", "z":
			return v.z
		"Magnitude":
			return v.length()
		"Unit":
			return v.normalized()
	return null


func _c3_get(c: Color, k: String) -> Variant:
	match k:
		"R", "r":
			return c.r
		"G", "g":
			return c.g
		"B", "b":
			return c.b
	return null


func _cf_get(t: Transform3D, k: String) -> Variant:
	match k:
		"Position", "p":
			return t.origin
		"X":
			return t.origin.x
		"Y":
			return t.origin.y
		"Z":
			return t.origin.z
		"LookVector":
			return -t.basis.z
		"RightVector":
			return t.basis.x
		"UpVector":
			return t.basis.y
	return null


# ------------------------------------------------------------------ özellik yazma
func set_prop(obj: Variant, key: Variant, val: Variant, th: LuaThread) -> void:
	var k := interp.tostr(key)
	if obj is RbxInst:
		var i: RbxInst = obj
		match i.role:
			"part":
				_part_set(i, k, val)
			"root":
				_root_set(i, k, val)
			"humanoid":
				_hum_set(i, k, val)
			_:
				_generic_set(i, k, val)
		return
	interp.throw(th, "bu değerin '%s' özelliği değiştirilemez" % k)


func _generic_set(i: RbxInst, k: String, v: Variant) -> void:
	match k:
		"Name":
			i.name = interp.tostr(v)
		"Parent":
			_reparent(i, v)
		_:
			i.props[k] = v
			if k == "Value":
				fire(_sig(i, "Changed"), [v])


func _part_set(i: RbxInst, k: String, v: Variant) -> void:
	if i.destroyed or not is_instance_valid(i.node):
		return
	var body := i.node as StaticBody3D
	var d: Dictionary = i.node.get_meta("data")
	match k:
		"Position":
			if v is Vector3:
				i.node.position = v
				d["p"] = v
		"Size":
			if v is Vector3:
				d["s"] = v
				PartFactory.refresh(body)
		"Color", "BrickColor":
			if v is Color:
				d["c"] = v
				PartFactory.refresh(body)
		"Transparency":
			i.props["Transparency"] = interp.num(v)
			var mesh := i.node.get_node_or_null("Mesh") as MeshInstance3D
			if mesh != null:
				mesh.transparency = clampf(interp.num(v), 0.0, 1.0)
		"CanCollide":
			i.props["CanCollide"] = interp.truthy(v)
			var shape := i.node.get_node_or_null("Shape") as CollisionShape3D
			if shape != null:
				shape.set_deferred("disabled", not interp.truthy(v))
		"Orientation", "Rotation":
			if v is Vector3:
				d["r"] = v.y
				PartFactory.refresh(body)
		"CFrame":
			if v is Transform3D:
				d["p"] = v.origin
				d["r"] = rad_to_deg(v.basis.get_euler().y)
				PartFactory.refresh(body)
		"Name":
			i.name = interp.tostr(v)
			d["n"] = i.name
		"Parent":
			_reparent(i, v)
		_:
			i.props[k] = v


func _root_set(i: RbxInst, k: String, v: Variant) -> void:
	match k:
		"Position":
			if v is Vector3:
				player.teleport(v - Vector3(0, 3, 0))
		"CFrame":
			if v is Transform3D:
				player.teleport(v.origin - Vector3(0, 3, 0))
		"Velocity", "AssemblyLinearVelocity":
			if v is Vector3 and v.y > 0.0:
				player.launch(v.y * 0.22)  # Roblox JumpPower 50 = bizde 11
		_:
			_generic_set(i, k, v)


func _hum_set(i: RbxInst, k: String, v: Variant) -> void:
	match k:
		"Health":
			player.set_health(interp.num(v))
		"WalkSpeed":
			player.speed = maxf(interp.num(v), 0.0) * 0.5
		"JumpPower":
			player.jump_velocity = maxf(interp.num(v), 0.0) * 0.22
		_:
			_generic_set(i, k, v)


func _in_workspace(i: RbxInst) -> bool:
	var p: RbxInst = i.parent
	while p != null:
		if p == workspace:
			return true
		p = p.parent
	return false


func _reparent(i: RbxInst, newp: Variant) -> void:
	if i.parent != null:
		i.parent.children.erase(i)
	i.parent = null
	if newp is RbxInst:
		var np: RbxInst = newp
		np.children.append(i)
		i.parent = np
		if np.role != "service" and np != workspace:
			fire(_sig(np, "ChildAdded"), [i])
	if i.role == "part" and is_instance_valid(i.node):
		var inws := _in_workspace(i)
		if inws and not i.node.is_inside_tree():
			parts_root.add_child(i.node)
		elif not inws and i.node.is_inside_tree():
			parts_root.remove_child(i.node)


func _destroy(i: RbxInst) -> void:
	if i.destroyed or ["character", "humanoid", "root", "player", "players", "workspace", "service"].has(i.role):
		return
	i.destroyed = true
	for c in i.children.duplicate():
		_destroy(c)
	if i.parent != null:
		i.parent.children.erase(i)
		i.parent = null
	if i.node != null and is_instance_valid(i.node):
		node_map.erase(i.node)
		if i.node.get_parent() != null:
			i.node.get_parent().remove_child(i.node)
		i.node.queue_free()


# ------------------------------------------------------------------ metotlar
func method(obj: Variant, nm: String, args: Array, th: LuaThread) -> Array:
	if obj is RbxSignal:
		return await _signal_method(obj, nm, args, th)
	if obj is RbxConn:
		if nm == "Disconnect":
			(obj as RbxConn).connected = false
		return []
	if obj is RbxInst:
		return await _inst_method(obj, nm, args, th)
	if obj is Vector3:
		return _v3_method(obj, nm, args, th)
	if obj is Color and nm == "Lerp":
		var o: Variant = interp.arg(args, 0)
		if o is Color:
			return [(obj as Color).lerp(o, interp.num(interp.arg(args, 1)))]
	interp.throw(th, "attempt to call method '%s' on a %s value" % [nm, interp.type_name(obj)])
	return []


func _signal_method(sg: RbxSignal, nm: String, args: Array, th: LuaThread) -> Array:
	match nm:
		"Connect", "connect", "Once", "once":
			var f: Variant = interp.arg(args, 0)
			if not (f is LuaFunc):
				interp.throw(th, "Connect: fonksiyon gerekli")
				return []
			var conn := RbxConn.new()
			sg.handlers.append({"fn": f, "conn": conn, "once": nm.to_lower() == "once"})
			return [conn]
		"Wait", "wait":
			var w := LuaWait.new()
			sg.waiters.append(w)
			var v: Variant = await w.done
			return [v]
	interp.throw(th, "RBXScriptSignal üzerinde '%s' yok" % nm)
	return []


func _v3_method(v: Vector3, nm: String, args: Array, th: LuaThread) -> Array:
	var o: Variant = interp.arg(args, 0)
	match nm:
		"Lerp":
			if o is Vector3:
				return [v.lerp(o, interp.num(interp.arg(args, 1)))]
		"Dot":
			if o is Vector3:
				return [v.dot(o)]
		"Cross":
			if o is Vector3:
				return [v.cross(o)]
		"Distance":
			if o is Vector3:
				return [v.distance_to(o)]
	interp.throw(th, "Vector3 üzerinde '%s' yok" % nm)
	return []


func _find_child(i: RbxInst, nm: String, recursive: bool) -> Variant:
	for c in i.children:
		if (c as RbxInst).name == nm:
			return c
	if recursive:
		for c2 in i.children:
			var r: Variant = _find_child(c2, nm, true)
			if r != null:
				return r
	return null


func _children_table(arr: Array) -> LuaTable:
	var t := LuaTable.new()
	for c in arr:
		t.append(c)
	return t


func _descendants(i: RbxInst, out: Array) -> void:
	for c in i.children:
		out.append(c)
		_descendants(c, out)


func _is_a(i: RbxInst, cls: String) -> bool:
	if i.cls == cls or cls == "Instance":
		return true
	if i.role == "part" and (cls == "BasePart" or cls == "PVInstance"):
		return true
	return i.role == "character" and cls == "Model"


func _clone(i: RbxInst) -> RbxInst:
	if i.role == "part" and is_instance_valid(i.node):
		var d2: Dictionary = (i.node.get_meta("data") as Dictionary).duplicate()
		d2["sc"] = ""
		var ni := _new_part_inst(d2)
		ni.name = i.name
		ni.props = i.props.duplicate()
		return ni
	var c := _mk(i.cls, i.name, "inst")
	c.props = i.props.duplicate()
	for ch in i.children:
		_attach(c, _clone(ch))
	return c


func _debris_task(i: RbxInst, secs: float) -> void:
	await interp.wait_seconds(secs)
	_destroy(i)


func _inst_method(i: RbxInst, nm: String, args: Array, th: LuaThread) -> Array:
	var a0: Variant = interp.arg(args, 0)
	match nm:
		"FindFirstChild":
			return [_find_child(i, interp.tostr(a0), interp.truthy(interp.arg(args, 1)))]
		"WaitForChild":
			for n in 50:
				var found: Variant = _find_child(i, interp.tostr(a0), false)
				if found != null:
					return [found]
				await interp.wait_seconds(0.1)
			return [null]
		"FindFirstChildOfClass", "FindFirstChildWhichIsA":
			for c in i.children:
				if _is_a(c, interp.tostr(a0)):
					return [c]
			return [null]
		"GetChildren":
			return [_children_table(i.children)]
		"GetDescendants":
			var all: Array = []
			_descendants(i, all)
			return [_children_table(all)]
		"Destroy", "Remove":
			_destroy(i)
			return []
		"ClearAllChildren":
			for c2 in i.children.duplicate():
				_destroy(c2)
			return []
		"Clone":
			return [_clone(i)]
		"IsA":
			return [_is_a(i, interp.tostr(a0))]
		"SetAttribute":
			i.attrs[interp.tostr(a0)] = interp.arg(args, 1)
			return []
		"GetAttribute":
			return [i.attrs.get(interp.tostr(a0))]
		"IsDescendantOf":
			var p: RbxInst = i.parent
			while p != null:
				if is_same(p, a0):
					return [true]
				p = p.parent
			return [false]
		"GetFullName":
			return [i.name]
		"GetService":
			if i == game_inst:
				var s: Variant = services.get(interp.tostr(a0))
				if s == null:
					interp.throw(th, "'%s' servisi yok" % interp.tostr(a0))
					return []
				return [s]
	# sınıfa/role özel metotlar
	match i.role:
		"humanoid":
			match nm:
				"TakeDamage":
					player.take_damage(interp.num(a0))
					return []
				"Move", "MoveTo", "ChangeState", "EquipTool", "UnequipTools":
					return []
		"character":
			match nm:
				"MoveTo", "PivotTo":
					if a0 is Vector3:
						player.teleport(a0)
					elif a0 is Transform3D:
						player.teleport((a0 as Transform3D).origin)
					return []
				"GetPivot":
					return [Transform3D(Basis(), player.global_position)]
		"players":
			match nm:
				"GetPlayers":
					return [_children_table([lp])]
				"GetPlayerFromCharacter":
					return [lp if is_same(a0, character) else null]
	match i.cls:
		"TweenService":
			if nm == "Create":
				return [_tween_create(a0, interp.arg(args, 1), interp.arg(args, 2))]
		"Tween":
			match nm:
				"Play":
					_tween_play(i)
					return []
				"Cancel", "Pause":
					var tw: Variant = i.props.get("_tween")
					if tw is Tween and is_instance_valid(tw):
						(tw as Tween).kill()
					return []
		"Debris":
			if nm == "AddItem" and a0 is RbxInst:
				_debris_task(a0, interp.num(interp.arg(args, 1)) if args.size() > 1 else 10.0)
				return []
		"Random":
			var rng: RandomNumberGenerator = i.props["rng"]
			if nm == "NextNumber":
				if args.size() >= 2:
					return [rng.randf_range(interp.num(a0), interp.num(args[1]))]
				return [rng.randf()]
			if nm == "NextInteger":
				return [float(rng.randi_range(int(interp.num(a0)), int(interp.num(interp.arg(args, 1)))))]
		"RunService":
			match nm:
				"IsClient", "IsServer", "IsRunning":
					return [true]
				"IsStudio":
					return [false]
	if NOOP_CLASSES.has(i.cls):
		return []
	if i.role == "part" and nm in ["SetNetworkOwner", "BreakJoints", "MakeJoints"]:
		return []
	interp.throw(th, "'%s' is not a valid member of %s" % [nm, i.cls])
	return []


# ------------------------------------------------------------------ TweenService
func _tween_create(target: Variant, info: Variant, goal: Variant) -> RbxInst:
	var tw := _mk("Tween", "Tween", "inst")
	tw.props["target"] = target
	tw.props["goal"] = goal
	tw.props["time"] = 1.0
	tw.props["style"] = ""
	if info is LuaTable:
		tw.props["time"] = interp.num((info as LuaTable).get_v("Time"))
		tw.props["style"] = interp.tostr((info as LuaTable).get_v("EasingStyle"))
	return tw


func _tween_play(tw: RbxInst) -> void:
	var tgt: Variant = tw.props.get("target")
	var goal: Variant = tw.props.get("goal")
	if not (tgt is RbxInst) or not (goal is LuaTable):
		return
	var tween: Tween = interp.create_tween()
	tween.set_parallel(true)
	if str(tw.props.get("style", "")).contains("Linear"):
		tween.set_trans(Tween.TRANS_LINEAR)
	else:
		tween.set_trans(Tween.TRANS_SINE)
	var secs := maxf(float(tw.props.get("time", 1.0)), 0.01)
	var gt: LuaTable = goal
	for k in gt.keys():
		var to: Variant = gt.get_v(k)
		var from: Variant = index(tgt, k, _dummy_th)
		if from == null or to == null:
			continue
		tween.tween_method(_tween_set.bind(tgt, interp.tostr(k)), from, to, secs)
	tw.props["_tween"] = tween
	tween.finished.connect(_tween_done.bind(tw))


func _tween_set(v: Variant, tgt: Variant, key: String) -> void:
	set_prop(tgt, key, v, _dummy_th)


func _tween_done(tw: RbxInst) -> void:
	fire(_sig(tw, "Completed"), ["Enum.PlaybackState.Completed"])


# ------------------------------------------------------------------ aritmetik (Vector3 / CFrame)
func arith(op: String, a: Variant, b: Variant, th: LuaThread) -> Variant:
	if a is Vector3 and b is Vector3:
		match op:
			"+":
				return a + b
			"-":
				return a - b
			"*":
				return a * b
			"/":
				return a / b
	elif a is Vector3 and interp.is_num(b):
		var f := float(b)
		match op:
			"*":
				return a * f
			"/":
				return a / f
	elif interp.is_num(a) and b is Vector3 and op == "*":
		return float(a) * b
	elif a is Transform3D and op == "*":
		if b is Transform3D:
			return a * b
		if b is Vector3:
			return a * b
	elif a is Transform3D and b is Vector3 and op == "+":
		return Transform3D((a as Transform3D).basis, (a as Transform3D).origin + b)
	interp.throw(th, "attempt to perform arithmetic (%s) on %s and %s" % [op, interp.typeof_name(a), interp.typeof_name(b)])
	return null


# ------------------------------------------------------------------ olaylar
func fire(sg: RbxSignal, args: Array) -> void:
	if sg.handlers.is_empty() and sg.waiters.is_empty():
		return
	for h in sg.handlers.duplicate():
		var conn: RbxConn = h["conn"]
		if not conn.connected:
			continue
		if h["once"]:
			conn.connected = false
		interp.spawn_fn(h["fn"], args)
	if not sg.waiters.is_empty():
		var ws := sg.waiters.duplicate()
		sg.waiters.clear()
		for w in ws:
			(w as LuaWait).done.emit(args[0] if args.size() > 0 else null)
	sg.handlers = sg.handlers.filter(func(x: Dictionary) -> bool: return (x["conn"] as RbxConn).connected)


func _on_part_touched(body: Node3D) -> void:
	if node_map.has(body):
		fire(_sig(node_map[body], "Touched"), [root_part])


func _on_part_untouched(body: Node3D) -> void:
	if node_map.has(body):
		fire(_sig(node_map[body], "TouchEnded"), [root_part])


func _on_died() -> void:
	fire(_sig(humanoid, "Died"), [])
	fire(_sig(lp, "CharacterAdded"), [character])


func _on_health_changed(cur: float, _mx: float) -> void:
	if humanoid.signals.has("HealthChanged"):
		fire(humanoid.signals["HealthChanged"], [cur])


func tick(delta: float) -> void:
	fire(heartbeat, [delta])
	fire(stepped, [delta])


func fire_initial() -> void:
	fire(_sig(players_svc, "PlayerAdded"), [lp])
	fire(_sig(lp, "CharacterAdded"), [character])


## Oyuncunun leaderstats klasöründeki değerler (HUD ve StarterGui {ad} metinleri için).
func leaderstats_values() -> Dictionary:
	var out := {}
	for c in lp.children:
		var ci: RbxInst = c
		if ci.name == "leaderstats":
			for v in ci.children:
				var vi: RbxInst = v
				if vi.props.has("Value"):
					out[vi.name] = interp.tostr(vi.props["Value"])
	return out
