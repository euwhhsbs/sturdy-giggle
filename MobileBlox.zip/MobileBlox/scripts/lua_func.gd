class_name LuaFunc
extends RefCounted
## Lua fonksiyonu: ya kullanıcı kodu (params/body/scope) ya da yerleşik (native Callable: (args, thread) -> Array).

var name := "?"
var params: Array = []
var vararg := false
var body: Array = []
var scope: LuaScope = null
var native: Callable = Callable()
