class_name LuauLexer
extends RefCounted
## Luau/Lua kaynak kodunu simgelere (token) ayırır. Çıktı: {"tokens": [...], "error": ""}

const KEYWORDS := [
	"and", "break", "continue", "do", "else", "elseif", "end", "false", "for", "function", "if",
	"in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while",
]
const OPS3 := ["...", "//=", "..="]
const OPS2 := ["==", "~=", "<=", ">=", "..", "//", "+=", "-=", "*=", "/=", "%=", "^=", "::", "->"]
const OPS1 := "+-*/%^#<>=(){}[];:,.?"


static func _is_alpha(c: String) -> bool:
	return (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or c == "_"


static func _is_digit(c: String) -> bool:
	return c >= "0" and c <= "9"


## "[" ardından "=" * seviye ve "[" varsa seviyeyi, yoksa -1 döndürür.
static func _long_level(src: String, i: int) -> int:
	if i >= src.length() or src[i] != "[":
		return -1
	var j := i + 1
	var lvl := 0
	while j < src.length() and src[j] == "=":
		lvl += 1
		j += 1
	if j < src.length() and src[j] == "[":
		return lvl
	return -1


static func tokenize(src: String) -> Dictionary:
	var toks: Array = []
	var i := 0
	var n := src.length()
	var line := 1
	while i < n:
		var c := src[i]
		if c == "\n":
			line += 1
			i += 1
			continue
		if c == " " or c == "\t" or c == "\r":
			i += 1
			continue
		# Yorumlar: -- ... ve --[[ ... ]]
		if c == "-" and i + 1 < n and src[i + 1] == "-":
			i += 2
			var lvl := _long_level(src, i)
			if lvl >= 0:
				var close := "]" + "=".repeat(lvl) + "]"
				var e := src.find(close, i + lvl + 2)
				if e == -1:
					return {"tokens": [], "error": "Satır %d: kapanmayan yorum --[[" % line}
				line += src.substr(i, e - i).count("\n")
				i = e + close.length()
			else:
				while i < n and src[i] != "\n":
					i += 1
			continue
		# Uzun string [[ ... ]]
		if c == "[":
			var lvl2 := _long_level(src, i)
			if lvl2 >= 0:
				var close2 := "]" + "=".repeat(lvl2) + "]"
				var start2 := i + lvl2 + 2
				var e2 := src.find(close2, start2)
				if e2 == -1:
					return {"tokens": [], "error": "Satır %d: kapanmayan [[ string" % line}
				var text := src.substr(start2, e2 - start2)
				if text.begins_with("\n"):
					text = text.substr(1)
				toks.append({"t": "str", "v": text, "l": line})
				line += src.substr(i, e2 - i).count("\n")
				i = e2 + close2.length()
				continue
		# String "..." veya '...'
		if c == "\"" or c == "'":
			var buf := ""
			var closed := false
			i += 1
			while i < n:
				var ch := src[i]
				if ch == c:
					closed = true
					i += 1
					break
				if ch == "\n":
					break
				if ch == "\\" and i + 1 < n:
					var nx := src[i + 1]
					i += 2
					if nx == "n":
						buf += "\n"
					elif nx == "t":
						buf += "\t"
					elif nx == "r":
						buf += "\r"
					elif nx == "\n":
						buf += "\n"
						line += 1
					elif _is_digit(nx):
						var code := nx
						while code.length() < 3 and i < n and _is_digit(src[i]):
							code += src[i]
							i += 1
						buf += char(code.to_int())
					elif nx == "x" and i + 1 < n:
						buf += char(src.substr(i, 2).hex_to_int())
						i += 2
					else:
						buf += nx
					continue
				buf += ch
				i += 1
			if not closed:
				return {"tokens": [], "error": "Satır %d: kapanmayan string" % line}
			toks.append({"t": "str", "v": buf, "l": line})
			continue
		# Sayı
		if _is_digit(c) or (c == "." and i + 1 < n and _is_digit(src[i + 1])):
			var j := i
			if c == "0" and i + 1 < n and (src[i + 1] == "x" or src[i + 1] == "X"):
				j = i + 2
				while j < n and (_is_digit(src[j]) or (src[j].to_lower() >= "a" and src[j].to_lower() <= "f")):
					j += 1
				toks.append({"t": "num", "v": float(src.substr(i + 2, j - i - 2).hex_to_int()), "l": line})
			else:
				while j < n and (_is_digit(src[j]) or src[j] == "_"):
					j += 1
				if j < n and src[j] == "." and not (j + 1 < n and src[j + 1] == "."):
					j += 1
					while j < n and _is_digit(src[j]):
						j += 1
				if j < n and (src[j] == "e" or src[j] == "E"):
					var k := j + 1
					if k < n and (src[k] == "+" or src[k] == "-"):
						k += 1
					if k < n and _is_digit(src[k]):
						j = k
						while j < n and _is_digit(src[j]):
							j += 1
				toks.append({"t": "num", "v": src.substr(i, j - i).replace("_", "").to_float(), "l": line})
			i = j
			continue
		# İsim / anahtar sözcük
		if _is_alpha(c):
			var j2 := i
			while j2 < n and (_is_alpha(src[j2]) or _is_digit(src[j2])):
				j2 += 1
			var word := src.substr(i, j2 - i)
			toks.append({"t": "kw" if KEYWORDS.has(word) else "name", "v": word, "l": line})
			i = j2
			continue
		# Operatörler
		var three := src.substr(i, 3)
		if OPS3.has(three):
			toks.append({"t": "op", "v": three, "l": line})
			i += 3
			continue
		var two := src.substr(i, 2)
		if OPS2.has(two):
			toks.append({"t": "op", "v": two, "l": line})
			i += 2
			continue
		if OPS1.contains(c):
			toks.append({"t": "op", "v": c, "l": line})
			i += 1
			continue
		return {"tokens": [], "error": "Satır %d: beklenmeyen karakter '%s'" % [line, c]}
	toks.append({"t": "eof", "v": "<dosya sonu>", "l": line})
	return {"tokens": toks, "error": ""}
