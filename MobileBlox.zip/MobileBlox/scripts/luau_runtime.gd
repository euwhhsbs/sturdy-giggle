class_name LuauRuntime
extends Node
## Play'de Luau script'lerini (parça + genel) çalıştırır. print/warn/hata çıktıları "printed" sinyaliyle gelir.

signal printed(text: String, kind: int)  # 0 bilgi, 1 uyarı, 2 hata

var interp: LuauInterp
var bridge: RbxBridge


func setup(player: Player, parts_root: Node, global_scripts: Array) -> void:
	interp = LuauInterp.new()
	add_child(interp)
	interp.printed.connect(_on_printed)
	bridge = RbxBridge.new()
	bridge.setup(interp, player, parts_root)
	interp.bridge = bridge
	interp.install_globals()
	for body in parts_root.get_children():
		var d: Dictionary = body.get_meta("data")
		var src := str(d.get("sc", ""))
		if src.strip_edges() == "" or LuauParser.is_legacy(src):
			continue
		var nm := str(d.get("n", ""))
		_start(src, bridge.script_inst_for_part(body as Node3D), (nm if nm != "" else "Part") + " script'i")
	for g in global_scripts:
		var gsrc := str(g["src"])
		if gsrc.strip_edges() == "" or LuauParser.is_legacy(gsrc):
			continue
		_start(gsrc, bridge.script_inst_global(str(g["n"])), str(g["n"]))
	# Tüm script'ler olaylarını bağladıktan sonra PlayerAdded / CharacterAdded tetiklenir
	await get_tree().process_frame
	bridge.fire_initial()


func _start(src: String, script_inst: Variant, label: String) -> void:
	var r := LuauParser.parse(src)
	if not bool(r["ok"]):
		printed.emit("[%s] %s" % [label, r["error"]], 2)
		return
	interp.run_chunk(r["ast"], script_inst, label)


func _on_printed(text: String, kind: int) -> void:
	printed.emit(text, kind)


func leaderstats_values() -> Dictionary:
	return bridge.leaderstats_values() if bridge != null else {}
