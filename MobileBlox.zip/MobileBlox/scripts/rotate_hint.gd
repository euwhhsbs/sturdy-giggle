extends CanvasLayer
## Autoload: cihaz dikey tutulursa "yatay çevir" uyarısı gösterir (itch.io web / telefon tarayıcısı için).

var _panel: ColorRect


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_panel = ColorRect.new()
	_panel.color = Color(0.05, 0.07, 0.12, 0.97)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.visible = false
	add_child(_panel)
	_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	_panel.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var l := Label.new()
	l.text = "Lütfen cihazını yatay çevir\n\nPlease rotate your device"
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 40)
	cc.add_child(l)


func _process(_delta: float) -> void:
	var s := DisplayServer.window_get_size()
	_panel.visible = s.y > s.x
