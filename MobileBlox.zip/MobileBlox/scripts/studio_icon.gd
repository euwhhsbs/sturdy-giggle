class_name StudioIcon
extends Control
## Roblox Studio tarzı düz çizgi ikonları (görsel dosya gerekmez; hepsi kodla çizilir).
## Kullanım: StudioIcon.draw_icon(canvas_item, "select", Rect2(...), renk)  (yalnızca _draw içinde)

@export var icon_name := "":
	set(v):
		icon_name = v
		queue_redraw()
var color := Color(0.30, 0.65, 1.0):
	set(v):
		color = v
		queue_redraw()


func _init() -> void:
	custom_minimum_size = Vector2(28, 28)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	draw_icon(self, icon_name, Rect2(Vector2.ZERO, size), color)


static func default_color(icon: String) -> Color:
	match icon:
		"delete", "close":
			return Color(0.95, 0.38, 0.35)
		"play", "spawn":
			return Color(0.30, 0.85, 0.40)
		"paint":
			return Color(1.0, 0.65, 0.20)
		"workspace":
			return Color(0.35, 0.75, 1.0)
		"check":
			return Color(0.40, 0.85, 0.45)
		_:
			return Color(0.30, 0.65, 1.0)


static func _p(o: Vector2, s: float, x: float, y: float) -> Vector2:
	return o + Vector2(x, y) * s


static func _poly(ci: CanvasItem, o: Vector2, s: float, pts: Array, col: Color) -> void:
	var arr := PackedVector2Array()
	for p in pts:
		arr.append(_p(o, s, p[0], p[1]))
	ci.draw_colored_polygon(arr, col)


static func _line(ci: CanvasItem, o: Vector2, s: float, x1: float, y1: float, x2: float, y2: float, col: Color, w: float) -> void:
	ci.draw_line(_p(o, s, x1, y1), _p(o, s, x2, y2), col, w)


static func _rect(ci: CanvasItem, o: Vector2, s: float, x: float, y: float, w: float, h: float, col: Color, filled: bool, lw: float) -> void:
	ci.draw_rect(Rect2(_p(o, s, x, y), Vector2(w, h) * s), col, filled, lw)


static func _ellipse(ci: CanvasItem, o: Vector2, s: float, cx: float, cy: float, rx: float, ry: float, col: Color) -> void:
	var arr := PackedVector2Array()
	for i in 24:
		var a := TAU * float(i) / 24.0
		arr.append(_p(o, s, cx + cos(a) * rx, cy + sin(a) * ry))
	ci.draw_colored_polygon(arr, col)


static func draw_icon(ci: CanvasItem, icon: String, r: Rect2, col: Color) -> void:
	var s := minf(r.size.x, r.size.y)
	if s <= 1.0:
		return
	var o := r.position + (r.size - Vector2(s, s)) * 0.5
	var w := maxf(1.5, s * 0.075)
	match icon:
		"select":
			_poly(ci, o, s, [[0.22, 0.08], [0.22, 0.82], [0.40, 0.66], [0.53, 0.92], [0.65, 0.86], [0.52, 0.61], [0.76, 0.61]], col)
		"move":
			_line(ci, o, s, 0.5, 0.12, 0.5, 0.88, col, w)
			_line(ci, o, s, 0.12, 0.5, 0.88, 0.5, col, w)
			_poly(ci, o, s, [[0.5, 0.03], [0.37, 0.22], [0.63, 0.22]], col)
			_poly(ci, o, s, [[0.5, 0.97], [0.37, 0.78], [0.63, 0.78]], col)
			_poly(ci, o, s, [[0.03, 0.5], [0.22, 0.37], [0.22, 0.63]], col)
			_poly(ci, o, s, [[0.97, 0.5], [0.78, 0.37], [0.78, 0.63]], col)
		"scale":
			_rect(ci, o, s, 0.12, 0.38, 0.50, 0.50, col, false, w)
			_line(ci, o, s, 0.50, 0.50, 0.86, 0.14, col, w)
			_poly(ci, o, s, [[0.92, 0.08], [0.62, 0.14], [0.86, 0.38]], col)
		"rotate":
			var c := _p(o, s, 0.5, 0.5)
			var rad := 0.34 * s
			ci.draw_arc(c, rad, -PI * 0.9, PI * 0.55, 24, col, w)
			var a := PI * 0.55
			var n := Vector2(cos(a), sin(a))
			var t := Vector2(-sin(a), cos(a))
			var e := c + n * rad
			ci.draw_colored_polygon(PackedVector2Array([e + t * 0.18 * s, e + n * 0.12 * s, e - n * 0.12 * s]), col)
		"cube", "part":
			_poly(ci, o, s, [[0.5, 0.08], [0.88, 0.28], [0.5, 0.48], [0.12, 0.28]], col.lightened(0.3))
			_poly(ci, o, s, [[0.12, 0.28], [0.5, 0.48], [0.5, 0.92], [0.12, 0.72]], col)
			_poly(ci, o, s, [[0.5, 0.48], [0.88, 0.28], [0.88, 0.72], [0.5, 0.92]], col.darkened(0.3))
		"cylinder":
			_ellipse(ci, o, s, 0.5, 0.76, 0.32, 0.13, col.darkened(0.3))
			_rect(ci, o, s, 0.18, 0.26, 0.64, 0.50, col.darkened(0.15), true, 1.0)
			_ellipse(ci, o, s, 0.5, 0.26, 0.32, 0.13, col.lightened(0.3))
		"sphere":
			ci.draw_circle(_p(o, s, 0.5, 0.5), 0.40 * s, col)
			ci.draw_circle(_p(o, s, 0.38, 0.36), 0.10 * s, col.lightened(0.55))
		"paint":
			ci.draw_circle(_p(o, s, 0.5, 0.5), 0.40 * s, col)
			ci.draw_circle(_p(o, s, 0.36, 0.40), 0.08 * s, Color(0.9, 0.25, 0.25))
			ci.draw_circle(_p(o, s, 0.55, 0.32), 0.08 * s, Color(0.95, 0.9, 0.3))
			ci.draw_circle(_p(o, s, 0.66, 0.50), 0.08 * s, Color(0.3, 0.8, 0.4))
			ci.draw_circle(_p(o, s, 0.48, 0.66), 0.08 * s, Color(0.3, 0.5, 0.95))
		"delete", "close":
			_line(ci, o, s, 0.22, 0.22, 0.78, 0.78, col, w * 1.5)
			_line(ci, o, s, 0.78, 0.22, 0.22, 0.78, col, w * 1.5)
		"spawn":
			ci.draw_circle(_p(o, s, 0.5, 0.36), 0.22 * s, col)
			_poly(ci, o, s, [[0.31, 0.46], [0.69, 0.46], [0.5, 0.92]], col)
		"copy":
			_rect(ci, o, s, 0.12, 0.12, 0.48, 0.55, col, false, w)
			_rect(ci, o, s, 0.38, 0.32, 0.50, 0.56, Color(col.r, col.g, col.b, 0.3), true, 1.0)
			_rect(ci, o, s, 0.38, 0.32, 0.50, 0.56, col, false, w)
		"undo", "redo":
			var flip := icon == "redo"
			var cx := 0.45 if flip else 0.55
			var c2 := _p(o, s, cx, 0.58)
			var a0 := -PI * 0.5
			var a1 := PI * 0.6
			if flip:
				ci.draw_arc(c2, 0.28 * s, PI - a1, PI - a0, 20, col, w)
			else:
				ci.draw_arc(c2, 0.28 * s, a0, a1, 20, col, w)
			if flip:
				_poly(ci, o, s, [[0.70, 0.30], [0.50, 0.18], [0.50, 0.42]], col)
			else:
				_poly(ci, o, s, [[0.30, 0.30], [0.50, 0.18], [0.50, 0.42]], col)
		"play":
			_poly(ci, o, s, [[0.28, 0.15], [0.28, 0.85], [0.86, 0.5]], col)
		"save":
			_rect(ci, o, s, 0.14, 0.14, 0.72, 0.72, col, false, w)
			_rect(ci, o, s, 0.30, 0.14, 0.40, 0.26, col, true, 1.0)
			_rect(ci, o, s, 0.28, 0.54, 0.44, 0.32, col, false, w)
		"load":
			_poly(ci, o, s, [[0.10, 0.24], [0.40, 0.24], [0.50, 0.36], [0.90, 0.36], [0.90, 0.80], [0.10, 0.80]], col)
		"menu":
			_line(ci, o, s, 0.2, 0.30, 0.8, 0.30, col, w * 1.3)
			_line(ci, o, s, 0.2, 0.50, 0.8, 0.50, col, w * 1.3)
			_line(ci, o, s, 0.2, 0.70, 0.8, 0.70, col, w * 1.3)
		"all":
			for k in [[0.12, 0.12, 1, 1], [0.88, 0.12, -1, 1], [0.12, 0.88, 1, -1], [0.88, 0.88, -1, -1]]:
				_line(ci, o, s, k[0], k[1], k[0] + 0.22 * k[2], k[1], col, w)
				_line(ci, o, s, k[0], k[1], k[0], k[1] + 0.22 * k[3], col, w)
			_rect(ci, o, s, 0.34, 0.34, 0.32, 0.32, col, true, 1.0)
		"multi":
			_rect(ci, o, s, 0.10, 0.10, 0.50, 0.50, col, false, w)
			_rect(ci, o, s, 0.40, 0.40, 0.50, 0.50, Color(col.r, col.g, col.b, 0.35), true, 1.0)
			_rect(ci, o, s, 0.40, 0.40, 0.50, 0.50, col, false, w)
		"focus":
			ci.draw_arc(_p(o, s, 0.5, 0.5), 0.28 * s, 0.0, TAU, 28, col, w)
			_line(ci, o, s, 0.5, 0.08, 0.5, 0.30, col, w)
			_line(ci, o, s, 0.5, 0.70, 0.5, 0.92, col, w)
			_line(ci, o, s, 0.08, 0.5, 0.30, 0.5, col, w)
			_line(ci, o, s, 0.70, 0.5, 0.92, 0.5, col, w)
		"gui_frame", "workspace_frame":
			_rect(ci, o, s, 0.12, 0.20, 0.76, 0.60, col, false, w)
		"gui_label":
			_line(ci, o, s, 0.2, 0.25, 0.8, 0.25, col, w * 1.3)
			_line(ci, o, s, 0.5, 0.25, 0.5, 0.82, col, w * 1.3)
		"gui_button":
			_rect(ci, o, s, 0.10, 0.28, 0.80, 0.44, col, false, w)
			_line(ci, o, s, 0.30, 0.50, 0.70, 0.50, col, w)
		"step":
			_rect(ci, o, s, 0.08, 0.36, 0.84, 0.28, col, false, w)
			for i in 6:
				var x := 0.18 + float(i) * 0.13
				_line(ci, o, s, x, 0.36, x, 0.36 + (0.16 if i % 2 == 0 else 0.10), col, w * 0.8)
		"joystick":
			ci.draw_arc(_p(o, s, 0.5, 0.5), 0.38 * s, 0.0, TAU, 28, col, w)
			ci.draw_circle(_p(o, s, 0.5, 0.5), 0.14 * s, col)
		"camera":
			_rect(ci, o, s, 0.08, 0.28, 0.84, 0.54, col, false, w)
			ci.draw_arc(_p(o, s, 0.5, 0.55), 0.16 * s, 0.0, TAU, 20, col, w)
			_rect(ci, o, s, 0.30, 0.16, 0.20, 0.12, col, true, 1.0)
		"panels":
			_rect(ci, o, s, 0.08, 0.16, 0.84, 0.68, col, false, w)
			_line(ci, o, s, 0.36, 0.16, 0.36, 0.84, col, w)
			_line(ci, o, s, 0.68, 0.16, 0.68, 0.84, col, w)
		"workspace":
			ci.draw_arc(_p(o, s, 0.5, 0.5), 0.38 * s, 0.0, TAU, 28, col, w)
			_line(ci, o, s, 0.12, 0.5, 0.88, 0.5, col, w * 0.8)
			_ellipse(ci, o, s, 0.5, 0.5, 0.16, 0.38, Color(col.r, col.g, col.b, 0.25))
		"script", "script_new":
			_rect(ci, o, s, 0.20, 0.08, 0.60, 0.84, col, false, w)
			_line(ci, o, s, 0.32, 0.30, 0.68, 0.30, col, w * 0.8)
			_line(ci, o, s, 0.32, 0.46, 0.68, 0.46, col, w * 0.8)
			_line(ci, o, s, 0.32, 0.62, 0.55, 0.62, col, w * 0.8)
			if icon == "script_new":
				ci.draw_circle(_p(o, s, 0.78, 0.78), 0.17 * s, Color(0.12, 0.12, 0.12))
				_line(ci, o, s, 0.78, 0.66, 0.78, 0.90, col, w)
				_line(ci, o, s, 0.66, 0.78, 0.90, 0.78, col, w)
		"check":
			_line(ci, o, s, 0.18, 0.55, 0.42, 0.78, col, w * 1.6)
			_line(ci, o, s, 0.42, 0.78, 0.84, 0.26, col, w * 1.6)
		"indent":
			_line(ci, o, s, 0.46, 0.25, 0.88, 0.25, col, w)
			_line(ci, o, s, 0.46, 0.50, 0.88, 0.50, col, w)
			_line(ci, o, s, 0.46, 0.75, 0.88, 0.75, col, w)
			_poly(ci, o, s, [[0.10, 0.34], [0.10, 0.66], [0.32, 0.50]], col)
		"dedent":
			_line(ci, o, s, 0.46, 0.25, 0.88, 0.25, col, w)
			_line(ci, o, s, 0.46, 0.50, 0.88, 0.50, col, w)
			_line(ci, o, s, 0.46, 0.75, 0.88, 0.75, col, w)
			_poly(ci, o, s, [[0.32, 0.34], [0.32, 0.66], [0.10, 0.50]], col)
		"help":
			ci.draw_arc(_p(o, s, 0.5, 0.34), 0.20 * s, PI, TAU + PI * 0.6, 20, col, w * 1.3)
			_line(ci, o, s, 0.5, 0.55, 0.5, 0.66, col, w * 1.3)
			ci.draw_circle(_p(o, s, 0.5, 0.82), 0.06 * s, col)
		"share":
			ci.draw_circle(_p(o, s, 0.25, 0.5), 0.13 * s, col)
			ci.draw_circle(_p(o, s, 0.75, 0.22), 0.13 * s, col)
			ci.draw_circle(_p(o, s, 0.75, 0.78), 0.13 * s, col)
			_line(ci, o, s, 0.25, 0.5, 0.75, 0.22, col, w)
			_line(ci, o, s, 0.25, 0.5, 0.75, 0.78, col, w)
		"chevron_up":
			_line(ci, o, s, 0.25, 0.62, 0.5, 0.36, col, w * 1.3)
			_line(ci, o, s, 0.5, 0.36, 0.75, 0.62, col, w * 1.3)
		_:
			ci.draw_circle(_p(o, s, 0.5, 0.5), 0.30 * s, col)
