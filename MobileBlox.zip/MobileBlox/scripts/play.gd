class_name PlayMode
extends WorldBase
## Roblox Client modu: sol yarı = yüzen joystick, sağ yarı = kamera kaydırma,
## sağ alt = Zıpla (multitouch), sağ üst = Menü (Stüdyo'ya doğrudan geçiş YOK).

const JoystickScript := preload("res://scripts/touch_joystick.gd")

var player: Player
var movers: Array[AnimatableBody3D] = []
var runtime: ScriptRuntime
var luau: LuauRuntime
var log_rt: RichTextLabel
var stats_label: Label
var _log_lines: Array[String] = []
var _log_timer := 0.0
var toast_label: Label
var _toast_tw: Tween
var gui_views: Array[GuiItemView] = []
var _tok_t := 0.0
var _t := 0.0
var fps_label: Label
var joy: Control
var mode_btn: Button
var death_label: Label
var hp_bar: ProgressBar
var hp_fill: StyleBoxFlat
var _last_hp := 100.0
var flash: ColorRect
var big_label: Label


func _ready() -> void:
	animate_movers = true
	build_world()
	for c in parts_root.get_children():
		if c is AnimatableBody3D:
			movers.append(c)
	player = Player.new()
	player.name = "Player"
	add_child(player)
	_build_ui()
	# MobileBlox Script'leri (parça + genel) çalışmaya başlar
	runtime = ScriptRuntime.new()
	add_child(runtime)
	runtime.message.connect(_toast)
	runtime.setup(player, parts_root, Game.scripts)
	# Luau (Roblox dili) script'leri
	luau = LuauRuntime.new()
	add_child(luau)
	luau.printed.connect(_on_luau_print)
	luau.setup(player, parts_root, Game.scripts)


## Hareketli platformlar: başlangıç konumu çevresinde "mesafe" kadar gidip gelir.
func _physics_process(delta: float) -> void:
	_t += delta
	for m in movers:
		var d: Dictionary = m.get_meta("data")
		var axis := Vector3.ZERO
		axis[clampi(int(d.get("b", 0)), 0, 2)] = 1.0
		var dist := maxf(0.5, float(d.get("a", 6.0)))
		var omega := 2.5 / (dist * 0.5)  # tepe hız ~2.5 birim/sn
		m.global_position = (d["p"] as Vector3) + axis * sin(_t * omega) * dist * 0.5


func _process(delta: float) -> void:
	fps_label.text = "FPS: %d" % Engine.get_frames_per_second()
	_log_timer -= delta
	if _log_timer <= 0.0 and not _log_lines.is_empty():
		_log_lines.clear()
		log_rt.text = ""
	_tok_t += delta
	if _tok_t >= 0.2:  # StarterGui metinlerindeki {can} {ölüm} {fps} {oyun}
		_tok_t = 0.0
		var tokens := {
			"can": int(player.health), "ölüm": player.deaths,
			"fps": Engine.get_frames_per_second(), "oyun": Game.current_name(),
		}
		var ls: Dictionary = luau.leaderstats_values() if luau != null else {}
		var stat_lines := PackedStringArray()
		for key in ls:
			tokens[key] = ls[key]
			stat_lines.append("%s: %s" % [key, ls[key]])
		stats_label.text = "\n".join(stat_lines)
		if runtime != null:  # script değişkenleri de {ad} olarak kullanılabilir
			for k in runtime.vars:
				tokens[k] = ScriptRuntime.fmt(runtime.vars[k])
		for v in gui_views:
			v.refresh_text(tokens)
	if flash.color.a > 0.0:
		flash.color.a = maxf(0.0, flash.color.a - delta * 1.2)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.theme = UIKit.make_theme()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# En arkada: kamera bakış katmanı (joystick/zıpla yemediği her dokunuş)
	var look := TouchLayer.new()
	root.add_child(look)
	look.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	look.drag_one.connect(func(rel: Vector2) -> void: player.rotate_cam(rel))
	look.drag_two.connect(func(_pan: Vector2, zoom: float) -> void: player.zoom_cam(zoom))

	# Sol: joystick bölgesi (ekranın sol %45'i, üst %30 hariç)
	joy = JoystickScript.new()
	root.add_child(joy)
	joy.stick_moved.connect(func(v: Vector2) -> void: player.move_input = v)

	# Sağ alt: Zıpla
	var jump := TouchButton.new()
	jump.label = "Zıpla"
	jump.custom_minimum_size = Vector2(170, 170)
	root.add_child(jump)
	UIKit.place(jump, Control.PRESET_BOTTOM_RIGHT, 40)
	jump.pressed.connect(func() -> void: player.jump_held = true)
	jump.released.connect(func() -> void: player.jump_held = false)

	# Sağ üst: Stüdyo'ya dön
	var back := UIKit.btn("Menü", Vector2(150, 64))
	back.pressed.connect(func() -> void: Game.goto("res://scenes/main_menu.tscn"))
	mode_btn = UIKit.btn("", Vector2(250, 64))
	mode_btn.pressed.connect(_toggle_joystick_mode)
	var top_right := HBoxContainer.new()
	top_right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_right.add_theme_constant_override("separation", 8)
	top_right.add_child(mode_btn)
	top_right.add_child(back)
	root.add_child(top_right)
	UIKit.place(top_right, Control.PRESET_TOP_RIGHT, 12)

	# Sol üst: FPS (mobil optimizasyon takibi)
	fps_label = Label.new()
	var fps_panel := UIKit.panel_wrap(fps_label)
	root.add_child(fps_panel)
	UIKit.place(fps_panel, Control.PRESET_TOP_LEFT, 12)

	# Üst orta: ölüm sayacı + can çubuğu
	death_label = Label.new()
	death_label.text = "Ölüm: 0"
	death_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hp_bar = ProgressBar.new()
	hp_bar.custom_minimum_size = Vector2(320, 26)
	hp_bar.max_value = 100.0
	hp_bar.value = 100.0
	hp_bar.show_percentage = false
	var hp_bg := StyleBoxFlat.new()
	hp_bg.bg_color = Color(0, 0, 0, 0.55)
	hp_bg.set_corner_radius_all(13)
	hp_fill = StyleBoxFlat.new()
	hp_fill.bg_color = Color(0.2, 0.85, 0.3)
	hp_fill.set_corner_radius_all(13)
	hp_bar.add_theme_stylebox_override("background", hp_bg)
	hp_bar.add_theme_stylebox_override("fill", hp_fill)
	var hp_box := VBoxContainer.new()
	hp_box.add_theme_constant_override("separation", 6)
	hp_box.add_child(death_label)
	hp_box.add_child(hp_bar)
	var death_panel := UIKit.panel_wrap(hp_box)
	root.add_child(death_panel)
	UIKit.place(death_panel, Control.PRESET_CENTER_TOP, 12)

	# Ölüm efekti: kırmızı flaş + "Öldün!" yazısı (dokunuşları engellemez)
	flash = ColorRect.new()
	flash.color = Color(0.9, 0.05, 0.05, 0.0)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(flash)
	flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	big_label = Label.new()
	big_label.text = "Öldün!"
	big_label.add_theme_font_size_override("font_size", 80)
	big_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	big_label.modulate.a = 0.0
	root.add_child(big_label)
	big_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# Script çıktısı (print / warn / hata) ve leaderstats
	log_rt = RichTextLabel.new()
	log_rt.bbcode_enabled = true
	log_rt.scroll_active = false
	log_rt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	log_rt.add_theme_font_size_override("normal_font_size", 18)
	root.add_child(log_rt)
	UIKit.anchor_rect(log_rt, 0.01, 0.13, 0.55, 0.42)
	stats_label = Label.new()
	stats_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(stats_label)
	UIKit.anchor_rect(stats_label, 0.70, 0.14, 0.99, 0.40)
	toast_label = Label.new()  # say komutu mesajları
	toast_label.add_theme_font_size_override("font_size", 38)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	toast_label.modulate.a = 0.0
	root.add_child(toast_label)
	UIKit.anchor_rect(toast_label, 0.1, 0.22, 0.9, 0.34)
	player.died.connect(_on_died)
	player.checkpoint_reached.connect(_on_checkpoint)
	player.health_changed.connect(_on_health)
	_apply_joystick_mode()
	_build_gui(root)


## Joystick modu: yüzen (sol yarıda her yerde belirir) / sabit (sol altta hep aynı yer).
func _apply_joystick_mode() -> void:
	var fixed := Game.joystick_fixed
	joy.set("fixed", fixed)
	if fixed:
		UIKit.anchor_rect(joy, 0.03, 0.58, 0.27, 0.98)
	else:
		UIKit.anchor_rect(joy, 0.0, 0.3, 0.45, 1.0)
	mode_btn.text = "Joystick: " + ("Sabit" if fixed else "Yüzen")


func _toggle_joystick_mode() -> void:
	Game.joystick_fixed = not Game.joystick_fixed
	Game.save_settings()
	_apply_joystick_mode()


## StarterGui: Stüdyoda tasarlanan arayüz öğeleri, her şeyin üstünde (yalnızca düğmeler dokunuş alır).
func _build_gui(root: Control) -> void:
	var gui_root := Control.new()
	gui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(gui_root)
	gui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for d in Game.gui_items:
		var v := GuiItemView.new()
		gui_root.add_child(v)
		v.setup(d, false)
		v.action_requested.connect(_on_gui_action)
		gui_views.append(v)
	_layout_gui()
	get_viewport().size_changed.connect(_layout_gui)


func _layout_gui() -> void:
	var area := get_viewport().get_visible_rect().size
	for v in gui_views:
		v.apply_layout(area, 1.0)


func _on_gui_action(action: int) -> void:
	match action:
		1:
			player.checkpoint = Game.spawn_point
			player.respawn()
		2:
			Game.goto("res://scenes/main_menu.tscn")


func _on_luau_print(text: String, kind: int) -> void:
	print(text)
	var col := "#e6e6e6" if kind == 0 else ("#ffb347" if kind == 1 else "#ff6b6b")
	_log_lines.append("[color=%s]%s[/color]" % [col, text.replace("[", "[lb]")])
	while _log_lines.size() > 6:
		_log_lines.pop_front()
	log_rt.text = "\n".join(PackedStringArray(_log_lines))
	_log_timer = 10.0


func _toast(text: String, secs: float) -> void:
	toast_label.text = text
	toast_label.modulate.a = 1.0
	if _toast_tw != null:
		_toast_tw.kill()
	_toast_tw = create_tween()
	_toast_tw.tween_interval(maxf(secs, 0.2))
	_toast_tw.tween_property(toast_label, "modulate:a", 0.0, 0.5)


func _on_checkpoint() -> void:
	big_label.text = "Checkpoint!"
	big_label.modulate = Color(1.0, 0.95, 0.4, 1.0)
	create_tween().tween_property(big_label, "modulate:a", 0.0, 1.0)


func _on_died() -> void:
	big_label.text = "Öldün!"
	big_label.modulate = Color(1, 1, 1, 1)
	death_label.text = "Ölüm: %d" % player.deaths
	flash.color.a = 0.55
	big_label.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_property(big_label, "modulate:a", 0.0, 0.9)


func _on_health(current: float, maximum: float) -> void:
	hp_bar.max_value = maximum
	hp_bar.value = current
	hp_fill.bg_color = Color(0.9, 0.15, 0.15).lerp(Color(0.2, 0.85, 0.3), current / maximum)
	if current < _last_hp - 0.01 and current > 0.0:
		flash.color.a = maxf(flash.color.a, 0.22)  # hasar flaşı
	_last_hp = current
