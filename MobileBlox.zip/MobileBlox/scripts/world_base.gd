class_name WorldBase
extends Node3D
## Studio ve Play'in ortak tabanı: ışık, ortam, zemin, parça kökü.
## Alt sınıflar _ready() içinde build_world() çağırır.

var parts_root: Node3D
var animate_movers := false  # Play: hareketli platformlar AnimatableBody3D olsun


func build_world() -> void:
	_make_environment()
	_make_ground()
	parts_root = Node3D.new()
	parts_root.name = "Parts"
	add_child(parts_root)
	rebuild_parts()


func rebuild_parts() -> void:
	for c in parts_root.get_children():
		parts_root.remove_child(c)
		c.queue_free()
	for d in Game.world_parts:
		add_part(d)


func add_part(d: Dictionary) -> StaticBody3D:
	var dd := d.duplicate() if animate_movers else d
	var b := PartFactory.build(dd, animate_movers)
	parts_root.add_child(b)
	return b


func _make_environment() -> void:
	# Mobil için ucuz: düz renk gökyüzü + düz ortam ışığı (sky shader yok)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.53, 0.76, 0.95)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.78, 0.85)
	env.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.shadow_enabled = Game.shadows_enabled
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL  # tek cascade = ucuz
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)


func _make_ground() -> void:
	var g := StaticBody3D.new()
	g.name = "Ground"
	g.add_to_group("ground")

	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(240, 240)
	mi.mesh = pm

	# 2x2 piksel dama dokusu, NEAREST filtre = 1 birimlik kareler (bedava ızgara hissi)
	var img := Image.create_empty(2, 2, false, Image.FORMAT_RGB8)
	var a := Color(0.36, 0.62, 0.30)
	var b := Color(0.33, 0.58, 0.27)
	img.set_pixel(0, 0, a)
	img.set_pixel(1, 1, a)
	img.set_pixel(1, 0, b)
	img.set_pixel(0, 1, b)
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = ImageTexture.create_from_image(img)
	mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mat.uv1_scale = Vector3(120, 120, 1)
	mat.roughness = 1.0
	mi.material_override = mat
	g.add_child(mi)

	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(240, 2, 240)
	cs.shape = bs
	cs.position = Vector3(0, -1, 0)
	g.add_child(cs)
	add_child(g)
