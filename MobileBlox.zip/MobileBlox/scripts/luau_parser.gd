class_name LuauParser
extends RefCounted
## Luau/Lua ayrıştırıcı (özyinelemeli iniş). Çıktı: {"ok": bool, "ast": [...], "error": "Satır N: ..."}
## Desteklenen: local/function/if/while/for/repeat/return/break/continue, tablolar, method çağrısı (:),
## closure, vararg (...), bileşik atama (+= -= ..= vb.), if-ifadesi, basit tür notları (x: number).

# operatör: [sol öncelik, sağ öncelik]
const BIN_PRI := {
	"or": [1, 1], "and": [2, 2],
	"<": [3, 3], ">": [3, 3], "<=": [3, 3], ">=": [3, 3], "~=": [3, 3], "==": [3, 3],
	"..": [9, 8], "+": [10, 10], "-": [10, 10],
	"*": [11, 11], "/": [11, 11], "//": [11, 11], "%": [11, 11],
	"^": [14, 13],
}
const UNARY_PRI := 12
const COMPOUND := {"+=": "+", "-=": "-", "*=": "*", "/=": "/", "%=": "%", "^=": "^", "..=": "..", "//=": "//"}

var toks: Array = []
var p := 0
var error := ""


## Eski MobileBlox Script (onstart: / ontouch: / every N:) mı?
static func is_legacy(src: String) -> bool:
	var rx := RegEx.new()
	rx.compile("(?m)^\\s*(onstart|ontouch|every\\s+[0-9.]+)\\s*:")
	return rx.search(src) != null


static func parse(src: String) -> Dictionary:
	var lx := LuauLexer.tokenize(src)
	if str(lx["error"]) != "":
		return {"ok": false, "ast": [], "error": lx["error"]}
	var ps := LuauParser.new()
	ps.toks = lx["tokens"]
	var ast := ps.parse_chunk()
	if ps.error != "":
		return {"ok": false, "ast": [], "error": ps.error}
	return {"ok": true, "ast": ast, "error": ""}


## Yalnızca sözdizimi denetimi: hata metni ("" = hata yok)
static func check(src: String) -> String:
	return str(parse(src)["error"])


# ------------------------------------------------------------------ yardımcılar
func _peek() -> Dictionary:
	return toks[p]


func _next() -> Dictionary:
	var t: Dictionary = toks[p]
	if p < toks.size() - 1:
		p += 1
	return t


func _tok_text() -> String:
	return str(toks[p]["v"])


func _fail(msg: String) -> void:
	if error == "":
		error = "Satır %d: %s" % [int(toks[p]["l"]), msg]


func _is_op(v: String) -> bool:
	var t: Dictionary = toks[p]
	return t["t"] == "op" and t["v"] == v


func _is_kw(v: String) -> bool:
	var t: Dictionary = toks[p]
	return t["t"] == "kw" and t["v"] == v


func _accept_op(v: String) -> bool:
	if _is_op(v):
		_next()
		return true
	return false


func _accept_kw(v: String) -> bool:
	if _is_kw(v):
		_next()
		return true
	return false


func _expect_op(v: String) -> void:
	if not _accept_op(v):
		_fail("'%s' bekleniyordu ('%s' bulundu)" % [v, _tok_text()])


func _expect_kw(v: String) -> void:
	if not _accept_kw(v):
		_fail("'%s' bekleniyordu ('%s' bulundu)" % [v, _tok_text()])


func _expect_name() -> String:
	var t: Dictionary = toks[p]
	if t["t"] == "name":
		_next()
		return str(t["v"])
	_fail("isim bekleniyordu ('%s' bulundu)" % _tok_text())
	return ""


## Luau tür notunu atlar: number, string?, Vector3, Foo.Bar
func _skip_type() -> void:
	var t: Dictionary = toks[p]
	if t["t"] == "name" or (t["t"] == "kw" and t["v"] == "nil"):
		_next()
		while _is_op(".") and error == "":
			_next()
			_expect_name()
		_accept_op("?")
	else:
		_fail("tür adı bekleniyordu")


# ------------------------------------------------------------------ bloklar
func _block_end() -> bool:
	var t: Dictionary = toks[p]
	if t["t"] == "eof":
		return true
	if t["t"] == "kw":
		var v := str(t["v"])
		return v == "end" or v == "else" or v == "elseif" or v == "until"
	return false


func _block() -> Array:
	var stmts: Array = []
	while error == "" and not _block_end():
		var s := _statement()
		if error != "":
			break
		stmts.append(s)
		_accept_op(";")
	return stmts


func parse_chunk() -> Array:
	var b := _block()
	if error == "" and toks[p]["t"] != "eof":
		_fail("beklenmeyen '%s'" % _tok_text())
	return b


# ------------------------------------------------------------------ deyimler
func _statement() -> Dictionary:
	var t: Dictionary = toks[p]
	var line := int(t["l"])
	if t["t"] == "kw":
		match str(t["v"]):
			"local":
				_next()
				if _accept_kw("function"):
					var fname := _expect_name()
					var fn := _func_body(line, fname)
					return {"k": "localfunc", "name": fname, "fn": fn, "l": line}
				var names: Array = []
				names.append(_expect_name())
				if _accept_op(":"):
					_skip_type()
				while error == "" and _accept_op(","):
					names.append(_expect_name())
					if _accept_op(":"):
						_skip_type()
				var exprs: Array = []
				if _accept_op("="):
					exprs = _expr_list()
				return {"k": "local", "names": names, "exprs": exprs, "l": line}
			"function":
				_next()
				return _function_stmt(line)
			"if":
				return _if_stmt(line)
			"while":
				_next()
				var cond := _expr()
				_expect_kw("do")
				var wbody := _block()
				_expect_kw("end")
				return {"k": "while", "cond": cond, "body": wbody, "l": line}
			"for":
				return _for_stmt(line)
			"repeat":
				_next()
				var rbody := _block()
				_expect_kw("until")
				var rcond := _expr()
				return {"k": "repeat", "body": rbody, "cond": rcond, "l": line}
			"do":
				_next()
				var dbody := _block()
				_expect_kw("end")
				return {"k": "do", "body": dbody, "l": line}
			"return":
				_next()
				var rexprs: Array = []
				if not _block_end() and not _is_op(";"):
					rexprs = _expr_list()
				return {"k": "return", "exprs": rexprs, "l": line}
			"break":
				_next()
				return {"k": "break", "l": line}
			"continue":
				_next()
				return {"k": "continue", "l": line}
	return _expr_stmt(line)


func _func_body(line: int, fname: String, is_method: bool = false) -> Dictionary:
	_expect_op("(")
	var params: Array = []
	var vararg := false
	if is_method:
		params.append("self")
	if not _is_op(")"):
		while error == "":
			if _accept_op("..."):
				vararg = true
				break
			params.append(_expect_name())
			if _accept_op(":"):
				_skip_type()
			if not _accept_op(","):
				break
	_expect_op(")")
	if _accept_op(":"):
		_skip_type()
	var body := _block()
	_expect_kw("end")
	return {"k": "func", "params": params, "vararg": vararg, "body": body, "name": fname, "l": line}


func _function_stmt(line: int) -> Dictionary:
	var first := _expect_name()
	var target: Dictionary = {"k": "name", "n": first, "l": line}
	var full := first
	var is_method := false
	while error == "" and (_is_op(".") or _is_op(":")):
		var colon := _is_op(":")
		_next()
		var key := _expect_name()
		target = {"k": "index", "o": target, "key": {"k": "str", "v": key}, "l": line}
		full += (":" if colon else ".") + key
		if colon:
			is_method = true
			break
	var fn := _func_body(line, full, is_method)
	return {"k": "assign", "targets": [target], "exprs": [fn], "l": line}


func _if_stmt(line: int) -> Dictionary:
	_next()
	var conds: Array = []
	var blocks: Array = []
	conds.append(_expr())
	_expect_kw("then")
	blocks.append(_block())
	var els: Array = []
	while error == "":
		if _accept_kw("elseif"):
			conds.append(_expr())
			_expect_kw("then")
			blocks.append(_block())
		elif _accept_kw("else"):
			els = _block()
			break
		else:
			break
	_expect_kw("end")
	return {"k": "if", "conds": conds, "blocks": blocks, "else": els, "l": line}


func _for_stmt(line: int) -> Dictionary:
	_next()
	var n1 := _expect_name()
	if _accept_op("="):
		var a := _expr()
		_expect_op(",")
		var b := _expr()
		var c: Dictionary = {}
		if _accept_op(","):
			c = _expr()
		_expect_kw("do")
		var body := _block()
		_expect_kw("end")
		return {"k": "fornum", "var": n1, "a": a, "b": b, "c": c, "body": body, "l": line}
	var names: Array = [n1]
	while error == "" and _accept_op(","):
		names.append(_expect_name())
	_expect_kw("in")
	var exprs := _expr_list()
	_expect_kw("do")
	var body2 := _block()
	_expect_kw("end")
	return {"k": "forin", "names": names, "exprs": exprs, "body": body2, "l": line}


func _expr_stmt(line: int) -> Dictionary:
	var e := _suffixed()
	if error != "":
		return {"k": "nop", "l": line}
	var t: Dictionary = toks[p]
	if t["t"] == "op" and (t["v"] == "=" or t["v"] == ","):
		var targets: Array = [e]
		while error == "" and _accept_op(","):
			targets.append(_suffixed())
		_expect_op("=")
		var exprs := _expr_list()
		for tg in targets:
			if tg["k"] != "name" and tg["k"] != "index":
				_fail("atama hedefi geçersiz")
		return {"k": "assign", "targets": targets, "exprs": exprs, "l": line}
	if t["t"] == "op" and COMPOUND.has(str(t["v"])):
		_next()
		var rhs := _expr()
		if e["k"] != "name" and e["k"] != "index":
			_fail("atama hedefi geçersiz")
		return {"k": "opassign", "t": e, "op": COMPOUND[str(t["v"])], "e": rhs, "l": line}
	if e["k"] != "call" and e["k"] != "mcall":
		_fail("bu ifade tek başına bir komut olamaz (çağrı ya da atama bekleniyordu)")
	return {"k": "callstmt", "e": e, "l": line}


# ------------------------------------------------------------------ ifadeler
func _expr_list() -> Array:
	var out: Array = [_expr()]
	while error == "" and _accept_op(","):
		out.append(_expr())
	return out


func _expr() -> Dictionary:
	return _subexpr(0)


func _subexpr(limit: int) -> Dictionary:
	var t: Dictionary = toks[p]
	var line := int(t["l"])
	var left: Dictionary
	if (t["t"] == "kw" and t["v"] == "not") or (t["t"] == "op" and (t["v"] == "-" or t["v"] == "#")):
		_next()
		var operand := _subexpr(UNARY_PRI)
		left = {"k": "un", "op": str(t["v"]), "e": operand, "l": line}
	else:
		left = _simple()
	while error == "":
		var ot: Dictionary = toks[p]
		if not (ot["t"] == "op" or ot["t"] == "kw"):
			break
		var opv := str(ot["v"])
		if not BIN_PRI.has(opv):
			break
		var pri: Array = BIN_PRI[opv]
		if int(pri[0]) <= limit:
			break
		_next()
		var right := _subexpr(int(pri[1]))
		var kind := "bin"
		if opv == "and":
			kind = "and"
		elif opv == "or":
			kind = "or"
		left = {"k": kind, "op": opv, "l": int(ot["l"]), "a": left, "b": right}
	return left


func _simple() -> Dictionary:
	var t: Dictionary = toks[p]
	var line := int(t["l"])
	var tt := str(t["t"])
	if tt == "num":
		_next()
		return {"k": "num", "v": t["v"], "l": line}
	if tt == "str":
		_next()
		return {"k": "str", "v": t["v"], "l": line}
	if tt == "kw":
		var v := str(t["v"])
		if v == "nil":
			_next()
			return {"k": "nil", "l": line}
		if v == "true":
			_next()
			return {"k": "true", "l": line}
		if v == "false":
			_next()
			return {"k": "false", "l": line}
		if v == "function":
			_next()
			return _func_body(line, "anonim")
		if v == "if":
			return _ifexpr(line)
	if tt == "op":
		if t["v"] == "...":
			_next()
			return {"k": "vararg", "l": line}
		if t["v"] == "{":
			return _table()
	return _suffixed()


func _ifexpr(line: int) -> Dictionary:
	_next()  # 'if' ya da 'elseif'
	var cond := _expr()
	_expect_kw("then")
	var a := _expr()
	var b: Dictionary
	if _is_kw("elseif"):
		b = _ifexpr(line)
	else:
		_expect_kw("else")
		b = _expr()
	return {"k": "ifexpr", "cond": cond, "a": a, "b": b, "l": line}


func _suffixed() -> Dictionary:
	var t: Dictionary = toks[p]
	var line := int(t["l"])
	var e: Dictionary
	if t["t"] == "name":
		_next()
		e = {"k": "name", "n": str(t["v"]), "l": line}
	elif t["t"] == "op" and t["v"] == "(":
		_next()
		var inner := _expr()
		_expect_op(")")
		e = {"k": "paren", "e": inner, "l": line}
	else:
		_fail("ifade bekleniyordu ('%s' bulundu)" % _tok_text())
		return {"k": "nil", "l": line}
	while error == "":
		var c: Dictionary = toks[p]
		var cl := int(c["l"])
		if c["t"] == "op" and c["v"] == ".":
			_next()
			var key := _expect_name()
			e = {"k": "index", "o": e, "key": {"k": "str", "v": key}, "l": cl}
		elif c["t"] == "op" and c["v"] == "[":
			_next()
			var k := _expr()
			_expect_op("]")
			e = {"k": "index", "o": e, "key": k, "l": cl}
		elif c["t"] == "op" and c["v"] == ":":
			_next()
			var m := _expect_name()
			var margs := _call_args()
			e = {"k": "mcall", "o": e, "m": m, "args": margs, "l": cl}
		elif (c["t"] == "op" and (c["v"] == "(" or c["v"] == "{")) or c["t"] == "str":
			var cargs := _call_args()
			e = {"k": "call", "f": e, "args": cargs, "l": cl}
		else:
			break
	return e


func _call_args() -> Array:
	var t: Dictionary = toks[p]
	if t["t"] == "str":
		_next()
		return [{"k": "str", "v": t["v"], "l": int(t["l"])}]
	if t["t"] == "op" and t["v"] == "{":
		return [_table()]
	_expect_op("(")
	var args: Array = []
	if not _is_op(")"):
		args = _expr_list()
	_expect_op(")")
	return args


func _table() -> Dictionary:
	var line := int(toks[p]["l"])
	_expect_op("{")
	var items: Array = []
	while error == "" and not _is_op("}"):
		var t: Dictionary = toks[p]
		if _is_op("["):
			_next()
			var k := _expr()
			_expect_op("]")
			_expect_op("=")
			items.append({"kind": "keyed", "key": k, "val": _expr()})
		elif t["t"] == "name" and toks[p + 1]["t"] == "op" and toks[p + 1]["v"] == "=":
			var nm := str(t["v"])
			_next()
			_next()
			items.append({"kind": "keyed", "key": {"k": "str", "v": nm}, "val": _expr()})
		else:
			items.append({"kind": "pos", "val": _expr()})
		if not (_accept_op(",") or _accept_op(";")):
			break
	_expect_op("}")
	return {"k": "table", "items": items, "l": line}
