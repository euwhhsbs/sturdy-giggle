class_name LuaThread
extends RefCounted
## Bir çalışma dizisi (coroutine) bağlamı: hata durumu, satır, adım sayacı.

var has_err := false
var err_msg := ""  # "Satır N: ..." (rapor için)
var err_raw: Variant = null  # pcall'a dönen ham değer
var line := 0
var steps := 0
var depth := 0
