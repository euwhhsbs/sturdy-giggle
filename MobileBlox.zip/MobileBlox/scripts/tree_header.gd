class_name TreeHeader
extends Button
## Gezgin/Özellikler başlık satırı: solda açılır ok (▶/▼), isteğe bağlı ikon, metin Button'un kendisidir.

var expanded := true:
	set(v):
		expanded = v
		queue_redraw()
var icon_name := ""


static func make(title: String, icon: String = "", bar: bool = false) -> TreeHeader:
	var b := TreeHeader.new()
	b.text = title
	b.icon_name = icon
	var left := 46 if icon != "" else 28
	var bg := Color(0.13, 0.13, 0.13) if bar else Color(0, 0, 0, 0)
	var n := UIKit.flat_box(bg, 0, Color(0, 0, 0, 0), 0, 4)
	n.content_margin_left = left
	var h := UIKit.flat_box(Color(1, 1, 1, 0.08), 0, Color(0, 0, 0, 0), 0, 4)
	h.content_margin_left = left
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", h)
	b.add_theme_stylebox_override("hover_pressed", h)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	return b


func _init() -> void:
	focus_mode = Control.FOCUS_NONE
	alignment = HORIZONTAL_ALIGNMENT_LEFT
	clip_text = true
	custom_minimum_size = Vector2(0, 34)


func _draw() -> void:
	var cy := size.y * 0.5
	var gray := Color(0.70, 0.70, 0.72)
	if expanded:
		draw_colored_polygon(PackedVector2Array([Vector2(8, cy - 3), Vector2(20, cy - 3), Vector2(14, cy + 5)]), gray)
	else:
		draw_colored_polygon(PackedVector2Array([Vector2(10, cy - 6), Vector2(10, cy + 6), Vector2(18, cy)]), gray)
	if icon_name != "":
		StudioIcon.draw_icon(self, icon_name, Rect2(Vector2(24, cy - 10), Vector2(20, 20)), StudioIcon.default_color(icon_name))
