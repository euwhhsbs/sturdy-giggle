class_name RbxInst
extends RefCounted
## Roblox Instance karşılığı: parça, oyuncu, karakter, Humanoid, servis, klasör, değer nesneleri...
## role: "part" | "root" | "humanoid" | "character" | "player" | "players" | "workspace" | "service" | "inst"

var cls := "Instance"
var name := ""
var role := "inst"
var parent: RbxInst = null
var children: Array = []
var node: Node3D = null  # parça düğümü (role == "part")
var props: Dictionary = {}
var attrs: Dictionary = {}
var signals: Dictionary = {}
var destroyed := false
