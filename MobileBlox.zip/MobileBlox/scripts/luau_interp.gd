class_name LuauInterp
extends Node
## Luau/Lua yorumlayıcısı (AST dolaşan). await ile coroutine destekler: wait(), olaylar, task.* çalışır.
## Hatalar GDScript istisnası değil, LuaThread.has_err bayrağıyla taşınır; pcall bu bayrağı yakalar.

signal printed(text: String, kind: int)  # kind: 0 bilgi, 1 uyarı, 2 hata

const MAX_DEPTH := 100
const CTL_BREAK := {"c": "break"}
const CTL_CONTINUE := {"c": "continue"}

var G: Dictionary = {}
var bridge = null  # RbxBridge (Roblox API köprüsü)
var string_lib: LuaTable = LuaTable.new()
var _waiters: Array = []
var _rng := RandomNumberGenerator.new()
var _pairs_fn: LuaFunc
var _ipairs_fn: LuaFunc
var _elapsed := 0.0


func _process(delta: float) -> void:
	_elapsed += delta
	var i := _waiters.size() - 1
	while i >= 0:
		if i < _waiters.size():
			var w: LuaWait = _waiters[i]
			w.elapsed += delta
			w.remaining -= delta
			if w.remaining <= 0.0:
				_waiters.remove_at(i)
				w.done.emit(w.elapsed)
		i -= 1
	if bridge != null:
		bridge.tick(delta)


# ------------------------------------------------------------------ genel yardımcılar
func arg(a: Array, i: int) -> Variant:
	return a[i] if i < a.size() else null


func is_num(v: Variant) -> bool:
	return v is int or v is float


func num(v: Variant) -> float:
	if v is float:
		return v
	if v is int:
		return float(v)
	if v is String:
		return v.to_float()
	return 0.0


func truthy(v: Variant) -> bool:
	if v == null:
		return false
	if v is bool:
		return v
	return true


func type_name(v: Variant) -> String:
	if v == null:
		return "nil"
	if v is bool:
		return "boolean"
	if is_num(v):
		return "number"
	if v is String:
		return "string"
	if v is LuaTable:
		return "table"
	if v is LuaFunc:
		return "function"
	return "userdata"


func typeof_name(v: Variant) -> String:
	if v is Vector3:
		return "Vector3"
	if v is Color:
		return "Color3"
	if v is Transform3D:
		return "CFrame"
	if v is RbxInst:
		return "Instance"
	if v is RbxSignal:
		return "RBXScriptSignal"
	if v is RbxConn:
		return "RBXScriptConnection"
	return type_name(v)


func fmt_num(f: float) -> String:
	if is_inf(f):
		return "inf" if f > 0.0 else "-inf"
	if is_nan(f):
		return "nan"
	if f == floorf(f) and absf(f) < 1.0e15:
		return str(int(f))
	return str(snappedf(f, 1.0e-10))


func tostr(v: Variant) -> String:
	if v == null:
		return "nil"
	if v is bool:
		return "true" if v else "false"
	if v is int:
		return str(v)
	if v is float:
		return fmt_num(v)
	if v is String:
		return v
	if v is LuaTable:
		return "table: 0x%x" % (v as Object).get_instance_id()
	if v is LuaFunc:
		return "function: 0x%x" % (v as Object).get_instance_id()
	if v is RbxInst:
		return (v as RbxInst).name
	if v is Vector3:
		return "%s, %s, %s" % [fmt_num(v.x), fmt_num(v.y), fmt_num(v.z)]
	if v is Color:
		return "%s, %s, %s" % [fmt_num(v.r), fmt_num(v.g), fmt_num(v.b)]
	return str(v)


## Hata kaydı: ilk hata saklanır; throw sonrası çağıranlar has_err bayrağına bakıp geri döner.
func throw(th: LuaThread, msg: String) -> Variant:
	if not th.has_err:
		th.has_err = true
		th.err_raw = msg
		th.err_msg = "Satır %d: %s" % [th.line, msg]
	return null


func _eq(a: Variant, b: Variant) -> bool:
	if a == null or b == null:
		return a == null and b == null
	if is_num(a) and is_num(b):
		return float(a) == float(b)
	if a is String and b is String:
		return a == b
	if a is bool or b is bool:
		return a is bool and b is bool and a == b
	if a is Object or b is Object:
		return is_same(a, b)
	return a == b


func _lt(a: Variant, b: Variant) -> bool:
	if is_num(a) and is_num(b):
		return float(a) < float(b)
	if a is String and b is String:
		return a < b
	return false


func _fn(nm: String, c: Callable) -> LuaFunc:
	var f := LuaFunc.new()
	f.name = nm
	f.native = c
	return f


func mk_lib(entries: Dictionary) -> LuaTable:
	var t := LuaTable.new()
	for k in entries:
		t.set_v(k, _fn(str(k), entries[k]))
	return t


# ------------------------------------------------------------------ çalıştırma
func run_chunk(ast: Array, script_inst: Variant, label: String) -> void:
	var th := LuaThread.new()
	var sc := LuaScope.new()
	sc.vars["script"] = script_inst
	await _exec_block(ast, sc, th)
	if th.has_err:
		printed.emit("[%s] %s" % [label, th.err_msg], 2)


func spawn_fn(f: Variant, args: Array) -> void:
	var th := LuaThread.new()
	await call_fn(f, args, th)
	if th.has_err:
		printed.emit(th.err_msg, 2)


func wait_seconds(t: float) -> float:
	var w := LuaWait.new()
	w.remaining = maxf(t, 0.0167)
	_waiters.append(w)
	var e: Variant = await w.done
	return float(e)


func call_fn(f: Variant, args: Array, th: LuaThread) -> Array:
	if not (f is LuaFunc):
		if f is LuaTable and (f as LuaTable).meta != null:
			var cm: Variant = (f as LuaTable).meta.get_v("__call")
			if cm is LuaFunc:
				var cargs: Array = [f]
				cargs.append_array(args)
				return await call_fn(cm, cargs, th)
		throw(th, "attempt to call a %s value" % type_name(f))
		return []
	var lf: LuaFunc = f
	if lf.native.is_valid():
		var r: Variant = await lf.native.call(args, th)
		if r is Array:
			return r
		if r == null:
			return []
		return [r]
	th.depth += 1
	if th.depth > MAX_DEPTH:
		throw(th, "stack overflow (çok derin özyineleme)")
		th.depth -= 1
		return []
	var sc := LuaScope.new(lf.scope)
	var np := lf.params.size()
	for i in np:
		sc.vars[lf.params[i]] = args[i] if i < args.size() else null
	sc.varargs = args.slice(np) if lf.vararg else []
	var ctl: Variant = await _exec_block(lf.body, sc, th)
	th.depth -= 1
	if ctl != null and ctl["c"] == "return":
		return ctl["v"]
	return []


func call_method(obj: Variant, nm: String, args: Array, th: LuaThread) -> Array:
	if obj == null:
		throw(th, "attempt to index a nil value (method '%s')" % nm)
		return []
	var full: Array = [obj]
	full.append_array(args)
	if obj is String:
		var sf: Variant = string_lib.get_v(nm)
		if sf == null:
			throw(th, "'%s' string metodu yok" % nm)
			return []
		return await call_fn(sf, full, th)
	if obj is LuaTable:
		var f: Variant = await index_value(obj, nm, th)
		return await call_fn(f, full, th)
	if bridge != null:
		return await bridge.method(obj, nm, args, th)
	throw(th, "attempt to call method '%s' on a %s value" % [nm, type_name(obj)])
	return []


func index_value(obj: Variant, key: Variant, th: LuaThread) -> Variant:
	if obj is LuaTable:
		var t: LuaTable = obj
		var v: Variant = t.get_v(key)
		if v == null and t.meta != null:
			var idx: Variant = t.meta.get_v("__index")
			if idx is LuaTable:
				return await index_value(idx, key, th)
			if idx is LuaFunc:
				var r: Array = await call_fn(idx, [t, key], th)
				return r[0] if r.size() > 0 else null
		return v
	if obj == null:
		throw(th, "attempt to index a nil value (field '%s')" % tostr(key))
		return null
	if obj is String:
		return string_lib.get_v(key)
	if bridge != null:
		return bridge.index(obj, key, th)
	return null


func set_index(obj: Variant, key: Variant, val: Variant, th: LuaThread) -> void:
	if obj is LuaTable:
		var t: LuaTable = obj
		if t.meta != null and t.get_v(key) == null:
			var ni: Variant = t.meta.get_v("__newindex")
			if ni is LuaFunc:
				await call_fn(ni, [t, key, val], th)
				return
			if ni is LuaTable:
				await set_index(ni, key, val, th)
				return
		if key == null:
			throw(th, "table index is nil")
			return
		t.set_v(key, val)
	elif obj == null:
		throw(th, "attempt to index a nil value (field '%s')" % tostr(key))
	elif bridge != null:
		bridge.set_prop(obj, key, val, th)
	else:
		throw(th, "bu değere atama yapılamaz")


# ------------------------------------------------------------------ deyimler
func _exec_block(stmts: Array, sc: LuaScope, th: LuaThread) -> Variant:
	for s in stmts:
		if th.has_err or not is_inside_tree():
			return null
		th.steps += 1
		if th.steps % 3000 == 0:
			await get_tree().process_frame  # sonsuz döngü oyunu dondurmasın
		th.line = int(s["l"])
		var ctl: Variant = await _exec(s, sc, th)
		if ctl != null:
			return ctl
	return null


func _exec(s: Dictionary, sc: LuaScope, th: LuaThread) -> Variant:
	match str(s["k"]):
		"local":
			var vals: Array = await _eval_list(s["exprs"], sc, th)
			if th.has_err:
				return null
			var names: Array = s["names"]
			for i in names.size():
				sc.vars[names[i]] = vals[i] if i < vals.size() else null
		"localfunc":
			sc.vars[s["name"]] = null
			sc.vars[s["name"]] = await _eval(s["fn"], sc, th)
		"assign":
			var rhs: Array = await _eval_list(s["exprs"], sc, th)
			if th.has_err:
				return null
			var targets: Array = s["targets"]
			for i in targets.size():
				await _assign(targets[i], rhs[i] if i < rhs.size() else null, sc, th)
				if th.has_err:
					return null
		"opassign":
			var cur: Variant = await _eval(s["t"], sc, th)
			if th.has_err:
				return null
			var r: Variant = await _eval(s["e"], sc, th)
			if th.has_err:
				return null
			var nv: Variant = _binop(str(s["op"]), cur, r, th)
			if th.has_err:
				return null
			await _assign(s["t"], nv, sc, th)
		"callstmt":
			await _eval_multi(s["e"], sc, th)
		"do":
			return await _exec_block(s["body"], LuaScope.new(sc), th)
		"while":
			while true:
				var c: Variant = await _eval(s["cond"], sc, th)
				if th.has_err or not truthy(c):
					break
				var ctl: Variant = await _exec_block(s["body"], LuaScope.new(sc), th)
				if th.has_err:
					return null
				if ctl != null:
					if ctl["c"] == "break":
						break
					if ctl["c"] == "return":
						return ctl
		"repeat":
			while true:
				var rsc := LuaScope.new(sc)
				var ctl2: Variant = await _exec_block(s["body"], rsc, th)
				if th.has_err:
					return null
				if ctl2 != null:
					if ctl2["c"] == "break":
						break
					if ctl2["c"] == "return":
						return ctl2
				var uc: Variant = await _eval(s["cond"], rsc, th)
				if th.has_err or truthy(uc):
					break
		"if":
			var conds: Array = s["conds"]
			for i in conds.size():
				var cv: Variant = await _eval(conds[i], sc, th)
				if th.has_err:
					return null
				if truthy(cv):
					return await _exec_block(s["blocks"][i], LuaScope.new(sc), th)
			return await _exec_block(s["else"], LuaScope.new(sc), th)
		"fornum":
			var a: Variant = await _eval(s["a"], sc, th)
			var b: Variant = await _eval(s["b"], sc, th)
			var stp: Variant = 1.0
			if not (s["c"] as Dictionary).is_empty():
				stp = await _eval(s["c"], sc, th)
			if th.has_err:
				return null
			if not (is_num(a) and is_num(b) and is_num(stp)):
				throw(th, "'for' başlangıç/bitiş/adım sayı olmalı")
				return null
			var x := float(a)
			var lim := float(b)
			var st := float(stp)
			if st == 0.0:
				throw(th, "'for' adımı 0 olamaz")
				return null
			while (st > 0.0 and x <= lim) or (st < 0.0 and x >= lim):
				var fsc := LuaScope.new(sc)
				fsc.vars[s["var"]] = x
				var ctl3: Variant = await _exec_block(s["body"], fsc, th)
				if th.has_err:
					return null
				if ctl3 != null:
					if ctl3["c"] == "break":
						break
					if ctl3["c"] == "return":
						return ctl3
				x += st
		"forin":
			return await _exec_forin(s, sc, th)
		"return":
			var rv: Array = await _eval_list(s["exprs"], sc, th)
			if th.has_err:
				return null
			return {"c": "return", "v": rv}
		"break":
			return CTL_BREAK
		"continue":
			return CTL_CONTINUE
	return null


func _exec_forin(s: Dictionary, sc: LuaScope, th: LuaThread) -> Variant:
	var vals: Array = await _eval_list(s["exprs"], sc, th)
	if th.has_err:
		return null
	var f: Variant = vals[0] if vals.size() > 0 else null
	var st: Variant = vals[1] if vals.size() > 1 else null
	var cv: Variant = vals[2] if vals.size() > 2 else null
	var names: Array = s["names"]
	if f is LuaFunc and f == _pairs_fn and st is LuaTable:
		var tt: LuaTable = st
		for k in tt.keys():
			var v: Variant = tt.get_v(k)
			if v == null:
				continue
			var sc2 := LuaScope.new(sc)
			sc2.vars[names[0]] = k
			if names.size() > 1:
				sc2.vars[names[1]] = v
			var ctl: Variant = await _exec_block(s["body"], sc2, th)
			if th.has_err:
				return null
			if ctl != null:
				if ctl["c"] == "break":
					break
				if ctl["c"] == "return":
					return ctl
		return null
	if f is LuaFunc and f == _ipairs_fn and st is LuaTable:
		var it: LuaTable = st
		var i := 1
		while true:
			var v2: Variant = it.get_v(i)
			if v2 == null:
				break
			var sc3 := LuaScope.new(sc)
			sc3.vars[names[0]] = i
			if names.size() > 1:
				sc3.vars[names[1]] = v2
			var ctl2: Variant = await _exec_block(s["body"], sc3, th)
			if th.has_err:
				return null
			if ctl2 != null:
				if ctl2["c"] == "break":
					break
				if ctl2["c"] == "return":
					return ctl2
			i += 1
		return null
	# genel yineleyici: f(state, control) nil dönene kadar
	while true:
		var rets: Array = await call_fn(f, [st, cv], th)
		if th.has_err:
			return null
		if rets.is_empty() or rets[0] == null:
			break
		cv = rets[0]
		var sc4 := LuaScope.new(sc)
		for j in names.size():
			sc4.vars[names[j]] = rets[j] if j < rets.size() else null
		var ctl3: Variant = await _exec_block(s["body"], sc4, th)
		if th.has_err:
			return null
		if ctl3 != null:
			if ctl3["c"] == "break":
				break
			if ctl3["c"] == "return":
				return ctl3
	return null


func _assign(target: Dictionary, val: Variant, sc: LuaScope, th: LuaThread) -> void:
	if target["k"] == "name":
		var holder := sc.find(str(target["n"]))
		if holder != null:
			holder.vars[target["n"]] = val
		else:
			G[target["n"]] = val
		return
	var o: Variant = await _eval(target["o"], sc, th)
	if th.has_err:
		return
	var k: Variant = await _eval(target["key"], sc, th)
	if th.has_err:
		return
	th.line = int(target["l"])
	await set_index(o, k, val, th)


# ------------------------------------------------------------------ ifadeler
func _eval_list(exprs: Array, sc: LuaScope, th: LuaThread) -> Array:
	var out: Array = []
	for i in exprs.size():
		if th.has_err:
			return out
		if i == exprs.size() - 1:
			var m: Array = await _eval_multi(exprs[i], sc, th)
			out.append_array(m)
		else:
			out.append(await _eval(exprs[i], sc, th))
	return out


func _eval_multi(n: Dictionary, sc: LuaScope, th: LuaThread) -> Array:
	var k := str(n["k"])
	if k == "call" or k == "mcall":
		return await _call_node(n, sc, th)
	if k == "vararg":
		return sc.varargs.duplicate()
	return [await _eval(n, sc, th)]


func _call_node(n: Dictionary, sc: LuaScope, th: LuaThread) -> Array:
	if n["k"] == "call":
		var f: Variant = await _eval(n["f"], sc, th)
		if th.has_err:
			return []
		var args: Array = await _eval_list(n["args"], sc, th)
		if th.has_err:
			return []
		th.line = int(n["l"])
		return await call_fn(f, args, th)
	var o: Variant = await _eval(n["o"], sc, th)
	if th.has_err:
		return []
	var margs: Array = await _eval_list(n["args"], sc, th)
	if th.has_err:
		return []
	th.line = int(n["l"])
	return await call_method(o, str(n["m"]), margs, th)


func _eval(n: Dictionary, sc: LuaScope, th: LuaThread) -> Variant:
	match str(n["k"]):
		"nil":
			return null
		"true":
			return true
		"false":
			return false
		"num", "str":
			return n["v"]
		"vararg":
			return sc.varargs[0] if sc.varargs.size() > 0 else null
		"name":
			var holder := sc.find(str(n["n"]))
			if holder != null:
				return holder.vars[n["n"]]
			return G.get(n["n"])
		"paren":
			return await _eval(n["e"], sc, th)
		"func":
			var f := LuaFunc.new()
			f.name = str(n.get("name", "?"))
			f.params = n["params"]
			f.vararg = n["vararg"]
			f.body = n["body"]
			f.scope = sc
			return f
		"index":
			var o: Variant = await _eval(n["o"], sc, th)
			if th.has_err:
				return null
			var k: Variant = await _eval(n["key"], sc, th)
			if th.has_err:
				return null
			th.line = int(n["l"])
			return await index_value(o, k, th)
		"call", "mcall":
			var r: Array = await _call_node(n, sc, th)
			return r[0] if r.size() > 0 else null
		"bin":
			var a: Variant = await _eval(n["a"], sc, th)
			if th.has_err:
				return null
			var b: Variant = await _eval(n["b"], sc, th)
			if th.has_err:
				return null
			th.line = int(n["l"])
			return _binop(str(n["op"]), a, b, th)
		"and":
			var la: Variant = await _eval(n["a"], sc, th)
			if th.has_err or not truthy(la):
				return la
			return await _eval(n["b"], sc, th)
		"or":
			var lo: Variant = await _eval(n["a"], sc, th)
			if th.has_err or truthy(lo):
				return lo
			return await _eval(n["b"], sc, th)
		"un":
			var u: Variant = await _eval(n["e"], sc, th)
			if th.has_err:
				return null
			th.line = int(n["l"])
			return _unop(str(n["op"]), u, th)
		"ifexpr":
			var c: Variant = await _eval(n["cond"], sc, th)
			if th.has_err:
				return null
			if truthy(c):
				return await _eval(n["a"], sc, th)
			return await _eval(n["b"], sc, th)
		"table":
			var t := LuaTable.new()
			var pos := 1
			var items: Array = n["items"]
			for i in items.size():
				var it: Dictionary = items[i]
				if it["kind"] == "keyed":
					var key: Variant = await _eval(it["key"], sc, th)
					var val: Variant = await _eval(it["val"], sc, th)
					if th.has_err:
						return null
					if key == null:
						throw(th, "table index is nil")
						return null
					t.set_v(key, val)
				elif i == items.size() - 1:
					var vs: Array = await _eval_multi(it["val"], sc, th)
					for v in vs:
						t.set_v(pos, v)
						pos += 1
				else:
					var v2: Variant = await _eval(it["val"], sc, th)
					t.set_v(pos, v2)
					pos += 1
				if th.has_err:
					return null
			return t
	return null


func _binop(op: String, a: Variant, b: Variant, th: LuaThread) -> Variant:
	match op:
		"==":
			return _eq(a, b)
		"~=":
			return not _eq(a, b)
		"..":
			if (a is String or is_num(a)) and (b is String or is_num(b)):
				return tostr(a) + tostr(b)
			throw(th, "attempt to concatenate a %s value" % type_name(b if (a is String or is_num(a)) else a))
			return null
		"<", "<=", ">", ">=":
			if is_num(a) and is_num(b):
				var x := float(a)
				var y := float(b)
				match op:
					"<":
						return x < y
					"<=":
						return x <= y
					">":
						return x > y
					_:
						return x >= y
			if a is String and b is String:
				match op:
					"<":
						return a < b
					"<=":
						return a <= b
					">":
						return a > b
					_:
						return a >= b
			throw(th, "attempt to compare %s with %s" % [type_name(a), type_name(b)])
			return null
	# aritmetik
	var an := is_num(a) or (a is String and a.is_valid_float())
	var bn := is_num(b) or (b is String and b.is_valid_float())
	if an and bn:
		var p := num(a)
		var q := num(b)
		match op:
			"+":
				return p + q
			"-":
				return p - q
			"*":
				return p * q
			"/":
				return p / q
			"%":
				return p - floorf(p / q) * q
			"^":
				return pow(p, q)
			"//":
				return floorf(p / q)
	if bridge != null:
		return bridge.arith(op, a, b, th)
	throw(th, "attempt to perform arithmetic on a %s value" % type_name(a if not an else b))
	return null


func _unop(op: String, v: Variant, th: LuaThread) -> Variant:
	match op:
		"not":
			return not truthy(v)
		"-":
			if is_num(v):
				return -float(v)
			if v is Vector3:
				return -v
			throw(th, "attempt to perform arithmetic on a %s value" % type_name(v))
			return null
		"#":
			if v is String:
				return v.length()
			if v is LuaTable:
				return (v as LuaTable).length()
			throw(th, "attempt to get length of a %s value" % type_name(v))
			return null
	return null


# ------------------------------------------------------------------ standart kütüphane
func install_globals() -> void:
	_rng.randomize()
	G["print"] = _fn("print", _n_print)
	G["warn"] = _fn("warn", _n_warn)
	G["error"] = _fn("error", _n_error)
	G["assert"] = _fn("assert", _n_assert)
	G["pcall"] = _fn("pcall", _n_pcall)
	G["type"] = _fn("type", _n_type)
	G["typeof"] = _fn("typeof", _n_typeof)
	G["tostring"] = _fn("tostring", _n_tostring)
	G["tonumber"] = _fn("tonumber", _n_tonumber)
	G["select"] = _fn("select", _n_select)
	G["unpack"] = _fn("unpack", _n_unpack)
	G["rawget"] = _fn("rawget", _n_rawget)
	G["rawset"] = _fn("rawset", _n_rawset)
	G["rawequal"] = _fn("rawequal", _n_rawequal)
	G["setmetatable"] = _fn("setmetatable", _n_setmetatable)
	G["getmetatable"] = _fn("getmetatable", _n_getmetatable)
	_pairs_fn = _fn("next", _n_next)
	_ipairs_fn = _fn("ipairs_iter", _n_ipairs_iter)
	G["next"] = _pairs_fn
	G["pairs"] = _fn("pairs", _n_pairs)
	G["ipairs"] = _fn("ipairs", _n_ipairs)
	G["wait"] = _fn("wait", _n_wait)
	G["spawn"] = _fn("spawn", _n_spawn)
	G["delay"] = _fn("delay", _n_delay)
	G["tick"] = _fn("tick", _n_tick)
	G["time"] = _fn("time", _n_time)
	G["task"] = mk_lib({"wait": _n_wait, "spawn": _n_spawn, "defer": _n_spawn, "delay": _n_delay})

	var m := mk_lib({
		"floor": _math_op.bind("floor"), "ceil": _math_op.bind("ceil"), "abs": _math_op.bind("abs"),
		"sqrt": _math_op.bind("sqrt"), "sin": _math_op.bind("sin"), "cos": _math_op.bind("cos"),
		"tan": _math_op.bind("tan"), "asin": _math_op.bind("asin"), "acos": _math_op.bind("acos"),
		"atan": _math_op.bind("atan"), "atan2": _math_op.bind("atan2"), "rad": _math_op.bind("rad"),
		"deg": _math_op.bind("deg"), "exp": _math_op.bind("exp"), "log": _math_op.bind("log"),
		"sign": _math_op.bind("sign"), "round": _math_op.bind("round"), "max": _math_op.bind("max"),
		"min": _math_op.bind("min"), "clamp": _math_op.bind("clamp"), "fmod": _math_op.bind("fmod"),
		"random": _math_op.bind("random"), "randomseed": _math_op.bind("randomseed"),
		"pow": _math_op.bind("pow"), "lerp": _math_op.bind("lerp"),
	})
	m.set_v("pi", PI)
	m.set_v("huge", INF)
	G["math"] = m

	string_lib = mk_lib({
		"len": _s_len, "sub": _s_sub, "upper": _s_upper, "lower": _s_lower, "rep": _s_rep,
		"reverse": _s_reverse, "format": _s_format, "find": _s_find, "match": _s_match,
		"gmatch": _s_gmatch, "gsub": _s_gsub, "split": _s_split, "byte": _s_byte, "char": _s_char,
	})
	G["string"] = string_lib
	G["table"] = mk_lib({
		"insert": _t_insert, "remove": _t_remove, "concat": _t_concat, "unpack": _n_unpack,
		"find": _t_find, "sort": _t_sort, "clear": _t_clear,
	})
	G["os"] = mk_lib({"time": _o_time, "clock": _o_clock, "date": _o_date})
	if bridge != null:
		bridge.install_globals(G)


func _n_print(a: Array, _th: LuaThread) -> Variant:
	var parts := PackedStringArray()
	for v in a:
		parts.append(tostr(v))
	printed.emit("\t".join(parts), 0)
	return []


func _n_warn(a: Array, _th: LuaThread) -> Variant:
	var parts := PackedStringArray()
	for v in a:
		parts.append(tostr(v))
	printed.emit("\t".join(parts), 1)
	return []


func _n_error(a: Array, th: LuaThread) -> Variant:
	var v: Variant = arg(a, 0)
	throw(th, tostr(v))
	th.err_raw = v
	return []


func _n_assert(a: Array, th: LuaThread) -> Variant:
	if not truthy(arg(a, 0)):
		throw(th, tostr(a[1]) if a.size() > 1 else "assertion failed!")
		return []
	return a


func _n_pcall(a: Array, th: LuaThread) -> Variant:
	if a.is_empty():
		return [false, "pcall: fonksiyon gerekli"]
	var th2 := LuaThread.new()
	th2.line = th.line
	th2.depth = th.depth
	var r: Array = await call_fn(a[0], a.slice(1), th2)
	if th2.has_err:
		return [false, th2.err_raw]
	var out: Array = [true]
	out.append_array(r)
	return out


func _n_type(a: Array, _th: LuaThread) -> Variant:
	return [type_name(arg(a, 0))]


func _n_typeof(a: Array, _th: LuaThread) -> Variant:
	return [typeof_name(arg(a, 0))]


func _n_tostring(a: Array, _th: LuaThread) -> Variant:
	return [tostr(arg(a, 0))]


func _n_tonumber(a: Array, _th: LuaThread) -> Variant:
	var v: Variant = arg(a, 0)
	if is_num(v):
		return [float(v)]
	if v is String:
		var s: String = v.strip_edges()
		var base := int(num(arg(a, 1))) if a.size() > 1 and a[1] != null else 10
		if base == 16 or s.begins_with("0x") or s.begins_with("0X"):
			if s.to_lower().begins_with("0x"):
				s = s.substr(2)
			if s.is_valid_hex_number():
				return [float(s.hex_to_int())]
			return [null]
		if s.is_valid_float():
			return [s.to_float()]
	return [null]


func _n_select(a: Array, _th: LuaThread) -> Variant:
	var n: Variant = arg(a, 0)
	if n is String and n == "#":
		return [a.size() - 1]
	var idx := int(num(n))
	if idx < 0:
		return a.slice(maxi(a.size() + idx, 1))
	return a.slice(idx)


func _n_unpack(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		return []
	var tt: LuaTable = t
	var i := int(num(a[1])) if a.size() > 1 and a[1] != null else 1
	var j := int(num(a[2])) if a.size() > 2 and a[2] != null else tt.length()
	var out: Array = []
	while i <= j:
		out.append(tt.get_v(i))
		i += 1
	return out


func _n_rawget(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	return [(t as LuaTable).get_v(arg(a, 1))] if t is LuaTable else [null]


func _n_rawset(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if t is LuaTable:
		(t as LuaTable).set_v(arg(a, 1), arg(a, 2))
	return [t]


func _n_rawequal(a: Array, _th: LuaThread) -> Variant:
	return [_eq(arg(a, 0), arg(a, 1))]


func _n_setmetatable(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if t is LuaTable:
		var m: Variant = arg(a, 1)
		(t as LuaTable).meta = m if m is LuaTable else null
	return [t]


func _n_getmetatable(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if t is LuaTable and (t as LuaTable).meta != null:
		return [(t as LuaTable).meta]
	return [null]


func _n_next(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		return [null]
	var tt: LuaTable = t
	var ks := tt.keys()
	var k: Variant = arg(a, 1)
	var start := 0
	if k != null:
		start = ks.find(LuaTable.norm(k)) + 1
		if start == 0:
			return [null]
	if start >= ks.size():
		return [null]
	return [ks[start], tt.get_v(ks[start])]


func _n_pairs(a: Array, th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		throw(th, "bad argument #1 to 'pairs' (table expected, got %s)" % type_name(t))
		return []
	return [_pairs_fn, t, null]


func _n_ipairs(a: Array, th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		throw(th, "bad argument #1 to 'ipairs' (table expected, got %s)" % type_name(t))
		return []
	return [_ipairs_fn, t, 0]


func _n_ipairs_iter(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	var i := int(num(arg(a, 1))) + 1
	if t is LuaTable:
		var v: Variant = (t as LuaTable).get_v(i)
		if v != null:
			return [i, v]
	return [null]


func _n_wait(a: Array, _th: LuaThread) -> Variant:
	var t := num(a[0]) if a.size() > 0 and a[0] != null else 0.03
	var e := await wait_seconds(t)
	return [e]


func _n_spawn(a: Array, _th: LuaThread) -> Variant:
	spawn_fn(arg(a, 0), a.slice(1))
	return []


func _delay_task(t: float, f: Variant, args: Array) -> void:
	await wait_seconds(t)
	spawn_fn(f, args)


func _n_delay(a: Array, _th: LuaThread) -> Variant:
	_delay_task(num(arg(a, 0)), arg(a, 1), a.slice(2))
	return []


func _n_tick(_a: Array, _th: LuaThread) -> Variant:
	return [Time.get_unix_time_from_system()]


func _n_time(_a: Array, _th: LuaThread) -> Variant:
	return [_elapsed]


func _math_op(a: Array, th: LuaThread, op: String) -> Variant:
	var x := num(arg(a, 0))
	match op:
		"floor":
			return [floorf(x)]
		"ceil":
			return [ceilf(x)]
		"abs":
			return [absf(x)]
		"sqrt":
			return [sqrt(x)]
		"sin":
			return [sin(x)]
		"cos":
			return [cos(x)]
		"tan":
			return [tan(x)]
		"asin":
			return [asin(x)]
		"acos":
			return [acos(x)]
		"atan":
			if a.size() > 1:
				return [atan2(x, num(a[1]))]
			return [atan(x)]
		"atan2":
			return [atan2(x, num(arg(a, 1)))]
		"rad":
			return [deg_to_rad(x)]
		"deg":
			return [rad_to_deg(x)]
		"exp":
			return [exp(x)]
		"log":
			if a.size() > 1:
				return [log(x) / log(num(a[1]))]
			return [log(x)]
		"sign":
			return [signf(x)]
		"round":
			return [roundf(x)]
		"pow":
			return [pow(x, num(arg(a, 1)))]
		"fmod":
			return [fmod(x, num(arg(a, 1)))]
		"clamp":
			return [clampf(x, num(arg(a, 1)), num(arg(a, 2)))]
		"lerp":
			return [lerpf(x, num(arg(a, 1)), num(arg(a, 2)))]
		"max":
			var m := x
			for v in a:
				m = maxf(m, num(v))
			return [m]
		"min":
			var n := x
			for v2 in a:
				n = minf(n, num(v2))
			return [n]
		"random":
			if a.size() == 0:
				return [_rng.randf()]
			if a.size() == 1:
				return [float(_rng.randi_range(1, maxi(int(x), 1)))]
			return [float(_rng.randi_range(int(x), int(num(a[1]))))]
		"randomseed":
			_rng.seed = int(x)
			return []
	return []


# ---- string
func _str_sub(s: String, i: int, j: int) -> String:
	var n := s.length()
	if i < 0:
		i = maxi(n + i + 1, 1)
	elif i == 0:
		i = 1
	if j < 0:
		j = n + j + 1
	elif j > n:
		j = n
	if i > j:
		return ""
	return s.substr(i - 1, j - i + 1)


func _s_len(a: Array, _th: LuaThread) -> Variant:
	return [tostr(arg(a, 0)).length()]


func _s_sub(a: Array, _th: LuaThread) -> Variant:
	var j := int(num(a[2])) if a.size() > 2 and a[2] != null else -1
	return [_str_sub(tostr(arg(a, 0)), int(num(arg(a, 1))), j)]


func _s_upper(a: Array, _th: LuaThread) -> Variant:
	return [tostr(arg(a, 0)).to_upper()]


func _s_lower(a: Array, _th: LuaThread) -> Variant:
	return [tostr(arg(a, 0)).to_lower()]


func _s_rep(a: Array, _th: LuaThread) -> Variant:
	var sep := tostr(a[2]) if a.size() > 2 and a[2] != null else ""
	var n := int(num(arg(a, 1)))
	var parts := PackedStringArray()
	for i in maxi(n, 0):
		parts.append(tostr(arg(a, 0)))
	return [sep.join(parts)]


func _s_reverse(a: Array, _th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var out := ""
	for i in range(s.length() - 1, -1, -1):
		out += s[i]
	return [out]


func _s_byte(a: Array, _th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var i := int(num(a[1])) if a.size() > 1 and a[1] != null else 1
	if i < 1 or i > s.length():
		return [null]
	return [s.unicode_at(i - 1)]


func _s_char(a: Array, _th: LuaThread) -> Variant:
	var out := ""
	for v in a:
		out += char(int(num(v)))
	return [out]


func _s_split(a: Array, _th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var sep := tostr(a[1]) if a.size() > 1 and a[1] != null else ","
	var t := LuaTable.new()
	for part in s.split(sep, true):
		t.append(part)
	return [t]


func _s_format(a: Array, _th: LuaThread) -> Variant:
	var fmt := tostr(arg(a, 0))
	var out := ""
	var ai := 1
	var i := 0
	while i < fmt.length():
		var c := fmt[i]
		if c != "%":
			out += c
			i += 1
			continue
		i += 1
		if i >= fmt.length():
			break
		if fmt[i] == "%":
			out += "%"
			i += 1
			continue
		var spec := ""
		while i < fmt.length() and "-+ #0123456789.".contains(fmt[i]):
			spec += fmt[i]
			i += 1
		if i >= fmt.length():
			break
		var conv := fmt[i]
		i += 1
		var v: Variant = a[ai] if ai < a.size() else null
		ai += 1
		match conv:
			"d", "i":
				out += ("%" + spec + "d") % int(num(v))
			"f":
				out += ("%" + spec + "f") % num(v)
			"x":
				out += ("%" + spec + "x") % int(num(v))
			"X":
				out += ("%" + spec + "X") % int(num(v))
			"s":
				out += ("%" + spec + "s") % tostr(v)
			"q":
				out += "\"" + tostr(v) + "\""
			"c":
				out += char(int(num(v)))
			"g", "e":
				out += fmt_num(num(v))
			_:
				out += "%" + conv
	return [out]


## Lua deseni -> PCRE (yaygın alt küme: %a %d %l %s %u %w %x %p, [], ^, $, ., *, +, -, ?, ())
func _class_inner(c: String) -> String:
	match c:
		"a":
			return "A-Za-z"
		"d":
			return "0-9"
		"l":
			return "a-z"
		"s":
			return " \\t\\n\\r\\f\\v"
		"u":
			return "A-Z"
		"w":
			return "A-Za-z0-9"
		"x":
			return "0-9A-Fa-f"
		"p":
			return "!-/:-@\\[-`{-~"
		"c":
			return "\\x00-\\x1f"
	return ""


func _lua_to_regex(pat: String) -> String:
	var out := ""
	var i := 0
	var n := pat.length()
	while i < n:
		var c := pat[i]
		if c == "%":
			i += 1
			if i >= n:
				out += "%"
				break
			var d := pat[i]
			var inner := _class_inner(d.to_lower())
			if inner != "":
				out += "[" + ("^" if d != d.to_lower() else "") + inner + "]"
			else:
				out += "\\" + d
			i += 1
		elif c == "[":
			var j := i + 1
			var set_s := "["
			if j < n and pat[j] == "^":
				set_s += "^"
				j += 1
			while j < n and pat[j] != "]":
				if pat[j] == "%" and j + 1 < n:
					var di := _class_inner(pat[j + 1].to_lower())
					set_s += di if di != "" else "\\" + pat[j + 1]
					j += 2
				else:
					set_s += "\\\\" if pat[j] == "\\" else pat[j]
					j += 1
			out += set_s + "]"
			i = j + 1
		elif c == "-":
			out += "\\-" if (out == "" or out.ends_with("(")) else "*?"
			i += 1
		elif "{}|\\".contains(c):
			out += "\\" + c
			i += 1
		else:
			out += c
			i += 1
	return out


func _re(pat: String) -> RegEx:
	var rx := RegEx.new()
	if rx.compile(_lua_to_regex(pat)) != OK:
		return null
	return rx


func _groups(m: RegExMatch) -> Array:
	var out: Array = []
	if m.get_group_count() == 0:
		out.append(m.get_string(0))
	else:
		for g in range(1, m.get_group_count() + 1):
			out.append(m.get_string(g))
	return out


func _s_find(a: Array, th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var pat := tostr(arg(a, 1))
	var init := int(num(a[2])) if a.size() > 2 and a[2] != null else 1
	if init < 0:
		init = maxi(s.length() + init + 1, 1)
	init = maxi(init, 1)
	if truthy(arg(a, 3)):
		var idx := s.find(pat, init - 1)
		if idx == -1:
			return [null]
		return [idx + 1, idx + pat.length()]
	var rx := _re(pat)
	if rx == null:
		throw(th, "geçersiz desen: " + pat)
		return []
	var m := rx.search(s, init - 1)
	if m == null:
		return [null]
	var res: Array = [m.get_start() + 1, m.get_end()]
	for g in range(1, m.get_group_count() + 1):
		res.append(m.get_string(g))
	return res


func _s_match(a: Array, th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var init := int(num(a[2])) if a.size() > 2 and a[2] != null else 1
	var rx := _re(tostr(arg(a, 1)))
	if rx == null:
		throw(th, "geçersiz desen")
		return []
	var m := rx.search(s, maxi(init, 1) - 1)
	if m == null:
		return [null]
	return _groups(m)


func _s_gmatch(a: Array, th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var rx := _re(tostr(arg(a, 1)))
	if rx == null:
		throw(th, "geçersiz desen")
		return []
	var st := {"ms": rx.search_all(s), "i": 0}
	return [_fn("gmatch_iter", _gmatch_next.bind(st))]


func _gmatch_next(_a: Array, _th: LuaThread, st: Dictionary) -> Variant:
	var ms: Array = st["ms"]
	var i: int = st["i"]
	if i >= ms.size():
		return [null]
	st["i"] = i + 1
	return _groups(ms[i])


func _s_gsub(a: Array, th: LuaThread) -> Variant:
	var s := tostr(arg(a, 0))
	var rx := _re(tostr(arg(a, 1)))
	var repl: Variant = arg(a, 2)
	var maxn := int(num(a[3])) if a.size() > 3 and a[3] != null else -1
	if rx == null:
		throw(th, "geçersiz desen")
		return []
	var out := ""
	var last := 0
	var count := 0
	for m in rx.search_all(s):
		if maxn >= 0 and count >= maxn:
			break
		out += s.substr(last, m.get_start() - last)
		var caps := _groups(m)
		var rep := ""
		if repl is String or is_num(repl):
			rep = tostr(repl)
			for gi in range(9, -1, -1):
				var gs := m.get_string(gi) if gi <= m.get_group_count() else ""
				rep = rep.replace("%" + str(gi), gs)
			rep = rep.replace("%%", "%")
		elif repl is LuaTable:
			var tv: Variant = (repl as LuaTable).get_v(caps[0])
			rep = tostr(tv) if truthy(tv) else m.get_string(0)
		elif repl is LuaFunc:
			var r: Array = await call_fn(repl, caps, th)
			if th.has_err:
				return []
			var rv: Variant = r[0] if r.size() > 0 else null
			rep = tostr(rv) if truthy(rv) else m.get_string(0)
		else:
			rep = m.get_string(0)
		out += rep
		last = m.get_end()
		count += 1
	out += s.substr(last)
	return [out, count]


# ---- table
func _t_insert(a: Array, th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		throw(th, "bad argument #1 to 'insert' (table expected)")
		return []
	var tt: LuaTable = t
	if a.size() == 2:
		tt.append(a[1])
	elif a.size() >= 3:
		var pos := int(num(a[1]))
		var i := tt.length()
		while i >= pos:
			tt.set_v(i + 1, tt.get_v(i))
			i -= 1
		tt.set_v(pos, a[2])
	return []


func _t_remove(a: Array, th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		throw(th, "bad argument #1 to 'remove' (table expected)")
		return []
	var tt: LuaTable = t
	var n := tt.length()
	if n == 0:
		return [null]
	var pos := int(num(a[1])) if a.size() > 1 and a[1] != null else n
	var v: Variant = tt.get_v(pos)
	var i := pos
	while i < n:
		tt.set_v(i, tt.get_v(i + 1))
		i += 1
	tt.set_v(n, null)
	return [v]


func _t_concat(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		return [""]
	var tt: LuaTable = t
	var sep := tostr(a[1]) if a.size() > 1 and a[1] != null else ""
	var i := int(num(a[2])) if a.size() > 2 and a[2] != null else 1
	var j := int(num(a[3])) if a.size() > 3 and a[3] != null else tt.length()
	var parts := PackedStringArray()
	while i <= j:
		parts.append(tostr(tt.get_v(i)))
		i += 1
	return [sep.join(parts)]


func _t_find(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if t is LuaTable:
		var tt: LuaTable = t
		for i in tt.length():
			if _eq(tt.get_v(i + 1), arg(a, 1)):
				return [i + 1]
	return [null]


func _t_clear(a: Array, _th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if t is LuaTable:
		(t as LuaTable).h.clear()
	return []


func _t_sort(a: Array, th: LuaThread) -> Variant:
	var t: Variant = arg(a, 0)
	if not (t is LuaTable):
		throw(th, "bad argument #1 to 'sort' (table expected)")
		return []
	var tt: LuaTable = t
	var cmp: Variant = arg(a, 1)
	var arr: Array = []
	for i in tt.length():
		arr.append(tt.get_v(i + 1))
	for i in range(1, arr.size()):
		var key: Variant = arr[i]
		var j := i - 1
		while j >= 0:
			var less := false
			if cmp != null:
				var r: Array = await call_fn(cmp, [key, arr[j]], th)
				if th.has_err:
					return []
				less = truthy(r[0] if r.size() > 0 else null)
			else:
				less = _lt(key, arr[j])
			if not less:
				break
			arr[j + 1] = arr[j]
			j -= 1
		arr[j + 1] = key
	for i in arr.size():
		tt.set_v(i + 1, arr[i])
	return []


# ---- os
func _o_time(_a: Array, _th: LuaThread) -> Variant:
	return [float(int(Time.get_unix_time_from_system()))]


func _o_clock(_a: Array, _th: LuaThread) -> Variant:
	return [float(Time.get_ticks_msec()) / 1000.0]


func _o_date(_a: Array, _th: LuaThread) -> Variant:
	return [Time.get_datetime_string_from_system()]
