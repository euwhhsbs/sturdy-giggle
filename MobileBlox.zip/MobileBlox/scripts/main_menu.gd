extends Control
## Ana menü (Roblox "Games" sayfası tarzı).
##   Üst çubuk: Oyunlar | More v   -> More içinde: Build, Ayarlar
##   Oyunlar : kartlara dokununca oyun başlar (Play). Stüdyo'ya buradan geçilmez.
##   Build   : aynı ızgara; karta dokununca o oyun Stüdyo'da açılır. İlk kart: Yeni Oyun.
## Oyundan Stüdyo'ya doğrudan geçiş yoktur; oyundan yalnızca bu menüye dönülür.

const PAGE_SIZE := 8
const COLUMNS := 4

var section := "games"  # "games" | "build"
var page := 0
var sort_mode := 0  # 0 popüler, 1 yeni, 2 A-Z
var query := ""

var games_tab: Button
var more_btn: Button
var hint_label: Label
var grid: GridContainer
var page_label: Label
var sort_opt: OptionButton
var search_edit: LineEdit
var more_menu: PanelContainer
var blocker: Control
var dialog_layer: Control
var dialog_panel: PanelContainer
var new_edit: LineEdit


func _ready() -> void:
	theme = UIKit.make_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.20, 0.23, 0.30)
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var main := VBoxContainer.new()
	main.add_theme_constant_override("separation", 8)
	add_child(main)
	main.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main.add_child(_build_topbar())

	var margin := MarginContainer.new()
	margin.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_bottom", 10)
	main.add_child(margin)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 8)
	margin.add_child(content)
	content.add_child(_build_filterbar())

	var games_panel := PanelContainer.new()
	games_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	grid = GridContainer.new()
	grid.columns = COLUMNS
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	games_panel.add_child(grid)
	content.add_child(games_panel)
	content.add_child(_build_pagebar())

	_build_overlays()
	_set_section("games")


# ------------------------------------------------------------------ Üst çubuk
func _build_topbar() -> PanelContainer:
	var bar := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.09, 0.28, 0.66)
	sb.border_width_bottom = 4
	sb.border_color = Color(0.05, 0.16, 0.42)
	sb.content_margin_left = 20
	sb.content_margin_right = 20
	sb.content_margin_top = 4
	sb.content_margin_bottom = 4
	bar.add_theme_stylebox_override("panel", sb)

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	bar.add_child(hb)

	var logo := Label.new()
	logo.text = "MobileBlox"
	logo.add_theme_font_size_override("font_size", 34)
	hb.add_child(logo)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(24, 0)
	hb.add_child(gap)

	games_tab = _tab_btn("Oyunlar")
	games_tab.pressed.connect(_set_section.bind("games"))
	hb.add_child(games_tab)
	more_btn = _tab_btn("More  v")
	more_btn.pressed.connect(_open_more)
	hb.add_child(more_btn)

	hint_label = Label.new()
	hint_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hint_label.clip_text = true
	hint_label.add_theme_font_size_override("font_size", 22)
	hb.add_child(hint_label)
	return bar


func _tab_btn(text: String) -> Button:
	var b := UIKit.btn(text, Vector2(0, 56))
	b.add_theme_font_size_override("font_size", 30)
	_tab_style(b, false)
	return b


func _tab_style(b: Button, active: bool) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.35) if active else Color(0, 0, 0, 0)
	sb.set_content_margin_all(12)
	b.add_theme_stylebox_override("normal", sb)
	var hov := StyleBoxFlat.new()
	hov.bg_color = Color(1, 1, 1, 0.15)
	hov.set_content_margin_all(12)
	b.add_theme_stylebox_override("hover", hov)
	b.add_theme_stylebox_override("pressed", hov)


# ------------------------------------------------------------------ Filtre + sayfa çubukları
func _build_filterbar() -> PanelContainer:
	var panel := PanelContainer.new()
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	panel.add_child(hb)

	var refresh := UIKit.btn("Yenile", Vector2(130, 52))
	refresh.pressed.connect(_refresh_grid)
	hb.add_child(refresh)

	sort_opt = OptionButton.new()
	sort_opt.custom_minimum_size = Vector2(260, 52)
	sort_opt.focus_mode = Control.FOCUS_NONE
	sort_opt.add_item("Popüler")
	sort_opt.add_item("Yeni")
	sort_opt.add_item("A-Z")
	sort_opt.item_selected.connect(_on_sort)
	hb.add_child(sort_opt)

	search_edit = LineEdit.new()
	search_edit.placeholder_text = "Oyun ara..."
	search_edit.custom_minimum_size = Vector2(0, 52)
	search_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search_edit.text_changed.connect(_on_search)
	search_edit.text_submitted.connect(_on_search)
	hb.add_child(search_edit)

	var go := UIKit.btn("Ara", Vector2(100, 52))
	go.pressed.connect(func() -> void: _on_search(search_edit.text))
	hb.add_child(go)
	return panel


func _build_pagebar() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	panel.add_child(hb)
	var prev := UIKit.btn("<", Vector2(90, 52))
	prev.pressed.connect(_change_page.bind(-1))
	hb.add_child(prev)
	page_label = Label.new()
	page_label.custom_minimum_size = Vector2(200, 0)
	page_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	page_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hb.add_child(page_label)
	var nxt := UIKit.btn(">", Vector2(90, 52))
	nxt.pressed.connect(_change_page.bind(1))
	hb.add_child(nxt)
	return panel


# ------------------------------------------------------------------ Bölümler ve ızgara
func _set_section(s: String) -> void:
	section = s
	page = 0
	_tab_style(games_tab, s == "games")
	_tab_style(more_btn, s == "build")
	hint_label.text = "Build: düzenlemek için bir oyun seç" if s == "build" else ""
	_close_more()
	_refresh_grid()


func _on_sort(idx: int) -> void:
	sort_mode = idx
	page = 0
	_refresh_grid()


func _on_search(text: String) -> void:
	query = text.strip_edges().to_lower()
	page = 0
	_refresh_grid()


func _change_page(delta: int) -> void:
	page += delta
	_refresh_grid()


func _filtered_games() -> Array[Dictionary]:
	var list: Array[Dictionary] = []
	for g in Game.games:
		if query != "" and not str(g["name"]).to_lower().contains(query):
			continue
		list.append(g)
	match sort_mode:
		0:
			list.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return int(a.get("plays", 0)) > int(b.get("plays", 0)))
		1:
			list.reverse()
		2:
			list.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
				return str(a["name"]).to_lower() < str(b["name"]).to_lower())
	return list


func _refresh_grid() -> void:
	for c in grid.get_children():
		grid.remove_child(c)
		c.queue_free()
	var entries: Array[Dictionary] = []
	if section == "build":
		entries.append({"new": true})
	for g in _filtered_games():
		entries.append({"game": g})
	var pages := maxi(1, ceili(float(entries.size()) / PAGE_SIZE))
	page = clampi(page, 0, pages - 1)
	var start := page * PAGE_SIZE
	for i in range(start, mini(start + PAGE_SIZE, entries.size())):
		var e: Dictionary = entries[i]
		if e.has("new"):
			grid.add_child(_make_card("+ Yeni Oyun", "Boş bir dünya oluştur", Color(0.20, 0.55, 0.30), "+", _open_new_dialog))
		else:
			var g: Dictionary = e["game"]
			var id := str(g["id"])
			var nm := str(g["name"])
			var hue := float(absi(hash(id)) % 360) / 360.0
			var sub := "Parça: %d   Oynanma: %d" % [int(g.get("parts", 0)), int(g.get("plays", 0))]
			if bool(g.get("builtin", false)):
				sub = "Yerleşik | Parça: %d" % int(g.get("parts", 0))
				if section == "build":
					sub += "  (kopya düzenlenir)"
			grid.add_child(_make_card(nm, sub, Color.from_hsv(hue, 0.5, 0.65), nm.substr(0, 1).to_upper(), _on_game.bind(id)))
	page_label.text = "Sayfa %d / %d" % [page + 1, pages]


func _make_card(title: String, sub: String, color: Color, big: String, cb: Callable) -> Button:
	var card := Button.new()
	card.custom_minimum_size = Vector2(285, 192)
	card.focus_mode = Control.FOCUS_NONE
	card.pressed.connect(cb)

	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 4)
	card.add_child(vb)
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 8)

	var thumb := ColorRect.new()
	thumb.color = color
	thumb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	thumb.custom_minimum_size = Vector2(0, 100)
	var letter := Label.new()
	letter.text = big
	letter.mouse_filter = Control.MOUSE_FILTER_IGNORE
	letter.add_theme_font_size_override("font_size", 64)
	letter.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	letter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	thumb.add_child(letter)
	letter.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.add_child(thumb)

	var n := Label.new()
	n.text = title
	n.clip_text = true
	n.mouse_filter = Control.MOUSE_FILTER_IGNORE
	n.add_theme_font_size_override("font_size", 24)
	n.add_theme_constant_override("outline_size", 0)
	vb.add_child(n)
	var s := Label.new()
	s.text = sub
	s.clip_text = true
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	s.add_theme_font_size_override("font_size", 19)
	s.add_theme_constant_override("outline_size", 0)
	s.modulate = Color(0.75, 0.8, 0.9)
	vb.add_child(s)
	return card


func _on_game(id: String) -> void:
	if section == "build":
		if Game.is_builtin(id):
			Game.fork_game(id)  # yerleşik oyun salt okunur: düzenlenebilir kopyası açılır
		else:
			Game.select_game(id)
		Game.goto("res://scenes/studio.tscn")
	else:
		Game.select_game(id)
		Game.record_play()
		Game.goto("res://scenes/play.tscn")


# ------------------------------------------------------------------ More menüsü + diyaloglar
func _build_overlays() -> void:
	# Menü dışına dokununca kapatan görünmez katman
	blocker = Control.new()
	blocker.mouse_filter = Control.MOUSE_FILTER_STOP
	blocker.visible = false
	blocker.gui_input.connect(_on_blocker_input)
	add_child(blocker)
	blocker.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	more_menu = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.02, 0.02, 0.06, 0.98)
	sb.set_border_width_all(2)
	sb.border_color = Color.WHITE
	sb.set_content_margin_all(0)
	more_menu.add_theme_stylebox_override("panel", sb)
	more_menu.visible = false
	var vb := VBoxContainer.new()
	more_menu.add_child(vb)
	vb.add_child(_menu_item("Build", _set_section.bind("build")))
	vb.add_child(_menu_item("Oyun İçe Aktar", _open_import))
	vb.add_child(_menu_item("Nasıl Oynanır", _open_help))
	vb.add_child(_menu_item("Ayarlar", _open_settings))
	vb.add_child(_menu_item("Hakkında", _open_about))
	add_child(more_menu)

	# Modal diyalog katmanı
	dialog_layer = Control.new()
	dialog_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	dialog_layer.visible = false
	add_child(dialog_layer)
	dialog_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dialog_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dialog_layer.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dialog_panel = PanelContainer.new()
	dialog_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	cc.add_child(dialog_panel)


func _menu_item(text: String, cb: Callable) -> Button:
	var b := UIKit.btn(text, Vector2(320, 70))
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 34)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0, 0, 0, 0)
	normal.content_margin_left = 22
	normal.content_margin_right = 22
	var hov := StyleBoxFlat.new()
	hov.bg_color = Color(1, 1, 1, 0.15)
	hov.content_margin_left = 22
	hov.content_margin_right = 22
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hov)
	b.add_theme_stylebox_override("pressed", hov)
	b.pressed.connect(cb)
	return b


func _open_more() -> void:
	blocker.visible = true
	more_menu.visible = true
	more_menu.position = Vector2(more_btn.global_position.x, more_btn.global_position.y + more_btn.size.y)


func _close_more() -> void:
	if blocker != null:
		blocker.visible = false
	if more_menu != null:
		more_menu.visible = false


func _on_blocker_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		_close_more()
	elif event is InputEventScreenTouch and (event as InputEventScreenTouch).pressed:
		_close_more()


func _show_dialog(content: Control) -> void:
	for c in dialog_panel.get_children():
		dialog_panel.remove_child(c)
		c.queue_free()
	dialog_panel.add_child(content)
	dialog_layer.visible = true


func _hide_dialog() -> void:
	dialog_layer.visible = false


func _title(text: String, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	return l


# ---- Ayarlar
func _joy_text() -> String:
	return "Joystick: " + ("Sabit" if Game.joystick_fixed else "Yüzen")


func _shadow_text() -> String:
	return "Gölgeler: " + ("Açık" if Game.shadows_enabled else "Kapalı")


func _open_settings() -> void:
	_close_more()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.custom_minimum_size = Vector2(440, 0)
	vb.add_child(_title("Ayarlar", 40))
	var jb := UIKit.btn(_joy_text(), Vector2(440, 68))
	jb.pressed.connect(_toggle_joy.bind(jb))
	vb.add_child(jb)
	var sh := UIKit.btn(_shadow_text(), Vector2(440, 68))
	sh.pressed.connect(_toggle_shadow.bind(sh))
	vb.add_child(sh)
	var fs := UIKit.btn(_fs_text(), Vector2(440, 68))
	fs.pressed.connect(_toggle_fs.bind(fs))
	vb.add_child(fs)
	var close := UIKit.btn("Kapat", Vector2(440, 68))
	close.pressed.connect(_hide_dialog)
	vb.add_child(close)
	_show_dialog(vb)


func _fs_text() -> String:
	var full := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
	return "Tam ekran: " + ("Açık" if full else "Kapalı")


func _toggle_fs(b: Button) -> void:
	var full := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if full else DisplayServer.WINDOW_MODE_FULLSCREEN)
	b.text = "Tam ekran: " + ("Kapalı" if full else "Açık")


const HELP_TEXT := "[b]Oyun (Oyunlar sekmesi)[/b]\n- Sol yarıda parmağını kaydır: yürü\n- Sağ yarıda kaydır: kamerayı döndür (iki parmak: yakınlaştır)\n- Zıpla düğmesi: zıpla\n- Sağ üstteki Menü: ana menüye dön\n\n[b]Stüdyo (More > Build)[/b]\n- Bir oyun seç ya da Yeni Oyun oluştur\n- Seç aracı: dokun = seç, seçili parçayı sürükle = taşı\n- Kutu / Silindir / Küre: dokunduğun yüzeye parça ekler\n- Çoklu: birden çok parça seç\n- Özellikler: konum, boyut, dönüş, renk, davranış\n- Arayüz sekmesi: oyun içi ekran öğeleri\n- Script sekmesi: Luau (Roblox dili) ile kod yaz\n- Kaydet: dünya bu cihazda saklanır"


func _open_help() -> void:
	_close_more()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.add_child(_title("Nasıl Oynanır", 40))
	var rt := RichTextLabel.new()
	rt.bbcode_enabled = true
	rt.custom_minimum_size = Vector2(640, 320)
	rt.add_theme_font_size_override("normal_font_size", 22)
	rt.add_theme_font_size_override("bold_font_size", 24)
	rt.text = HELP_TEXT
	vb.add_child(rt)
	var close := UIKit.btn("Kapat", Vector2(640, 64))
	close.pressed.connect(_hide_dialog)
	vb.add_child(close)
	_show_dialog(vb)


func _open_about() -> void:
	_close_more()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	vb.add_child(_title("MobileBlox", 44))
	var l := Label.new()
	l.text = "Sürüm %s\n\nGodot Engine ile yapıldı (MIT lisansı).\n\nOyunların bu cihazda / tarayıcıda saklanır.\nTarayıcı verisini silersen dünyaların da silinir." % Game.version
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.custom_minimum_size = Vector2(560, 0)
	vb.add_child(l)
	var close := UIKit.btn("Kapat", Vector2(560, 64))
	close.pressed.connect(_hide_dialog)
	vb.add_child(close)
	_show_dialog(vb)


func _toggle_joy(b: Button) -> void:
	Game.joystick_fixed = not Game.joystick_fixed
	Game.save_settings()
	b.text = _joy_text()


func _toggle_shadow(b: Button) -> void:
	Game.shadows_enabled = not Game.shadows_enabled
	Game.save_settings()
	b.text = _shadow_text()


# ---- Oyun içe aktar (başkasının paylaştığı metni yapıştır)
var import_edit: TextEdit
var import_name: LineEdit
var import_msg: Label


func _open_import() -> void:
	_close_more()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	vb.add_child(_title("Oyun İçe Aktar", 40))
	var info := Label.new()
	info.text = "Paylaşılan oyun metnini aşağıya yapıştır (kutuya uzun bas > Yapıştır)."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(640, 0)
	vb.add_child(info)
	import_edit = TextEdit.new()
	import_edit.custom_minimum_size = Vector2(640, 220)
	import_edit.placeholder_text = "{\"mobileblox\": 1, ...}"
	vb.add_child(import_edit)
	import_name = LineEdit.new()
	import_name.placeholder_text = "Oyun adı (boşsa orijinali)"
	import_name.custom_minimum_size = Vector2(0, 56)
	vb.add_child(import_name)
	import_msg = Label.new()
	vb.add_child(import_msg)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var paste := UIKit.btn("Panodan", Vector2(150, 60))
	paste.pressed.connect(func() -> void: import_edit.text = DisplayServer.clipboard_get())
	row.add_child(paste)
	var go := UIKit.btn("İçe Aktar", Vector2(240, 60))
	go.pressed.connect(_do_import)
	row.add_child(go)
	var cancel := UIKit.btn("Kapat", Vector2(220, 60))
	cancel.pressed.connect(_hide_dialog)
	row.add_child(cancel)
	vb.add_child(row)
	_show_dialog(vb)


func _do_import() -> void:
	var id := Game.import_json(import_edit.text, import_name.text)
	if id == "":
		import_msg.text = "Geçersiz metin: oyun bulunamadı."
		import_msg.modulate = Color(1.0, 0.5, 0.45)
		return
	_hide_dialog()
	_refresh_list_after_import()


func _refresh_list_after_import() -> void:
	sort_mode = 1  # "Yeni": içe aktarılan oyun listenin başında görünsün
	sort_opt.select(1)
	page = 0
	_refresh_grid()


# ---- Yeni oyun
func _open_new_dialog() -> void:
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.custom_minimum_size = Vector2(500, 0)
	vb.add_child(_title("Yeni Oyun", 40))
	new_edit = LineEdit.new()
	new_edit.placeholder_text = "Oyun adı"
	new_edit.custom_minimum_size = Vector2(0, 64)
	vb.add_child(new_edit)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var create := UIKit.btn("Oluştur", Vector2(240, 64))
	create.pressed.connect(_create_game)
	row.add_child(create)
	var cancel := UIKit.btn("İptal", Vector2(240, 64))
	cancel.pressed.connect(_hide_dialog)
	row.add_child(cancel)
	vb.add_child(row)
	_show_dialog(vb)


func _create_game() -> void:
	var n := new_edit.text.strip_edges()
	if n.is_empty():
		n = "Yeni Oyun %d" % (Game.games.size() + 1)
	Game.create_game(n)
	Game.goto("res://scenes/studio.tscn")
