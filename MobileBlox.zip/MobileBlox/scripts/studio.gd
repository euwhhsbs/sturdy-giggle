class_name Studio
extends WorldBase
## Roblox Studio benzeri düzenleyici (mobil):
##   Üst: sekmeli şerit (Ana Sayfa / Model / Test / Görünüm)
##   Sol: Gezgin (parça listesi)   Sağ: Özellikler (ad/konum/boyut/dönüş/renk/tehlike)
##   Orta: 3D görünüm + dinamik joystick (kamera uçurma) + Yük./Aşa. düğmeleri + Çıktı
## Dokunma: tek parmak sürükle = orbit (seçili parçanın üstünden başlarsa PARÇAYI TAŞIR),
##          iki parmak = pan + pinch zoom, kısa dokunuş = araç eylemi.
## Çoklu seçim: "Çoklu" açıkken parçalara dokunarak ekle/çıkar. Düzenlemeler tüm seçime uygulanır.

enum Tool { SELECT, ADD, DELETE, PAINT, SPAWN }

const JoystickScript := preload("res://scripts/touch_joystick.gd")
const STEPS: Array[float] = [0.5, 1.0, 2.0]
const ROT_STEPS: Array[float] = [15.0, 45.0, 90.0]
const BEHAVIOR_NAMES: Array[String] = [
	"Yok", "Hasar", "Öldür", "Zıplatıcı", "Checkpoint", "Hareketli Platform",
]
const KIND_NAMES: Array[String] = ["Kutu", "Silindir", "Küre"]
const AXIS_NAMES: Array[String] = ["X", "Y", "Z"]
const MAX_BOXES := 300  # aynı anda çizilen seçim kutusu üst sınırı
const HINTS: Array[String] = [
	"Seç: dokun = seç, seçili parçayı sürükle = taşı",
	"Ekle: bir yüzeye dokun",
	"Sil: bir parçaya dokun",
	"Boya: bir parçaya dokun",
	"Spawn: bir yüzeye dokun",
]

var cur_tool: int = Tool.SELECT
var cur_kind: int = PartFactory.Kind.BOX
var cur_color := Color("1e88e5")
var step_idx := 1
var multi_mode := false
var selected: StaticBody3D = null  # birincil (Özellikler panelinde gösterilen)
var sel_list: Array[StaticBody3D] = []  # tüm seçim
var palette: Array[Color] = [
	Color("e53935"), Color("fb8c00"), Color("fdd835"), Color("43a047"), Color("1e88e5"),
	Color("8e24aa"), Color("f5f5f5"), Color("757575"), Color("3e2723"), Color("212121"),
]

var cam: Camera3D
var cam_target := Vector3(0, 1, 0)
var cam_yaw := 0.6
var cam_pitch := -0.7
var cam_dist := 18.0

var sel_mat: StandardMaterial3D
var sel_boxes: Array[MeshInstance3D] = []
var spawn_marker: MeshInstance3D

# UI referansları
var tool_group: ButtonGroup
var pages: Array[HBoxContainer] = []
var ribbon_scroll: ScrollContainer
var ribbon_hide_btn: Button
var step_btn: RibbonButton
var mode_btn: RibbonButton
var multi_btn: RibbonButton
var undo_btn: RibbonButton
var redo_btn: RibbonButton
var explorer_panel: PanelContainer
var explorer: ItemList
var tab_buttons: Array[Button] = []
var doc_buttons: Array[Button] = []
var ws_header: TreeHeader
var ws_box: Control
var sg_header: TreeHeader
var sg_box: Control
var props_panel: PanelContainer
var props_box: VBoxContainer
var props_empty: Label
var name_edit: LineEdit
var sel_info: Label
var pos_vals: Array[Label] = []
var size_vals: Array[Label] = []
var rot_vals: Array[Label] = []
var color_chip: ColorRect
var behavior_opt: OptionButton
var param_row: HBoxContainer
var param_title: Label
var param_val: Label
var axis_btn: Button

# StarterGui (arayüz) editörü
var gui_mode := false
var gui_canvas: Control
var screen_rect: Control
var cam_ctrl: Control  # Yük./Aşa. düğmeleri
var gui_views: Array[GuiItemView] = []
var gui_sel_id := -1
var gui_counter := 0
var gui_list: ItemList
var gui_sc: ScrollContainer
var g_name: LineEdit
var g_text: LineEdit
var g_text_box: Control
var g_font_box: Control
var g_action_box: Control
var g_action_opt: OptionButton
var g_vals: Dictionary = {}
var gui_undo_btn: RibbonButton
var gui_redo_btn: RibbonButton

# Script editörü
var script_mode := false
var script_canvas: Control
var code_edit: CodeEdit
var script_title: Label
var script_err: Label
var help_panel: Control
var ss_header: TreeHeader
var ss_box: Control
var script_list: ItemList
var tpl_btn: RibbonButton
var cur_script_kind := ""  # "part" | "global" | ""
var cur_script_node: StaticBody3D = null
var cur_script_id := -1
var _script_loading := false
var _tpl_idx := 0
var viewport_area: Control
var joy: Control
var out_label: RichTextLabel
var log_lines: Array[String] = []

var joy_vec := Vector2.ZERO
var cam_vert := 0.0
var _label_counter := 0

# Geri al / Yinele
var undo_stack: Array[Dictionary] = []
var redo_stack: Array[Dictionary] = []
var _last_key := ""
var _last_sig := 0
var _last_msec := 0

# Basılı tutunca tekrar (+/- düğmeleri)
var _hold_cb := Callable()
var _hold_t := 0.0

# Parça sürükleme
var _drag_mode := 0  # 0 = orbit, 1 = parça taşı
var _drag_p0 := Vector3.ZERO
var _drag_plane_y := 0.0
var _drag_orig: Dictionary = {}
var _drag_off := Vector3.ZERO


func _ready() -> void:
	build_world()
	_make_camera()
	_make_helpers()
	_build_ui()
	_explorer_rebuild()
	_gui_rebuild()
	_script_list_refresh()
	_script_show_none()
	_update_camera()
	_status("Oyun: %s (%d parça)" % [Game.current_name(), parts_root.get_child_count()])
	_status(HINTS[0])


func _exit_tree() -> void:
	_clear_history()


func _process(delta: float) -> void:
	if _hold_cb.is_valid():
		_hold_t += delta
		while _hold_t >= 0.1:
			_hold_t -= 0.1
			_hold_cb.call()
	if joy_vec == Vector2.ZERO and cam_vert == 0.0:
		return
	# Joystick = kamerayı yerde gezdir (Roblox Studio'da WASD gibi), Yük./Aşa. = yukarı/aşağı
	var fwd := -cam.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var right := cam.global_transform.basis.x
	var speed := maxf(6.0, cam_dist * 0.8)
	cam_target += (right * joy_vec.x + fwd * -joy_vec.y) * speed * delta
	cam_target.y = maxf(0.0, cam_target.y + cam_vert * speed * delta)
	_update_camera()


# ------------------------------------------------------------------ Kamera
func _make_camera() -> void:
	cam = Camera3D.new()
	cam.far = 300.0
	add_child(cam)
	cam.make_current()


func _update_camera() -> void:
	cam.position = cam_target + Basis.from_euler(Vector3(cam_pitch, cam_yaw, 0.0)) * Vector3(0, 0, cam_dist)
	cam.look_at(cam_target)


func _reset_camera() -> void:
	cam_target = Vector3(0, 1, 0)
	cam_yaw = 0.6
	cam_pitch = -0.7
	cam_dist = 18.0
	_update_camera()


func _on_orbit(rel: Vector2) -> void:
	cam_yaw -= rel.x * 0.006
	cam_pitch = clampf(cam_pitch - rel.y * 0.006, -1.5, -0.05)
	_update_camera()


func _on_pan_zoom(pan: Vector2, zoom: float) -> void:
	var right := cam.global_transform.basis.x
	var fwd := -cam.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	cam_target += (-right * pan.x + fwd * pan.y) * cam_dist * 0.0016
	cam_dist = clampf(cam_dist * zoom, 4.0, 120.0)
	_update_camera()


func _focus_selected() -> void:
	if sel_list.is_empty():
		return
	var lo := Vector3(INF, INF, INF)
	var hi := Vector3(-INF, -INF, -INF)
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		var p: Vector3 = d["p"]
		var h := (d["s"] as Vector3) * 0.5
		lo = lo.min(p - h)
		hi = hi.max(p + h)
	cam_target = (lo + hi) * 0.5
	cam_dist = clampf((hi - lo).length() * 1.4 + 6.0, 6.0, 80.0)
	_update_camera()


# ------------------------------------------------------------------ Yardımcı nesneler
func _make_helpers() -> void:
	sel_mat = StandardMaterial3D.new()
	sel_mat.albedo_color = Color(1.0, 0.9, 0.2, 0.35)
	sel_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sel_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	spawn_marker = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.6
	cm.bottom_radius = 0.6
	cm.height = 0.15
	cm.radial_segments = 16
	cm.rings = 1
	spawn_marker.mesh = cm
	var sm := StandardMaterial3D.new()
	sm.albedo_color = Color(0.2, 1.0, 0.3)
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	spawn_marker.material_override = sm
	spawn_marker.position = Game.spawn_point
	add_child(spawn_marker)


# ------------------------------------------------------------------ UI iskeleti
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.theme = UIKit.make_studio_theme()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# En arkada tam ekran jest katmanı (3D görünüm hep tam ekran; paneller üstte)
	var touch := TouchLayer.new()
	root.add_child(touch)
	touch.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	touch.tapped.connect(_on_tap)
	touch.drag_began.connect(_on_drag_began)
	touch.drag_moved.connect(_on_drag_moved)
	touch.drag_ended.connect(_on_drag_ended)
	touch.drag_two.connect(_on_pan_zoom)

	var layout := VBoxContainer.new()
	layout.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_theme_constant_override("separation", 2)
	root.add_child(layout)
	layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	layout.add_child(_build_titlebar())
	layout.add_child(_build_ribbon())

	var body := HBoxContainer.new()
	body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 2)
	layout.add_child(body)
	body.add_child(_build_explorer())
	body.add_child(_build_center())
	body.add_child(_build_props())

	_apply_joystick_mode()
	_refresh_props()
	_update_history_buttons()
	_update_count()


## Pencere başlığı: "Oyun adı - MobileBlox Studio" (Roblox Studio'daki "Baseplate - Roblox Studio" gibi)
func _build_titlebar() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.10, 0.10, 0.10), 0, Color(0.05, 0.05, 0.05), 1, 4))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	panel.add_child(hb)
	var logo := StudioIcon.new()
	logo.icon_name = "cube"
	logo.custom_minimum_size = Vector2(26, 26)
	hb.add_child(logo)
	var title := Label.new()
	title.text = "%s - MobileBlox Studio" % Game.current_name()
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.clip_text = true
	hb.add_child(title)
	var close := Button.new()
	close.text = "Çıkış"
	close.focus_mode = Control.FOCUS_NONE
	close.custom_minimum_size = Vector2(96, 32)
	close.pressed.connect(_go_menu)
	hb.add_child(close)
	return panel


# ------------------------------------------------------------------ Şerit (ribbon)
func _build_ribbon() -> PanelContainer:
	tool_group = ButtonGroup.new()
	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.20, 0.20, 0.20), 0, Color(0.09, 0.09, 0.09), 1, 0))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	panel.add_child(vb)

	# Sekme şeridi
	var strip := PanelContainer.new()
	strip.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.13, 0.13, 0.13), 0, Color(0.09, 0.09, 0.09), 1, 0))
	var tabbar := HBoxContainer.new()
	tabbar.add_theme_constant_override("separation", 0)
	strip.add_child(tabbar)
	vb.add_child(strip)
	var tab_group := ButtonGroup.new()
	var tab_names: Array[String] = ["Ana Sayfa", "Model", "Test", "Görünüm", "Arayüz", "Script"]
	for i in tab_names.size():
		var tb := Button.new()
		tb.text = tab_names[i]
		tb.toggle_mode = true
		tb.focus_mode = Control.FOCUS_NONE
		tb.custom_minimum_size = Vector2(120, 40)
		tb.button_group = tab_group
		UIKit.style_tab(tb)
		tb.button_pressed = (i == 0)
		tb.pressed.connect(_show_page.bind(i))
		tabbar.add_child(tb)
		tab_buttons.append(tb)
	var gap := Control.new()
	gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tabbar.add_child(gap)
	ribbon_hide_btn = Button.new()
	ribbon_hide_btn.text = "Gizle"
	ribbon_hide_btn.focus_mode = Control.FOCUS_NONE
	ribbon_hide_btn.custom_minimum_size = Vector2(90, 32)
	ribbon_hide_btn.pressed.connect(_toggle_ribbon)
	tabbar.add_child(ribbon_hide_btn)

	# Şerit içeriği
	ribbon_scroll = ScrollContainer.new()
	ribbon_scroll.custom_minimum_size = Vector2(0, 104)
	ribbon_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(ribbon_scroll)
	var pages_root := VBoxContainer.new()
	ribbon_scroll.add_child(pages_root)
	for i in 6:
		var p := HBoxContainer.new()
		p.add_theme_constant_override("separation", 6)
		p.visible = (i == 0)
		pages_root.add_child(p)
		pages.append(p)
	_fill_home(pages[0])
	_fill_model(pages[1])
	_fill_test(pages[2])
	_fill_view(pages[3])
	_fill_gui(pages[4])
	_fill_script(pages[5])
	return panel


## Şerit grubu: düğmeler üstte, grup adı altta küçük gri yazı, yanında ince ayırıcı.
func _group(page: Control, title: String) -> HBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	v.add_child(row)
	var l := Label.new()
	l.text = title
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 16)
	l.modulate = Color(0.62, 0.64, 0.68)
	v.add_child(l)
	page.add_child(v)
	page.add_child(VSeparator.new())
	return row


func _rb(parent: Control, icon: String, caption: String, cb: Callable, width: float = 72.0) -> RibbonButton:
	var b := RibbonButton.make(icon, caption, width)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _rb_tool(parent: Control, icon: String, caption: String, tool_id: int, kind_id: int, on: bool) -> RibbonButton:
	var b := RibbonButton.make(icon, caption)
	b.toggle_mode = true
	b.button_group = tool_group
	b.button_pressed = on
	b.pressed.connect(_set_tool.bind(tool_id, kind_id))
	parent.add_child(b)
	return b


func _fill_home(p: Control) -> void:
	var g := _group(p, "Dosya")
	_rb(g, "menu", "Menü", _go_menu)
	_rb(g, "save", "Kaydet", _save)
	_rb(g, "load", "Yükle", _load)
	_rb(g, "share", "Paylaş", _share)

	g = _group(p, "Geçmiş")
	undo_btn = _rb(g, "undo", "Geri Al", _undo)
	redo_btn = _rb(g, "redo", "Yinele", _redo)

	g = _group(p, "Araçlar")
	_rb_tool(g, "select", "Seç", Tool.SELECT, -1, true)
	_rb_tool(g, "delete", "Silgi", Tool.DELETE, -1, false)
	_rb_tool(g, "paint", "Boya", Tool.PAINT, -1, false)
	_rb_tool(g, "spawn", "Spawn", Tool.SPAWN, -1, false)

	g = _group(p, "Seçim")
	multi_btn = RibbonButton.make("multi", "Çoklu")
	multi_btn.toggle_mode = true
	multi_btn.toggled.connect(_set_multi)
	g.add_child(multi_btn)
	_rb(g, "all", "Tümü", _select_all)

	g = _group(p, "Ekle")
	var kind_icons: Array[String] = ["cube", "cylinder", "sphere"]
	for i in KIND_NAMES.size():
		_rb_tool(g, kind_icons[i], KIND_NAMES[i], Tool.ADD, i, false)

	g = _group(p, "Renk")
	var cgroup := ButtonGroup.new()
	for c in palette:
		var s := UIKit.swatch(c)
		s.custom_minimum_size = Vector2(44, 44)
		s.button_group = cgroup
		s.pressed.connect(_set_color.bind(c))
		g.add_child(s)
		if c == cur_color:
			s.button_pressed = true

	g = _group(p, "Düzenle")
	_rb(g, "copy", "Kopyala", _duplicate)
	_rb(g, "delete", "Sil", _delete_selected)

	g = _group(p, "Test")
	_rb(g, "play", "Oyna", _play)


func _fill_model(p: Control) -> void:
	var g := _group(p, "Adım")
	step_btn = _rb(g, "step", "Adım: 1.0 | 45°", _cycle_step, 150.0)
	g = _group(p, "Seçim")
	_rb(g, "copy", "Kopyala", _duplicate)
	_rb(g, "delete", "Sil", _delete_selected)
	_rb(g, "all", "Tümü", _select_all)
	_rb(g, "focus", "Odakla", _focus_selected)
	_rb(g, "dot", "Bırak", func() -> void: _select(null))


func _fill_test(p: Control) -> void:
	var g := _group(p, "Oyun")
	_rb(g, "play", "Oyna (Client)", _play, 120.0)
	g = _group(p, "Dosya")
	_rb(g, "save", "Kaydet", _save)
	_rb(g, "menu", "Menü", _go_menu)


func _fill_view(p: Control) -> void:
	var g := _group(p, "Paneller")
	var eb := RibbonButton.make("workspace", "Gezgin")
	eb.toggle_mode = true
	eb.button_pressed = true
	eb.toggled.connect(func(on: bool) -> void: explorer_panel.visible = on)
	g.add_child(eb)
	var pb := RibbonButton.make("panels", "Özellikler", 90.0)
	pb.toggle_mode = true
	pb.button_pressed = true
	pb.toggled.connect(func(on: bool) -> void: props_panel.visible = on)
	g.add_child(pb)

	g = _group(p, "Kontrol")
	mode_btn = RibbonButton.make("joystick", "Joystick: Yüzen", 150.0)
	mode_btn.pressed.connect(_toggle_joystick_mode)
	g.add_child(mode_btn)

	g = _group(p, "Kamera")
	_rb(g, "camera", "Sıfırla", _reset_camera)


func _show_page(i: int) -> void:
	for k in pages.size():
		pages[k].visible = (k == i)
	ribbon_scroll.visible = true
	ribbon_hide_btn.text = "Gizle"
	_set_gui_mode(i == 4)
	_set_script_mode(i == 5)


func _goto_tab(i: int) -> void:
	if i >= 0 and i < tab_buttons.size():
		tab_buttons[i].button_pressed = true
	_show_page(i)


func _toggle_ribbon() -> void:
	ribbon_scroll.visible = not ribbon_scroll.visible
	ribbon_hide_btn.text = "Gizle" if ribbon_scroll.visible else "Göster"


# ------------------------------------------------------------------ Gezgin (Explorer)
## Panel başlık şeridi ("Gezgin", "Özellikler", "Çıktı")
func _panel_title(text: String) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.13, 0.13, 0.13), 0, Color(0.09, 0.09, 0.09), 1, 6))
	var l := Label.new()
	l.text = text
	p.add_child(l)
	return p


## Roblox Gezgin'i gibi ağaç: Workspace (parçalar) ve StarterGui (arayüz) açılıp kapanır.
func _build_explorer() -> PanelContainer:
	explorer_panel = PanelContainer.new()
	explorer_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	explorer_panel.custom_minimum_size = Vector2(250, 0)
	explorer_panel.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.17, 0.17, 0.17), 0, Color(0.09, 0.09, 0.09), 1, 0))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	explorer_panel.add_child(vb)
	vb.add_child(_panel_title("Gezgin"))

	ws_header = TreeHeader.make("Workspace (0)", "workspace")
	ws_header.pressed.connect(_toggle_ws)
	vb.add_child(ws_header)
	ws_box = MarginContainer.new()
	ws_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	ws_box.add_theme_constant_override("margin_left", 16)
	explorer = ItemList.new()
	explorer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	explorer.custom_minimum_size = Vector2(0, 100)
	explorer.allow_reselect = true
	explorer.item_selected.connect(_on_explorer_selected)
	ws_box.add_child(explorer)
	vb.add_child(ws_box)

	sg_header = TreeHeader.make("StarterGui (0)", "gui_frame")
	sg_header.expanded = false
	sg_header.pressed.connect(_toggle_sg)
	vb.add_child(sg_header)
	sg_box = MarginContainer.new()
	sg_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sg_box.add_theme_constant_override("margin_left", 16)
	sg_box.visible = false
	gui_list = ItemList.new()
	gui_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	gui_list.custom_minimum_size = Vector2(0, 100)
	gui_list.allow_reselect = true
	gui_list.item_selected.connect(_on_gui_list_selected)
	sg_box.add_child(gui_list)
	vb.add_child(sg_box)

	ss_header = TreeHeader.make("Scripts (0)", "script")
	ss_header.expanded = false
	ss_header.pressed.connect(_toggle_ss)
	vb.add_child(ss_header)
	ss_box = MarginContainer.new()
	ss_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	ss_box.add_theme_constant_override("margin_left", 16)
	ss_box.visible = false
	script_list = ItemList.new()
	script_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	script_list.custom_minimum_size = Vector2(0, 80)
	script_list.allow_reselect = true
	script_list.item_selected.connect(_on_script_list_selected)
	ss_box.add_child(script_list)
	vb.add_child(ss_box)
	return explorer_panel


func _toggle_ws() -> void:
	_set_expanded(true, not ws_header.expanded)


func _toggle_sg() -> void:
	_set_expanded(false, not sg_header.expanded)


func _set_expanded(workspace: bool, on: bool) -> void:
	if workspace:
		ws_header.expanded = on
		ws_box.visible = on
	else:
		sg_header.expanded = on
		sg_box.visible = on


## Otomatik ad (kayıtta tutulmaz): "Kutu 7"
func _auto_label(body: Node) -> String:
	if body.has_meta("label"):
		return str(body.get_meta("label"))
	_label_counter += 1
	var d: Dictionary = body.get_meta("data")
	var lbl := "%s %d" % [KIND_NAMES[int(d["k"])], _label_counter]
	body.set_meta("label", lbl)
	return lbl


## Görünen ad: özel ad ("n") varsa o, yoksa otomatik.
func _label_of(body: Node) -> String:
	var d: Dictionary = body.get_meta("data")
	var custom := str(d.get("n", ""))
	if custom != "":
		return custom
	return _auto_label(body)


## Seçili parçaların başında "* " işareti olur.
func _item_text(body: Node, marked: bool) -> String:
	var d: Dictionary = body.get_meta("data")
	var mark := "  [S]" if str(d.get("sc", "")) != "" else ""
	return ("* " if marked else "") + _label_of(body) + mark


func _explorer_rebuild() -> void:
	explorer.clear()
	var marked := {}
	for n in sel_list:
		marked[n] = true
	for c in parts_root.get_children():
		explorer.add_item(_item_text(c, marked.has(c)))
	_update_count()


func _explorer_add(body: Node) -> void:
	explorer.add_item(_item_text(body, false))
	_update_count()


func _update_count() -> void:
	if ws_header != null:
		ws_header.text = "Workspace (%d)" % parts_root.get_child_count()
	if sg_header != null:
		sg_header.text = "StarterGui (%d)" % Game.gui_items.size()
	if ss_header != null:
		ss_header.text = "Scripts (%d)" % Game.scripts.size()


func _refresh_marks(old: Array) -> void:
	var cur := {}
	for n in sel_list:
		cur[n] = true
	for n in old:
		if is_instance_valid(n) and not cur.has(n) and (n as Node).get_parent() == parts_root:
			var i: int = (n as Node).get_index()
			if i < explorer.item_count:
				explorer.set_item_text(i, _item_text(n, false))
	for n in sel_list:
		var j := n.get_index()
		if j < explorer.item_count:
			explorer.set_item_text(j, _item_text(n, true))


func _on_explorer_selected(idx: int) -> void:
	if idx < 0 or idx >= parts_root.get_child_count():
		return
	var body := parts_root.get_child(idx) as StaticBody3D
	if body == null:
		return
	if gui_mode:
		_goto_tab(0)  # Gezgin'den parça seçilince Arayüz modundan çık
	if multi_mode:
		_toggle_select(body)
	else:
		_select(body)
		var d: Dictionary = body.get_meta("data")
		cam_target = d["p"]  # listeden seçilince kamerayı parçaya odakla
		_update_camera()


# ------------------------------------------------------------------ Orta alan (joystick + çıktı)
func _build_center() -> VBoxContainer:
	var center := VBoxContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.add_theme_constant_override("separation", 0)

	# Belge sekmeleri: 3D görünüm / StarterGui (Roblox'taki "Baseplate | Script" sekmeleri gibi)
	var docs := PanelContainer.new()
	docs.mouse_filter = Control.MOUSE_FILTER_STOP
	docs.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.13, 0.13, 0.13), 0, Color(0.09, 0.09, 0.09), 1, 0))
	var dh := HBoxContainer.new()
	dh.add_theme_constant_override("separation", 0)
	docs.add_child(dh)
	var dgroup := ButtonGroup.new()
	var doc_names: Array[String] = [Game.current_name(), "StarterGui", "Script"]
	for i in 3:
		var db := Button.new()
		db.text = doc_names[i]
		db.toggle_mode = true
		db.focus_mode = Control.FOCUS_NONE
		db.clip_text = true
		db.custom_minimum_size = Vector2(150, 36)
		db.button_group = dgroup
		UIKit.style_tab(db)
		db.button_pressed = (i == 0)
		db.pressed.connect(_on_doc_tab.bind(i))
		dh.add_child(db)
		doc_buttons.append(db)
	center.add_child(docs)

	viewport_area = Control.new()
	viewport_area.mouse_filter = Control.MOUSE_FILTER_IGNORE
	viewport_area.size_flags_vertical = Control.SIZE_EXPAND_FILL
	center.add_child(viewport_area)

	# Dinamik joystick: kamerayı uçurur
	joy = JoystickScript.new()
	viewport_area.add_child(joy)
	joy.set("radius", 90.0)
	joy.stick_moved.connect(func(v: Vector2) -> void: joy_vec = v)

	# Yukarı / Aşağı (basılı tut)
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 10)
	var up := TouchButton.new()
	up.label = "Yük."
	up.custom_minimum_size = Vector2(96, 96)
	up.pressed.connect(func() -> void: cam_vert = 1.0)
	up.released.connect(func() -> void: cam_vert = 0.0)
	vb.add_child(up)
	var down := TouchButton.new()
	down.label = "Aşa."
	down.custom_minimum_size = Vector2(96, 96)
	down.pressed.connect(func() -> void: cam_vert = -1.0)
	down.released.connect(func() -> void: cam_vert = 0.0)
	vb.add_child(down)
	viewport_area.add_child(vb)
	UIKit.place(vb, Control.PRESET_BOTTOM_RIGHT, 10)
	cam_ctrl = vb

	# StarterGui önizleme tuvali (yalnızca Arayüz sekmesinde görünür, 3D'ye dokunuşu engeller)
	gui_canvas = Control.new()
	gui_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	gui_canvas.visible = false
	viewport_area.add_child(gui_canvas)
	gui_canvas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen_rect = Control.new()
	screen_rect.mouse_filter = Control.MOUSE_FILTER_STOP
	screen_rect.gui_input.connect(_on_screen_input)
	gui_canvas.add_child(screen_rect)
	var frame := Panel.new()
	var fsb := StyleBoxFlat.new()
	fsb.bg_color = Color(0.05, 0.08, 0.15, 0.35)
	fsb.set_border_width_all(3)
	fsb.border_color = Color(1, 1, 1, 0.5)
	frame.add_theme_stylebox_override("panel", fsb)
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen_rect.add_child(frame)
	frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gui_canvas.resized.connect(_layout_gui)
	_build_script_canvas()

	# Çıktı (Output): zaman damgalı mesajlar
	var out_panel := PanelContainer.new()
	out_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	out_panel.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.17, 0.17, 0.17), 0, Color(0.09, 0.09, 0.09), 1, 0))
	var ov := VBoxContainer.new()
	ov.add_theme_constant_override("separation", 0)
	out_panel.add_child(ov)
	ov.add_child(_panel_title("Çıktı"))
	out_label = RichTextLabel.new()
	out_label.bbcode_enabled = true
	out_label.scroll_following = true
	out_label.selection_enabled = false
	out_label.custom_minimum_size = Vector2(0, 84)
	out_label.add_theme_font_size_override("normal_font_size", 18)
	out_label.add_theme_stylebox_override("normal", UIKit.flat_box(Color(0.10, 0.10, 0.10), 0, Color(0, 0, 0, 0), 0, 6))
	ov.add_child(out_label)
	center.add_child(out_panel)
	return center


## Belge sekmesine basınca ilgili şerit sekmesine geç.
func _on_doc_tab(i: int) -> void:
	var target: int = [0, 4, 5][i]
	var current := 5 if script_mode else (4 if gui_mode else 0)
	if target != current:
		_goto_tab(target)


## Joystick modu (Play ile aynı ayar): yüzen / sabit
func _apply_joystick_mode() -> void:
	var fixed := Game.joystick_fixed
	joy.set("fixed", fixed)
	if fixed:
		UIKit.anchor_rect(joy, 0.0, 0.45, 0.4, 1.0)
	else:
		UIKit.anchor_rect(joy, 0.0, 0.15, 0.55, 1.0)
	mode_btn.caption = "Joystick: " + ("Sabit" if fixed else "Yüzen")


func _toggle_joystick_mode() -> void:
	Game.joystick_fixed = not Game.joystick_fixed
	Game.save_settings()
	_apply_joystick_mode()


func _status(t: String) -> void:
	log_lines.append(t)
	if out_label != null:
		if log_lines.size() > 150:
			out_label.clear()
			log_lines.clear()
		out_label.append_text("[color=#8a8a8a]%s[/color]  %s\n" % [Time.get_time_string_from_system(), t.replace("[", "[lb]")])


# ------------------------------------------------------------------ Özellikler (Properties)
## Roblox Özellikler panelindeki gibi açılır kategori: başlık + içerik kutusu.
func _category(parent: Control, title: String) -> VBoxContainer:
	var h := TreeHeader.make(title, "", true)
	parent.add_child(h)
	var mc := MarginContainer.new()
	mc.add_theme_constant_override("margin_left", 8)
	mc.add_theme_constant_override("margin_right", 8)
	mc.add_theme_constant_override("margin_top", 4)
	mc.add_theme_constant_override("margin_bottom", 8)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 4)
	mc.add_child(inner)
	parent.add_child(mc)
	h.pressed.connect(_toggle_category.bind(h, mc))
	return inner


func _toggle_category(h: TreeHeader, content: Control) -> void:
	h.expanded = not h.expanded
	content.visible = h.expanded


func _build_props() -> PanelContainer:
	props_panel = PanelContainer.new()
	props_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	props_panel.custom_minimum_size = Vector2(330, 0)
	props_panel.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.17, 0.17, 0.17), 0, Color(0.09, 0.09, 0.09), 1, 0))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	props_panel.add_child(vb)
	vb.add_child(_panel_title("Özellikler"))
	props_empty = Label.new()
	props_empty.text = "Hiçbir şey seçili değil"
	props_empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	props_empty.modulate = Color(0.6, 0.6, 0.62)
	vb.add_child(props_empty)

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.custom_minimum_size = Vector2(0, 120)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	props_box = VBoxContainer.new()
	props_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	props_box.add_theme_constant_override("separation", 0)
	sc.add_child(props_box)

	# Veri
	var cat := _category(props_box, "Veri")
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Parça adı"
	name_edit.custom_minimum_size = Vector2(0, 44)
	name_edit.text_submitted.connect(_on_name_submitted)
	name_edit.focus_exited.connect(_on_name_focus_exited)
	cat.add_child(name_edit)
	sel_info = _small_label("")
	cat.add_child(sel_info)

	# Dönüşüm
	cat = _category(props_box, "Dönüşüm")
	cat.add_child(_small_label("Konum"))
	for a in 3:
		_num_row(cat, AXIS_NAMES[a], pos_vals, a, 0)
	cat.add_child(_small_label("Boyut"))
	for a in 3:
		_num_row(cat, AXIS_NAMES[a], size_vals, a, 1)
	cat.add_child(_small_label("Dönüş"))
	_num_row(cat, "Y", rot_vals, 1, 2)

	# Görünüm
	cat = _category(props_box, "Görünüm")
	var cr := HBoxContainer.new()
	var cl := Label.new()
	cl.text = "Renk"
	cl.custom_minimum_size = Vector2(80, 0)
	cr.add_child(cl)
	color_chip = ColorRect.new()
	color_chip.custom_minimum_size = Vector2(120, 30)
	cr.add_child(color_chip)
	cat.add_child(cr)

	# Davranış
	cat = _category(props_box, "Davranış")
	behavior_opt = OptionButton.new()
	behavior_opt.custom_minimum_size = Vector2(0, 44)
	behavior_opt.focus_mode = Control.FOCUS_NONE
	for nm in BEHAVIOR_NAMES:
		behavior_opt.add_item(nm)
	behavior_opt.item_selected.connect(_set_behavior)
	cat.add_child(behavior_opt)

	param_row = HBoxContainer.new()
	param_row.add_theme_constant_override("separation", 6)
	param_title = Label.new()
	param_title.custom_minimum_size = Vector2(90, 0)
	param_row.add_child(param_title)
	var pm := UIKit.btn("-", Vector2(48, 40))
	pm.button_down.connect(_hold_start.bind(_adjust_param.bind(-1.0)))
	pm.button_up.connect(_hold_stop)
	param_row.add_child(pm)
	param_val = Label.new()
	param_val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	param_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	param_row.add_child(param_val)
	var pp := UIKit.btn("+", Vector2(48, 40))
	pp.button_down.connect(_hold_start.bind(_adjust_param.bind(1.0)))
	pp.button_up.connect(_hold_stop)
	param_row.add_child(pp)
	cat.add_child(param_row)

	axis_btn = UIKit.btn("Eksen: X", Vector2(0, 44))
	axis_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	axis_btn.pressed.connect(_cycle_axis)
	cat.add_child(axis_btn)

	_build_gui_props(vb)
	return props_panel


func _small_label(text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 18)
	l.modulate = Color(0.62, 0.64, 0.68)
	return l


## kind: 0 = konum, 1 = boyut, 2 = dönüş. +/- basılı tutulunca tekrar eder.
func _num_row(parent: Control, title: String, vals: Array[Label], axis: int, kind: int) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	var l := Label.new()
	l.text = title
	l.custom_minimum_size = Vector2(30, 0)
	row.add_child(l)
	var minus := UIKit.btn("-", Vector2(48, 40))
	minus.button_down.connect(_hold_start.bind(_adjust.bind(kind, axis, -1.0)))
	minus.button_up.connect(_hold_stop)
	row.add_child(minus)
	var box := PanelContainer.new()
	box.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.10, 0.10, 0.10), 2, Color(0.30, 0.30, 0.30), 1, 4))
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := Label.new()
	v.text = "0.0"
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(v)
	row.add_child(box)
	var plus := UIKit.btn("+", Vector2(48, 40))
	plus.button_down.connect(_hold_start.bind(_adjust.bind(kind, axis, 1.0)))
	plus.button_up.connect(_hold_stop)
	row.add_child(plus)
	vals.append(v)
	parent.add_child(row)


func _refresh_props() -> void:
	if gui_mode:
		props_box.get_parent().visible = false
		var gd := _gui_sel()
		gui_sc.visible = not gd.is_empty()
		props_empty.visible = gd.is_empty()
		props_empty.text = "Arayüz öğesi seçili değil"
		if not gd.is_empty():
			_fill_gui_props(gd)
		return
	gui_sc.visible = false
	props_empty.text = "Hiçbir şey seçili değil"
	var has := selected != null and is_instance_valid(selected)
	props_box.get_parent().visible = has  # ScrollContainer
	props_empty.visible = not has
	if not has:
		return
	var d: Dictionary = selected.get_meta("data")
	var p: Vector3 = d["p"]
	var s: Vector3 = d["s"]
	for a in 3:
		pos_vals[a].text = "%.1f" % p[a]
		size_vals[a].text = "%.1f" % s[a]
	rot_vals[0].text = "%.0f°" % fposmod(float(d.get("r", 0.0)), 360.0)
	if not name_edit.has_focus():
		name_edit.text = _label_of(selected)
	sel_info.text = "%d parça seçili (düzenlemeler hepsine uygulanır)" % sel_list.size() if sel_list.size() > 1 else ""
	sel_info.visible = sel_list.size() > 1
	color_chip.color = d["c"]
	_refresh_behavior(d)


# ------------------------------------------------------------------ Ad değiştirme
func _on_name_submitted(text: String) -> void:
	_rename(text)
	name_edit.release_focus()


func _on_name_focus_exited() -> void:
	_rename(name_edit.text)


func _rename(text: String) -> void:
	if selected == null or not is_instance_valid(selected):
		return
	var t := text.strip_edges()
	if t == _label_of(selected):
		return  # değişiklik yok
	_record_edit("rename", [selected])
	var d: Dictionary = selected.get_meta("data")
	d["n"] = t  # boş = otomatik ada dön
	var i := selected.get_index()
	if i < explorer.item_count:
		explorer.set_item_text(i, _item_text(selected, true))
	_refresh_props()
	_status("Ad: " + _label_of(selected))


# ------------------------------------------------------------------ Araç / seçim ayarları
func _set_tool(tool_id: int, kind_id: int) -> void:
	cur_tool = tool_id
	if kind_id >= 0:
		cur_kind = kind_id
		_status("Ekle (%s): bir yüzeye dokun" % KIND_NAMES[kind_id])
	else:
		_status(HINTS[tool_id])


func _set_multi(on: bool) -> void:
	multi_mode = on
	if on:
		_status("Çoklu seçim AÇIK: parçalara dokunarak ekle / çıkar")
	else:
		_status("Çoklu seçim KAPALI")


func _set_color(c: Color) -> void:
	cur_color = c
	if not sel_list.is_empty():
		_paint_nodes(sel_list)


func _cycle_step() -> void:
	step_idx = (step_idx + 1) % STEPS.size()
	step_btn.caption = "Adım: %s | %d°" % [str(STEPS[step_idx]), int(ROT_STEPS[step_idx])]


# ------------------------------------------------------------------ Seçim yönetimi
func _select(body: StaticBody3D) -> void:
	if body == null:
		_set_selection([])
	else:
		_set_selection([body], body)


func _toggle_select(body: StaticBody3D) -> void:
	var list: Array = sel_list.duplicate()
	var prim: StaticBody3D = null
	if list.has(body):
		list.erase(body)
		if not list.is_empty():
			prim = list.back() as StaticBody3D
	else:
		list.append(body)
		prim = body
	_set_selection(list, prim)


func _select_all() -> void:
	var list: Array = parts_root.get_children()
	_set_selection(list)
	_status("Tümü seçildi: %d parça" % list.size())


func _set_selection(list: Array, primary: StaticBody3D = null) -> void:
	# Ad kutusunda yazılan metin, seçim değişmeden önce ESKİ parçaya kaydedilsin
	if name_edit != null and name_edit.has_focus():
		name_edit.release_focus()
	var old := sel_list.duplicate()
	var typed: Array[StaticBody3D] = []
	for n in list:
		if is_instance_valid(n) and n is StaticBody3D:
			typed.append(n)
	sel_list = typed
	if primary != null and sel_list.has(primary):
		selected = primary
	elif not sel_list.is_empty():
		selected = sel_list.back()
	else:
		selected = null
	_refresh_marks(old)
	_update_selection()
	_script_sync_selection()


## Seçim kutuları + Gezgin vurgusu + Özellikler panelini günceller (düzenlemeden sonra çağrılır).
func _update_selection() -> void:
	_refresh_boxes()
	if selected == null or not is_instance_valid(selected):
		explorer.deselect_all()
	else:
		explorer.select(selected.get_index())
		explorer.ensure_current_is_visible()
	_refresh_props()


func _refresh_boxes() -> void:
	var n := mini(sel_list.size(), MAX_BOXES)
	while sel_boxes.size() < n:
		var nb := MeshInstance3D.new()
		nb.mesh = BoxMesh.new()
		nb.material_override = sel_mat
		nb.visible = false
		add_child(nb)
		sel_boxes.append(nb)
	for i in sel_boxes.size():
		var b := sel_boxes[i]
		if i < n:
			var d: Dictionary = sel_list[i].get_meta("data")
			b.position = d["p"]
			b.rotation_degrees = Vector3(0.0, float(d.get("r", 0.0)), 0.0)
			(b.mesh as BoxMesh).size = (d["s"] as Vector3) + Vector3.ONE * 0.08
			b.visible = true
		else:
			b.visible = false


# ------------------------------------------------------------------ Dokunma eylemi
func _raycast(screen_pos: Vector2) -> Dictionary:
	var from := cam.project_ray_origin(screen_pos)
	var to := from + cam.project_ray_normal(screen_pos) * 500.0
	var q := PhysicsRayQueryParameters3D.create(from, to)
	return get_world_3d().direct_space_state.intersect_ray(q)


func _part_at(hit: Dictionary) -> StaticBody3D:
	var collider := hit.get("collider") as Node
	if collider != null and collider.is_in_group("parts"):
		return collider as StaticBody3D
	return null


func _on_tap(pos: Vector2) -> void:
	get_viewport().gui_release_focus()  # ad kutusundaki klavyeyi kapat (ad kaydedilir)
	var hit := _raycast(pos)
	if hit.is_empty():
		if cur_tool == Tool.SELECT and not multi_mode:
			_select(null)
		return
	var body := _part_at(hit)
	match cur_tool:
		Tool.SELECT:
			if multi_mode:
				if body != null:
					_toggle_select(body)
			else:
				_select(body)
		Tool.ADD:
			_add_at(hit)
		Tool.DELETE:
			if body != null:
				_delete_nodes([body])
		Tool.PAINT:
			if body != null:
				_paint_nodes([body])
		Tool.SPAWN:
			Game.spawn_point = (hit["position"] as Vector3) + Vector3(0, 0.1, 0)
			spawn_marker.position = Game.spawn_point
			_status("Spawn noktası ayarlandı")


func _default_size(kind: int) -> Vector3:
	match kind:
		PartFactory.Kind.BOX:
			return Vector3(4, 1, 2)
		_:
			return Vector3(2, 2, 2)


func _add_at(hit: Dictionary) -> void:
	if parts_root.get_child_count() >= Game.MAX_PARTS:
		_status("Parça sınırı doldu (%d)" % Game.MAX_PARTS)
		return
	var n: Vector3 = hit["normal"]
	var p: Vector3 = hit["position"]
	var size := _default_size(cur_kind)
	var center := (p + n * size * 0.5).snapped(Vector3(0.5, 0.5, 0.5))
	var d := {"k": cur_kind, "p": center, "s": size, "c": cur_color, "x": 0, "r": 0.0, "n": ""}
	var body := add_part(d)
	_push({"type": "tree", "node": body, "index": body.get_index()})
	_explorer_add(body)
	_select(body)
	_status("Eklendi: " + _label_of(body))


# ------------------------------------------------------------------ Parçayı parmakla sürükleme
## Seçili bir parçanın (veya "Seç" aracıyla herhangi bir parçanın) üstünden başlayan tek parmak
## sürüklemesi parçayı (tüm seçimi) yere paralel düzlemde taşır. Boş yerden başlarsa kamera döner.
func _ray_plane(screen_pos: Vector2, plane_y: float) -> Variant:
	var from := cam.project_ray_origin(screen_pos)
	var dir := cam.project_ray_normal(screen_pos)
	return Plane(Vector3.UP, plane_y).intersects_ray(from, dir)


func _on_drag_began(start: Vector2, fresh: bool) -> void:
	get_viewport().gui_release_focus()
	_drag_mode = 0
	if not fresh or cur_tool != Tool.SELECT:
		return
	var hit := _raycast(start)
	if hit.is_empty():
		return
	var body := _part_at(hit)
	if body == null:
		return
	if not sel_list.has(body):
		if multi_mode:
			return  # çoklu modda seçili olmayan parçadan sürükleme = kamera
		_select(body)
	var py: float = (hit["position"] as Vector3).y
	var p0: Variant = _ray_plane(start, py)
	if p0 == null:
		return
	_drag_plane_y = py
	_drag_p0 = p0
	_drag_orig.clear()
	for n in sel_list:
		_drag_orig[n] = (n.get_meta("data") as Dictionary)["p"]
	_drag_off = Vector3.ZERO
	_record_edit("drag", sel_list)
	_last_key = ""  # her sürükleme ayrı bir geri alma adımı olsun
	_drag_mode = 1


func _on_drag_moved(pos: Vector2, rel: Vector2) -> void:
	if _drag_mode == 0:
		_on_orbit(rel)
		return
	var p: Variant = _ray_plane(pos, _drag_plane_y)
	if p == null:
		return
	var step: float = STEPS[step_idx]
	var off: Vector3 = (p as Vector3) - _drag_p0
	off.y = 0.0
	off = off.snapped(Vector3(step, step, step))
	if off == _drag_off:
		return
	_drag_off = off
	for n in sel_list:
		if not _drag_orig.has(n):
			continue
		var d: Dictionary = n.get_meta("data")
		var np: Vector3 = (_drag_orig[n] as Vector3) + off
		d["p"] = np
		n.position = np
	_update_selection()


func _on_drag_ended() -> void:
	# Hiç yer değişmediyse boş geri alma adımını sil
	if _drag_mode == 1 and _drag_off == Vector3.ZERO and not undo_stack.is_empty():
		undo_stack.pop_back()
		_update_history_buttons()
	_drag_mode = 0
	_drag_orig.clear()


# ------------------------------------------------------------------ Düzenlemeler (tüm seçime uygulanır)
func _adjust(kind: int, axis: int, sign_: float) -> void:
	if sel_list.is_empty():
		return
	match kind:
		0:
			_move_axis(axis, sign_)
		1:
			_resize(axis, sign_)
		_:
			_rotate_selected(sign_)


func _move_axis(axis: int, sign_: float) -> void:
	_record_edit("move%d" % axis, sel_list)
	var delta: float = sign_ * STEPS[step_idx]
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		var p: Vector3 = d["p"]
		p[axis] += delta
		d["p"] = p
		n.position = p
	_update_selection()


func _resize(axis: int, sign_: float) -> void:
	_record_edit("size%d" % axis, sel_list)
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		var s: Vector3 = d["s"]
		s[axis] = maxf(0.5, s[axis] + sign_ * STEPS[step_idx])
		var kind := int(d["k"])
		if kind == PartFactory.Kind.SPHERE:
			s = Vector3.ONE * s[axis]
		elif kind == PartFactory.Kind.CYLINDER and axis != 1:
			s.x = s[axis]
			s.z = s[axis]
		d["s"] = s
		PartFactory.refresh(n)
	_update_selection()


func _rotate_selected(sign_: float) -> void:
	_record_edit("rot", sel_list)
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		d["r"] = fposmod(float(d.get("r", 0.0)) + sign_ * ROT_STEPS[step_idx], 360.0)
		PartFactory.refresh(n)
	_update_selection()


## Davranışı (hasar, öldür, zıplatıcı, checkpoint, hareketli platform) tüm seçime uygular.
func _set_behavior(idx: int) -> void:
	if sel_list.is_empty():
		return
	_record_edit("behavior", sel_list)
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		d["x"] = idx
		if idx == 3:
			d["a"] = 18.0  # zıplatma gücü
		elif idx == 5:
			d["a"] = 6.0  # mesafe
			d["b"] = 0  # eksen X
		else:
			d["a"] = 0.0
		PartFactory.refresh(n)
	_update_selection()
	_status("Davranış: " + BEHAVIOR_NAMES[idx])


## Zıplatıcı gücü / platform mesafesi (-/+).
func _adjust_param(sign_: float) -> void:
	if selected == null:
		return
	var kind := int((selected.get_meta("data") as Dictionary).get("x", 0))
	if kind != 3 and kind != 5:
		return
	_record_edit("param", sel_list)
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		if int(d.get("x", 0)) != kind:
			continue
		if kind == 3:
			d["a"] = clampf(float(d.get("a", 18.0)) + sign_ * 2.0, 6.0, 40.0)
		else:
			d["a"] = clampf(float(d.get("a", 6.0)) + sign_ * 1.0, 2.0, 30.0)
	_update_selection()


func _cycle_axis() -> void:
	if selected == null:
		return
	_record_edit("axis", sel_list)
	for n in sel_list:
		var d: Dictionary = n.get_meta("data")
		if int(d.get("x", 0)) == 5:
			d["b"] = (int(d.get("b", 0)) + 1) % 3
	_update_selection()


func _refresh_behavior(d: Dictionary) -> void:
	var kind := clampi(int(d.get("x", 0)), 0, BEHAVIOR_NAMES.size() - 1)
	behavior_opt.select(kind)
	param_row.visible = (kind == 3 or kind == 5)
	axis_btn.visible = (kind == 5)
	if kind == 3:
		param_title.text = "Güç"
		param_val.text = "%.0f" % float(d.get("a", 18.0))
	elif kind == 5:
		param_title.text = "Mesafe"
		param_val.text = "%.0f" % float(d.get("a", 6.0))
		axis_btn.text = "Eksen: " + AXIS_NAMES[clampi(int(d.get("b", 0)), 0, 2)]


func _paint_nodes(nodes: Array) -> void:
	_record_edit("paint", nodes)
	for n in nodes:
		var d: Dictionary = n.get_meta("data")
		d["c"] = cur_color
		PartFactory.refresh(n)
	_update_selection()


func _duplicate() -> void:
	if sel_list.is_empty():
		return
	if parts_root.get_child_count() + sel_list.size() > Game.MAX_PARTS:
		_status("Parça sınırı doldu (%d)" % Game.MAX_PARTS)
		return
	var created: Array = []
	var subs: Array = []
	for n in sel_list:
		var d: Dictionary = (n.get_meta("data") as Dictionary).duplicate()
		d["n"] = ""  # kopya otomatik ad alır
		var s: Vector3 = d["s"]
		d["p"] = (d["p"] as Vector3) + Vector3(0, s.y, 0)
		var body := add_part(d)
		_explorer_add(body)
		subs.append({"type": "tree", "node": body, "index": body.get_index()})
		created.append(body)
	_push(_entry_of(subs))
	_set_selection(created)
	_status("Kopyalandı: %d parça" % created.size())


func _delete_selected() -> void:
	if not sel_list.is_empty():
		_delete_nodes(sel_list.duplicate())


func _delete_nodes(nodes: Array) -> void:
	var list: Array = nodes.duplicate()
	if list.is_empty():
		return
	# seçimden çıkar (Gezgin hâlâ tutarlıyken)
	var rest: Array = []
	for s in sel_list:
		if not list.has(s):
			rest.append(s)
	_set_selection(rest)
	# yüksek sıradan başa doğru kaldır; geri alırken sıra bozulmaz
	list.sort_custom(func(a: Node, b: Node) -> bool: return a.get_index() > b.get_index())
	var subs: Array = []
	for n in list:
		var idx: int = (n as Node).get_index()
		parts_root.remove_child(n)
		subs.append({"type": "tree", "node": n, "index": idx})
	_push(_entry_of(subs))  # silinen parçalar geri alınabilsin diye bellekte kalır
	_explorer_rebuild()
	_status("Silindi: %d parça" % list.size())


# ------------------------------------------------------------------ +/- düğmesi basılı tutma
func _hold_start(cb: Callable) -> void:
	cb.call()
	_hold_cb = cb
	_hold_t = -0.35  # tekrar başlamadan önce kısa bekleme


func _hold_stop() -> void:
	_hold_cb = Callable()


# ------------------------------------------------------------------ Geri al / Yinele
## Kayıt türleri:
##   "mod"   : parça verisi değişti (before = önceki veri)
##   "tree"  : parça eklendi/silindi (index = ağaçtaki sırası). Aynı kayıt iki yönde çalışır.
##   "group" : birden çok kaydı tek adımda toplar (çoklu seçim işlemleri)
func _entry_of(subs: Array) -> Dictionary:
	if subs.size() == 1:
		return subs[0]
	return {"type": "group", "entries": subs}


func _push(entry: Dictionary) -> void:
	_last_key = ""
	for e in redo_stack:
		_drop(e)
	redo_stack.clear()
	undo_stack.append(entry)
	if undo_stack.size() > 100:
		_drop(undo_stack.pop_front())
	_update_history_buttons()


func _sig(nodes: Array) -> int:
	var h := 7
	for n in nodes:
		h = h * 31 + (n as Object).get_instance_id()
	return h


## Düzenleme YAPILMADAN ÖNCE çağrılır. Peş peşe aynı türde düzenlemeler (basılı tutma)
## aynı parçalar üzerinde tek geri alma adımında birleşir.
func _record_edit(key: String, nodes: Array) -> void:
	var sig := _sig(nodes)
	var now := Time.get_ticks_msec()
	if key == _last_key and sig == _last_sig and now - _last_msec < 800 \
			and redo_stack.is_empty() and not undo_stack.is_empty():
		_last_msec = now
		return
	var subs: Array = []
	for n in nodes:
		subs.append({"type": "mod", "node": n, "before": (n.get_meta("data") as Dictionary).duplicate()})
	if subs.is_empty():
		return
	_push(_entry_of(subs))
	_last_key = key
	_last_sig = sig
	_last_msec = now


## Ağaçta olmayan (silinmiş) parçayı kalıcı olarak serbest bırakır.
func _drop(e: Dictionary) -> void:
	if e["type"] == "group":
		for sub in e["entries"]:
			_drop(sub)
		return
	if e["type"] != "tree":
		return
	var node: Variant = e["node"]
	if is_instance_valid(node) and (node as Node).get_parent() == null:
		(node as Node).free()


func _entry_nodes(e: Dictionary) -> Array:
	if e["type"] == "group":
		var out: Array = []
		for sub in e["entries"]:
			out.append_array(_entry_nodes(sub))
		return out
	if e["type"] == "guimod" or e["type"] == "guitree":
		return []
	return [e["node"]]


## Kaydı ters yönde uygular; kayıt kendini tersine çevirir (aynı kayıt diğer yığına gider).
func _flip(e: Dictionary) -> void:
	if e["type"] == "group":
		var list: Array = e["entries"]
		list.reverse()  # geri alırken sondan başa, yinelerken baştan sona
		for sub in list:
			_flip(sub)
		return
	if e["type"] == "guimod":
		var gd: Dictionary = e["data"]
		var gcur := gd.duplicate()
		gd.clear()
		gd.merge(e["before"])
		e["before"] = gcur
		return
	if e["type"] == "guitree":
		var gd2: Dictionary = e["data"]
		var gidx := _gui_index(int(gd2["id"]))
		if gidx >= 0:
			e["index"] = gidx
			Game.gui_items.remove_at(gidx)
		else:
			Game.gui_items.insert(clampi(int(e["index"]), 0, Game.gui_items.size()), gd2)
		return
	var node := e["node"] as StaticBody3D
	if e["type"] == "tree":
		if node.get_parent() == parts_root:
			e["index"] = node.get_index()
			parts_root.remove_child(node)
		else:
			parts_root.add_child(node)
			parts_root.move_child(node, mini(int(e["index"]), parts_root.get_child_count() - 1))
	else:
		var d: Dictionary = node.get_meta("data")
		var cur := d.duplicate()
		d.clear()
		d.merge(e["before"])
		e["before"] = cur
		PartFactory.refresh(node)


func _undo() -> void:
	if undo_stack.is_empty():
		_status("Geri alınacak bir şey yok")
		return
	_set_selection([])
	var e: Dictionary = undo_stack.pop_back()
	_flip(e)
	redo_stack.append(e)
	_after_history(e, "Geri alındı")


func _redo() -> void:
	if redo_stack.is_empty():
		_status("Yinelenecek bir şey yok")
		return
	_set_selection([])
	var e: Dictionary = redo_stack.pop_back()
	_flip(e)
	undo_stack.append(e)
	_after_history(e, "Yinelendi")


func _after_history(e: Dictionary, verb: String) -> void:
	_last_key = ""
	_explorer_rebuild()
	var gids := _entry_gui_ids(e)
	if not gids.is_empty():
		_gui_rebuild()
		_gui_select(int(gids[0]) if _gui_index(int(gids[0])) >= 0 else -1)
	var valid: Array = []
	for n in _entry_nodes(e):
		if is_instance_valid(n) and (n as Node).get_parent() == parts_root:
			valid.append(n)
	_set_selection(valid)
	_update_history_buttons()
	if valid.size() == 1:
		_status("%s: %s" % [verb, _label_of(valid[0])])
	else:
		_status("%s: %d parça" % [verb, maxi(valid.size(), 1)])


func _update_history_buttons() -> void:
	if undo_btn != null:
		undo_btn.disabled = undo_stack.is_empty()
	if redo_btn != null:
		redo_btn.disabled = redo_stack.is_empty()
	if gui_undo_btn != null:
		gui_undo_btn.disabled = undo_stack.is_empty()
	if gui_redo_btn != null:
		gui_redo_btn.disabled = redo_stack.is_empty()


func _clear_history() -> void:
	for e in undo_stack:
		_drop(e)
	for e in redo_stack:
		_drop(e)
	undo_stack.clear()
	redo_stack.clear()
	_last_key = ""
	_update_history_buttons()


# ------------------------------------------------------------------ StarterGui (arayüz) editörü
## "Arayüz" sekmesi: oyun içinde görünecek Çerçeve / Etiket / Düğme öğeleri tasarlanır.
## Öğeler ekran oranlarıyla (0..1) saklanır; her cihazda aynı yerde görünür. Play'de en üstte çizilir.
const GUI_TYPES: Array[String] = ["Çerçeve", "Etiket", "Düğme"]
const GUI_ACTIONS: Array[String] = ["Eylem: Yok", "Eylem: Başa dön", "Eylem: Menüye dön"]


func _fill_gui(p: Control) -> void:
	var g := _group(p, "Ekle")
	_rb(g, "gui_frame", "Çerçeve", _gui_add.bind(0), 84.0)
	_rb(g, "gui_label", "Etiket", _gui_add.bind(1))
	_rb(g, "gui_button", "Düğme", _gui_add.bind(2))
	g = _group(p, "Düzenle")
	_rb(g, "copy", "Kopyala", _gui_duplicate)
	_rb(g, "delete", "Sil", _gui_delete)
	_rb(g, "dot", "Bırak", func() -> void: _gui_select(-1))
	g = _group(p, "Geçmiş")
	gui_undo_btn = _rb(g, "undo", "Geri Al", _undo)
	gui_redo_btn = _rb(g, "redo", "Yinele", _redo)
	g = _group(p, "İpucu")
	g.add_child(_small_label("Metne {can} {ölüm} {fps} {oyun} yazarsan Play'de canlı değer gösterilir"))


func _build_gui_props(parent: VBoxContainer) -> void:
	gui_sc = ScrollContainer.new()
	gui_sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	gui_sc.custom_minimum_size = Vector2(0, 120)
	gui_sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	gui_sc.visible = false
	parent.add_child(gui_sc)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 4)
	gui_sc.add_child(box)

	g_name = LineEdit.new()
	g_name.placeholder_text = "Öğe adı"
	g_name.custom_minimum_size = Vector2(0, 52)
	g_name.text_submitted.connect(_on_gname_submitted)
	g_name.focus_exited.connect(_on_gname_exit)
	box.add_child(g_name)

	g_text_box = VBoxContainer.new()
	box.add_child(g_text_box)
	g_text_box.add_child(_small_label("Metin"))
	g_text = LineEdit.new()
	g_text.placeholder_text = "Metin"
	g_text.custom_minimum_size = Vector2(0, 52)
	g_text.text_submitted.connect(_on_gtext_submitted)
	g_text.focus_exited.connect(_on_gtext_exit)
	g_text_box.add_child(g_text)

	box.add_child(_small_label("Konum ve boyut (% ekran)"))
	_gui_row(box, "X", "x", 0.01)
	_gui_row(box, "Y", "y", 0.01)
	_gui_row(box, "En", "w", 0.01)
	_gui_row(box, "Boy", "h", 0.01)
	g_font_box = VBoxContainer.new()
	box.add_child(g_font_box)
	_gui_row(g_font_box, "Yazı", "fs", 2.0)

	box.add_child(_small_label("Renk"))
	var flow := HFlowContainer.new()
	flow.add_theme_constant_override("h_separation", 6)
	flow.add_theme_constant_override("v_separation", 6)
	var cg := ButtonGroup.new()
	for c in palette:
		var s := UIKit.swatch(c)
		s.custom_minimum_size = Vector2(46, 46)
		s.button_group = cg
		s.pressed.connect(_gui_set_color.bind(c))
		flow.add_child(s)
	box.add_child(flow)

	g_action_box = VBoxContainer.new()
	box.add_child(g_action_box)
	g_action_opt = OptionButton.new()
	g_action_opt.custom_minimum_size = Vector2(0, 52)
	g_action_opt.focus_mode = Control.FOCUS_NONE
	for nm in GUI_ACTIONS:
		g_action_opt.add_item(nm)
	g_action_opt.item_selected.connect(_gui_set_action)
	g_action_box.add_child(g_action_opt)


func _gui_row(parent: Control, title: String, field: String, step: float) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var l := Label.new()
	l.text = title
	l.custom_minimum_size = Vector2(60, 0)
	row.add_child(l)
	var minus := UIKit.btn("-", Vector2(64, 46))
	minus.button_down.connect(_hold_start.bind(_gui_adjust.bind(field, -step)))
	minus.button_up.connect(_hold_stop)
	row.add_child(minus)
	var v := Label.new()
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(v)
	var plus := UIKit.btn("+", Vector2(64, 46))
	plus.button_down.connect(_hold_start.bind(_gui_adjust.bind(field, step)))
	plus.button_up.connect(_hold_stop)
	row.add_child(plus)
	g_vals[field] = v
	parent.add_child(row)


func _fill_gui_props(d: Dictionary) -> void:
	var t := int(d["t"])
	if not g_name.has_focus():
		g_name.text = str(d["n"])
	if not g_text.has_focus():
		g_text.text = str(d["tx"])
	g_text_box.visible = t != 0
	g_font_box.visible = t != 0
	g_action_box.visible = t == 2
	for f in ["x", "y", "w", "h"]:
		(g_vals[f] as Label).text = "%d%%" % int(round(float(d[f]) * 100.0))
	(g_vals["fs"] as Label).text = str(int(d["fs"]))
	g_action_opt.select(clampi(int(d["ac"]), 0, 2))


func _set_gui_mode(on: bool) -> void:
	if gui_mode == on:
		return
	gui_mode = on
	gui_canvas.visible = on
	_update_overlays()
	_set_expanded(true, not on)  # Gezgin'de Workspace <-> StarterGui
	_set_expanded(false, on)
	_sync_doc_tab()
	if on:
		_layout_gui()
		_status("Arayüz (StarterGui): öğe ekle, sürükleyerek yerleştir")
	_update_count()
	_refresh_props()


## Oyun ekranının (en-boy oranı korunarak) önizleme çerçevesi ve içindeki öğeler.
func _layout_gui() -> void:
	if gui_canvas == null or not gui_canvas.visible:
		return
	var area := gui_canvas.size
	var vp := get_viewport().get_visible_rect().size
	var aspect := vp.x / maxf(vp.y, 1.0)
	var w := minf(area.x, area.y * aspect)
	var h := w / aspect
	screen_rect.size = Vector2(w, h)
	screen_rect.position = (area - Vector2(w, h)) * 0.5
	var fs := _gui_font_scale()
	for v in gui_views:
		v.apply_layout(screen_rect.size, fs)


func _gui_font_scale() -> float:
	return screen_rect.size.y / maxf(get_viewport().get_visible_rect().size.y, 1.0)


func _gui_index(id: int) -> int:
	for i in Game.gui_items.size():
		if int(Game.gui_items[i]["id"]) == id:
			return i
	return -1


func _gui_sel() -> Dictionary:
	var i := _gui_index(gui_sel_id)
	if i < 0:
		return {}
	return Game.gui_items[i]


func _gui_view_of(id: int) -> GuiItemView:
	for v in gui_views:
		if int(v.data["id"]) == id:
			return v
	return null


func _gui_rebuild() -> void:
	for v in gui_views:
		screen_rect.remove_child(v)
		v.queue_free()
	gui_views.clear()
	for d in Game.gui_items:
		var v := GuiItemView.new()
		screen_rect.add_child(v)
		v.setup(d, true)
		v.tapped_item.connect(_on_gui_tapped)
		v.drag_started.connect(_on_gui_drag_started)
		v.dragged_item.connect(_on_gui_dragged)
		gui_views.append(v)
	gui_counter = maxi(gui_counter, Game.gui_items.size())
	if _gui_index(gui_sel_id) < 0:
		gui_sel_id = -1
	for v in gui_views:
		v.selected = (int(v.data["id"]) == gui_sel_id)
	_gui_list_refresh()
	_layout_gui()
	_refresh_props()


func _gui_list_refresh() -> void:
	gui_list.clear()
	for d in Game.gui_items:
		gui_list.add_item(str(d["n"]))
	var idx := _gui_index(gui_sel_id)
	if idx >= 0:
		gui_list.select(idx)
	_update_count()


func _gui_select(id: int) -> void:
	# Ad/metin kutusunda yazılan metin, seçim değişmeden önce ESKİ öğeye kaydedilsin
	if g_name != null and g_name.has_focus():
		g_name.release_focus()
	if g_text != null and g_text.has_focus():
		g_text.release_focus()
	gui_sel_id = id
	for v in gui_views:
		v.selected = (int(v.data["id"]) == id)
	var idx := _gui_index(id)
	if idx >= 0 and idx < gui_list.item_count:
		gui_list.select(idx)
	else:
		gui_list.deselect_all()
	_refresh_props()


func _on_gui_list_selected(idx: int) -> void:
	if not gui_mode:
		_goto_tab(4)  # StarterGui öğesi seçilince Arayüz sekmesine geç
	if idx >= 0 and idx < Game.gui_items.size():
		_gui_select(int(Game.gui_items[idx]["id"]))


func _on_gui_tapped(view: GuiItemView) -> void:
	_gui_select(int(view.data["id"]))


func _on_screen_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and (event as InputEventScreenTouch).pressed:
		_gui_select(-1)


func _on_gui_drag_started(view: GuiItemView) -> void:
	_record_gui_edit("guidrag", [view.data])
	_last_key = ""  # her sürükleme ayrı bir geri alma adımı olsun


func _on_gui_dragged(view: GuiItemView, rel: Vector2) -> void:
	var d := view.data
	var sz := screen_rect.size
	if sz.x <= 0.0 or sz.y <= 0.0:
		return
	d["x"] = clampf(float(d["x"]) + rel.x / sz.x, 0.0, maxf(0.0, 1.0 - float(d["w"])))
	d["y"] = clampf(float(d["y"]) + rel.y / sz.y, 0.0, maxf(0.0, 1.0 - float(d["h"])))
	view.apply_layout(sz, _gui_font_scale())
	_refresh_props()


func _gui_defaults(t: int) -> Dictionary:
	match t:
		1:
			return {"t": 1, "tx": "Merhaba", "x": 0.4, "y": 0.05, "w": 0.2, "h": 0.08,
				"c": Color.WHITE, "fs": 28, "ac": 0}
		2:
			return {"t": 2, "tx": "Düğme", "x": 0.4, "y": 0.85, "w": 0.2, "h": 0.1,
				"c": Color(0.2, 0.5, 0.95), "fs": 28, "ac": 0}
		_:
			return {"t": 0, "tx": "", "x": 0.35, "y": 0.3, "w": 0.3, "h": 0.3,
				"c": Color(0.1, 0.15, 0.3, 0.7), "fs": 28, "ac": 0}


func _gui_add(t: int) -> void:
	gui_counter += 1
	var d := _gui_defaults(t)
	d["id"] = Game.next_gui_id()
	d["n"] = "%s %d" % [GUI_TYPES[t], gui_counter]
	Game.gui_items.append(d)
	_push({"type": "guitree", "data": d, "index": Game.gui_items.size() - 1})
	gui_sel_id = int(d["id"])
	_gui_rebuild()
	_status("Eklendi: " + str(d["n"]))


func _gui_duplicate() -> void:
	var src := _gui_sel()
	if src.is_empty():
		return
	gui_counter += 1
	var d := src.duplicate()
	d["id"] = Game.next_gui_id()
	d["n"] = "%s %d" % [GUI_TYPES[int(d["t"])], gui_counter]
	d["x"] = clampf(float(d["x"]) + 0.02, 0.0, maxf(0.0, 1.0 - float(d["w"])))
	d["y"] = clampf(float(d["y"]) + 0.02, 0.0, maxf(0.0, 1.0 - float(d["h"])))
	Game.gui_items.append(d)
	_push({"type": "guitree", "data": d, "index": Game.gui_items.size() - 1})
	gui_sel_id = int(d["id"])
	_gui_rebuild()
	_status("Kopyalandı: " + str(d["n"]))


func _gui_delete() -> void:
	var idx := _gui_index(gui_sel_id)
	if idx < 0:
		return
	var d: Dictionary = Game.gui_items[idx]
	Game.gui_items.remove_at(idx)
	_push({"type": "guitree", "data": d, "index": idx})
	gui_sel_id = -1
	_gui_rebuild()
	_status("Silindi: " + str(d["n"]))


## field: x, y, w, h (ekran oranı) veya fs (yazı boyutu)
func _gui_adjust(field: String, delta: float) -> void:
	var d := _gui_sel()
	if d.is_empty():
		return
	_record_gui_edit("gui_" + field, [d])
	if field == "fs":
		d["fs"] = clampi(int(d["fs"]) + int(delta), 10, 96)
	else:
		var v := snappedf(float(d[field]) + delta, 0.005)
		if field == "w" or field == "h":
			d[field] = clampf(v, 0.02, 1.0)
		else:
			d[field] = clampf(v, 0.0, 1.0)
	var view := _gui_view_of(int(d["id"]))
	if view != null:
		view.apply_layout(screen_rect.size, _gui_font_scale())
	_refresh_props()


func _gui_set_color(c: Color) -> void:
	var d := _gui_sel()
	if d.is_empty():
		return
	_record_gui_edit("guicolor", [d])
	d["c"] = c
	var view := _gui_view_of(int(d["id"]))
	if view != null:
		view.rebuild()


func _gui_set_action(idx: int) -> void:
	var d := _gui_sel()
	if d.is_empty():
		return
	_record_gui_edit("guiaction", [d])
	d["ac"] = idx


func _on_gname_submitted(text: String) -> void:
	_gui_rename(text)
	g_name.release_focus()


func _on_gname_exit() -> void:
	_gui_rename(g_name.text)


func _on_gtext_submitted(text: String) -> void:
	_gui_set_text(text)
	g_text.release_focus()


func _on_gtext_exit() -> void:
	_gui_set_text(g_text.text)


func _gui_rename(text: String) -> void:
	var d := _gui_sel()
	var t := text.strip_edges()
	if d.is_empty() or t == "" or t == str(d["n"]):
		return
	_record_gui_edit("guiname", [d])
	d["n"] = t
	_gui_list_refresh()
	_status("Ad: " + t)


func _gui_set_text(text: String) -> void:
	var d := _gui_sel()
	if d.is_empty() or text == str(d["tx"]):
		return
	_record_gui_edit("guitext", [d])
	d["tx"] = text
	var view := _gui_view_of(int(d["id"]))
	if view != null:
		view.refresh_text({})


## GUI düzenlemesi YAPILMADAN ÖNCE çağrılır (geri alma için önceki hâli saklar).
func _record_gui_edit(key: String, items: Array) -> void:
	var sig := 1000003
	for d in items:
		sig = sig * 31 + int((d as Dictionary)["id"])
	var now := Time.get_ticks_msec()
	if key == _last_key and sig == _last_sig and now - _last_msec < 800 \
			and redo_stack.is_empty() and not undo_stack.is_empty():
		_last_msec = now
		return
	var subs: Array = []
	for d in items:
		subs.append({"type": "guimod", "data": d, "before": (d as Dictionary).duplicate()})
	if subs.is_empty():
		return
	_push(_entry_of(subs))
	_last_key = key
	_last_sig = sig
	_last_msec = now


func _entry_gui_ids(e: Dictionary) -> Array:
	if e["type"] == "group":
		var out: Array = []
		for sub in e["entries"]:
			out.append_array(_entry_gui_ids(sub))
		return out
	if e["type"] == "guimod" or e["type"] == "guitree":
		return [int((e["data"] as Dictionary)["id"])]
	return []


# ------------------------------------------------------------------ Script editörü
## MobileBlox Script (bkz. mb_script.gd): parçalara (ontouch) ya da oyuna genel (onstart / every) kod yazılır.
## Parça script'i parçanın verisinde ("sc"), genel script'ler Game.scripts içinde saklanır.
## Luau (Roblox'un dili): parçalara ve oyuna script yazılır. Parça script'inde `script.Parent` = parça.
## Eski MobileBlox Script'i (onstart: / ontouch: / every N:) hâlâ çalışır; otomatik algılanır.
const SCRIPT_TEMPLATES: Array[Dictionary] = [
	{"n": "Dokun: hasar", "c": "local part = script.Parent\n\npart.Touched:Connect(function(hit)\n    local humanoid = hit.Parent:FindFirstChild(\"Humanoid\")\n    if humanoid then\n        humanoid:TakeDamage(25)\n    end\nend)\n"},
	{"n": "Genel: leaderstats", "c": "game.Players.PlayerAdded:Connect(function(player)\n    local stats = Instance.new(\"Folder\")\n    stats.Name = \"leaderstats\"\n    stats.Parent = player\n\n    local puan = Instance.new(\"IntValue\")\n    puan.Name = \"Puan\"\n    puan.Value = 0\n    puan.Parent = stats\nend)\n"},
	{"n": "Parça: puan topla", "c": "local part = script.Parent\nlocal alindi = false\n\npart.Touched:Connect(function(hit)\n    if alindi then return end\n    if hit.Parent:FindFirstChild(\"Humanoid\") then\n        alindi = true\n        local player = game.Players:GetPlayerFromCharacter(hit.Parent)\n        player.leaderstats.Puan.Value += 1\n        part:Destroy()\n    end\nend)\n"},
	{"n": "Işınlayıcı", "c": "local part = script.Parent\n\npart.Touched:Connect(function(hit)\n    local root = hit.Parent:FindFirstChild(\"HumanoidRootPart\")\n    if root then\n        root.CFrame = CFrame.new(0, 20, 0)\n    end\nend)\n"},
	{"n": "Kaybolan platform", "c": "local part = script.Parent\n\nwhile true do\n    wait(2)\n    part.Transparency = 1\n    part.CanCollide = false\n    wait(2)\n    part.Transparency = 0\n    part.CanCollide = true\nend\n"},
	{"n": "Renk döngüsü", "c": "local part = script.Parent\n\nwhile true do\n    part.BrickColor = BrickColor.new(\"Bright red\")\n    wait(1)\n    part.BrickColor = BrickColor.new(\"Bright blue\")\n    wait(1)\nend\n"},
	{"n": "Zıplatıcı", "c": "local part = script.Parent\n\npart.Touched:Connect(function(hit)\n    if hit.Parent:FindFirstChild(\"Humanoid\") then\n        hit.Velocity = Vector3.new(0, 90, 0)\n    end\nend)\n"},
	{"n": "Kapı (Tween)", "c": "local part = script.Parent\nlocal TweenService = game:GetService(\"TweenService\")\nlocal acik = false\n\npart.Touched:Connect(function(hit)\n    if acik then return end\n    if hit.Parent:FindFirstChild(\"Humanoid\") then\n        acik = true\n        local info = TweenInfo.new(1)\n        TweenService:Create(part, info, {Position = part.Position + Vector3.new(0, 6, 0)}):Play()\n        wait(3)\n        TweenService:Create(part, info, {Position = part.Position - Vector3.new(0, 6, 0)}):Play()\n        acik = false\n    end\nend)\n"},
	{"n": "Genel: geri sayım", "c": "for i = 10, 1, -1 do\n    print(i)\n    wait(1)\nend\nprint(\"Süre doldu!\")\ngame.Players.LocalPlayer.Character.Humanoid.Health = 0\n"},
]
const SCRIPT_HELP := "[b]Luau (Roblox dili)[/b]\n\n[color=#4da6ff]Nesneler[/color]\nscript.Parent  (parça)\ngame, workspace\ngame.Players.LocalPlayer\nhit.Parent:FindFirstChild(\"Humanoid\")\n\n[color=#ffa94d]Parça[/color]\nPosition, Size, Color, BrickColor\nTransparency, CanCollide, Name\nCFrame, Orientation\n:Destroy() :Clone()\n.Touched / .TouchEnded\n\n[color=#c792ea]Humanoid[/color]\nHealth, MaxHealth\nWalkSpeed, JumpPower\n:TakeDamage(n)   .Died\n\n[color=#7ee787]Diğer[/color]\nInstance.new(\"Part\"/\"Folder\"/\"IntValue\")\nVector3, Color3, CFrame, BrickColor\nTweenService:Create(p,TweenInfo.new(s),{...})\nwait(), task.wait(), spawn()\nRunService.Heartbeat\nprint warn pcall math string table\n\nleaderstats klasörü ekranda görünür.\nplayer.leaderstats.Puan.Value += 1\n\n[color=#8a8a8a]Yok: GUI (UDim2), Sound, Raycast, DataStore.[/color]"


func _fill_script(p: Control) -> void:
	var g := _group(p, "Script")
	_rb(g, "script_new", "Genel Script", _script_new_global, 90.0)
	_rb(g, "script", "Parçaya Ekle", _script_add_to_part, 96.0)
	_rb(g, "delete", "Sil", _script_delete)
	g = _group(p, "Kod")
	_rb(g, "check", "Denetle", _script_report)
	_rb(g, "indent", "Girinti", _script_indent.bind(1))
	_rb(g, "dedent", "Geri Gir.", _script_indent.bind(-1))
	g = _group(p, "Şablon")
	tpl_btn = _rb(g, "script", "Şablon: " + str(SCRIPT_TEMPLATES[0]["n"]), _script_insert_template, 190.0)
	g = _group(p, "Yardım")
	_rb(g, "help", "Komutlar", _script_toggle_help)


func _make_highlighter() -> CodeHighlighter:
	var h := CodeHighlighter.new()
	h.number_color = Color(0.55, 0.85, 0.55)
	h.symbol_color = Color(0.80, 0.80, 0.80)
	h.function_color = Color(0.86, 0.86, 0.86)
	h.member_variable_color = Color(0.86, 0.86, 0.86)
	for w in ["and", "break", "continue", "do", "else", "elseif", "end", "for", "function", "if", "in",
			"local", "not", "or", "repeat", "return", "then", "until", "while"]:
		h.add_keyword_color(w, Color(0.78, 0.57, 0.92))
	for w in ["nil", "true", "false", "self"]:
		h.add_keyword_color(w, Color(0.30, 0.65, 1.0))
	for w in ["game", "workspace", "script", "Instance", "Vector3", "Color3", "CFrame", "BrickColor", "TweenInfo",
			"Enum", "Random", "print", "warn", "error", "wait", "spawn", "delay", "tick", "pcall", "assert",
			"type", "typeof", "tostring", "tonumber", "pairs", "ipairs", "select", "unpack", "math", "string",
			"table", "os", "task",
			"onstart", "ontouch", "every", "say", "set", "add", "heal", "damage", "kill", "respawn", "teleport",
			"bounce", "move", "color", "hide", "show", "destroy"]:
		h.add_keyword_color(w, Color(1.0, 0.66, 0.30))
	h.add_color_region("--[[", "]]", Color(0.45, 0.52, 0.45), false)
	h.add_color_region("--", "", Color(0.45, 0.52, 0.45), true)
	h.add_color_region("\"", "\"", Color(0.65, 0.85, 0.50), true)
	h.add_color_region("'", "'", Color(0.65, 0.85, 0.50), true)
	h.add_color_region("#", "", Color(0.45, 0.52, 0.45), true)
	return h


func _build_script_canvas() -> void:
	script_canvas = PanelContainer.new()
	script_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	script_canvas.visible = false
	script_canvas.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.12, 0.12, 0.12), 0, Color(0.09, 0.09, 0.09), 1, 0))
	viewport_area.add_child(script_canvas)
	script_canvas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 0)
	script_canvas.add_child(sv)

	var head := PanelContainer.new()
	head.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.13, 0.13, 0.13), 0, Color(0.09, 0.09, 0.09), 1, 6))
	script_title = Label.new()
	script_title.clip_text = true
	head.add_child(script_title)
	sv.add_child(head)

	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 0)
	sv.add_child(row)

	code_edit = CodeEdit.new()
	code_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	code_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	code_edit.gutters_draw_line_numbers = true
	code_edit.indent_automatic = true
	code_edit.indent_use_spaces = true
	code_edit.indent_size = 4
	code_edit.auto_brace_completion_enabled = true
	code_edit.syntax_highlighter = _make_highlighter()
	code_edit.add_theme_font_size_override("font_size", 24)
	code_edit.add_theme_stylebox_override("normal", UIKit.flat_box(Color(0.10, 0.10, 0.10), 0, Color(0, 0, 0, 0), 0, 6))
	code_edit.add_theme_color_override("font_color", Color(0.90, 0.90, 0.90))
	code_edit.add_theme_color_override("caret_color", Color(1, 1, 1))
	code_edit.add_theme_color_override("line_number_color", Color(0.45, 0.45, 0.45))
	code_edit.add_theme_color_override("current_line_color", Color(1, 1, 1, 0.05))
	code_edit.editable = false
	code_edit.text_changed.connect(_on_code_changed)
	row.add_child(code_edit)

	help_panel = PanelContainer.new()
	help_panel.custom_minimum_size = Vector2(300, 0)
	help_panel.visible = false
	var help := RichTextLabel.new()
	help.bbcode_enabled = true
	help.text = SCRIPT_HELP
	help.add_theme_font_size_override("normal_font_size", 18)
	help.add_theme_font_size_override("bold_font_size", 20)
	help_panel.add_child(help)
	row.add_child(help_panel)

	var foot := PanelContainer.new()
	foot.add_theme_stylebox_override("panel", UIKit.flat_box(Color(0.13, 0.13, 0.13), 0, Color(0.09, 0.09, 0.09), 1, 6))
	script_err = Label.new()
	script_err.clip_text = true
	foot.add_child(script_err)
	sv.add_child(foot)


func _update_overlays() -> void:
	var overlay := gui_mode or script_mode
	joy.visible = not overlay
	cam_ctrl.visible = not overlay


## Şerit ve belge sekmelerini (3D / StarterGui / Script) aynı duruma getirir.
func _sync_doc_tab() -> void:
	if doc_buttons.size() == 3:
		doc_buttons[2 if script_mode else (1 if gui_mode else 0)].set_pressed_no_signal(true)


func _set_script_mode(on: bool) -> void:
	if script_mode == on:
		return
	script_mode = on
	script_canvas.visible = on
	_update_overlays()
	_set_expanded_ss(on)
	if on:
		if selected != null:
			_script_open_part(selected, true)
		elif cur_script_kind == "":
			_script_show_none()
		_status("Script editörü (Luau): kod yaz, 'Denetle' ile kontrol et")
	_sync_doc_tab()


func _set_expanded_ss(on: bool) -> void:
	ss_header.expanded = on
	ss_box.visible = on


func _toggle_ss() -> void:
	_set_expanded_ss(not ss_header.expanded)


## Seçim değişince (Gezgin'den vb.) script editörü seçili parçayı açar.
func _script_sync_selection() -> void:
	if not script_mode or code_edit == null:
		return
	if selected != null:
		_script_open_part(selected)
	elif cur_script_kind == "part" and (not is_instance_valid(cur_script_node) or cur_script_node.get_parent() != parts_root):
		_script_show_none()


func _script_index(id: int) -> int:
	for i in Game.scripts.size():
		if int(Game.scripts[i]["id"]) == id:
			return i
	return -1


func _script_list_refresh() -> void:
	script_list.clear()
	for g in Game.scripts:
		script_list.add_item(str(g["n"]))
	if cur_script_kind == "global":
		var i := _script_index(cur_script_id)
		if i >= 0:
			script_list.select(i)
	_update_count()


func _on_script_list_selected(idx: int) -> void:
	if not script_mode:
		_goto_tab(5)
	if idx >= 0 and idx < Game.scripts.size():
		_script_open_global(int(Game.scripts[idx]["id"]))


func _refresh_item(body: StaticBody3D) -> void:
	var i := body.get_index()
	if body.get_parent() == parts_root and i < explorer.item_count:
		explorer.set_item_text(i, _item_text(body, sel_list.has(body)))


func _script_load_text(t: String) -> void:
	_script_loading = true
	code_edit.text = t
	_script_loading = false
	_script_check()


func _script_open_part(body: StaticBody3D, force: bool = false) -> void:
	if not force and cur_script_kind == "part" and cur_script_node == body:
		return
	cur_script_kind = "part"
	cur_script_node = body
	cur_script_id = -1
	var d: Dictionary = body.get_meta("data")
	var src := str(d.get("sc", ""))
	_script_load_text(src)
	code_edit.editable = true
	var hint := "" if src != "" else "   (boş: yaz ya da şablon ekle)"
	script_title.text = "Script - " + _label_of(body) + hint
	script_list.deselect_all()


func _script_open_global(id: int) -> void:
	var i := _script_index(id)
	if i < 0:
		_script_show_none()
		return
	cur_script_kind = "global"
	cur_script_node = null
	cur_script_id = id
	_script_load_text(str(Game.scripts[i]["src"]))
	code_edit.editable = true
	script_title.text = "Genel script - %s   (Luau; oyun başlayınca çalışır)" % str(Game.scripts[i]["n"])
	script_list.select(i)


func _script_show_none() -> void:
	cur_script_kind = ""
	cur_script_node = null
	cur_script_id = -1
	_script_load_text("")
	code_edit.editable = false
	script_title.text = "Script seçilmedi: Gezgin'den bir parça ya da script seç"
	script_err.text = ""


func _on_code_changed() -> void:
	if _script_loading:
		return
	var t := code_edit.text
	if cur_script_kind == "part":
		if is_instance_valid(cur_script_node) and cur_script_node.get_parent() == parts_root:
			var d: Dictionary = cur_script_node.get_meta("data")
			var had := str(d.get("sc", "")) != ""
			d["sc"] = t
			if had != (t != ""):
				_refresh_item(cur_script_node)
	elif cur_script_kind == "global":
		var i := _script_index(cur_script_id)
		if i >= 0:
			Game.scripts[i]["src"] = t
	_script_check()


## Kaynağı denetler: Luau ya da eski MobileBlox dili (otomatik algılanır). Hata listesi döner.
func _script_errors(src: String) -> Array:
	if LuauParser.is_legacy(src):
		return MBScript.compile(src)["errors"]
	var e := LuauParser.check(src)
	return [] if e == "" else [e]


func _script_lang(src: String) -> String:
	return "eski dil" if LuauParser.is_legacy(src) else "Luau"


func _script_check() -> void:
	if script_err == null or code_edit == null:
		return
	var txt := code_edit.text
	if txt.strip_edges() == "":
		script_err.text = "Boş script"
		script_err.modulate = Color(0.62, 0.64, 0.68)
		return
	var errs := _script_errors(txt)
	if errs.is_empty():
		script_err.text = "Sözdizimi hatası yok (%s)" % _script_lang(txt)
		script_err.modulate = Color(0.45, 0.85, 0.50)
	else:
		var more := "  (+%d hata daha)" % (errs.size() - 1) if errs.size() > 1 else ""
		script_err.text = str(errs[0]) + more
		script_err.modulate = Color(0.95, 0.45, 0.40)


func _script_report() -> void:
	if code_edit.text.strip_edges() == "":
		_status("Script boş")
		return
	var errs := _script_errors(code_edit.text)
	if errs.is_empty():
		_status("Script geçerli (%s). Çalışma zamanı hataları Play'de ekranda görünür." % _script_lang(code_edit.text))
	else:
		for e in errs:
			_status(str(e))


func _script_new_global() -> void:
	var id := Game.next_script_id()
	Game.scripts.append({"id": id, "n": "Script %d" % (Game.scripts.size() + 1), "src": "print(\"Merhaba Dünya!\")\n"})
	_script_list_refresh()
	_script_open_global(id)
	_status("Genel script eklendi")


func _script_add_to_part() -> void:
	if selected == null:
		_status("Önce Gezgin'den bir parça seç")
		return
	var d: Dictionary = selected.get_meta("data")
	if str(d.get("sc", "")) == "":
		d["sc"] = str(SCRIPT_TEMPLATES[0]["c"])
		_refresh_item(selected)
	_script_open_part(selected, true)
	_status("Parça script'i hazır: " + _label_of(selected))


func _script_delete() -> void:
	if cur_script_kind == "part" and is_instance_valid(cur_script_node):
		var d: Dictionary = cur_script_node.get_meta("data")
		d["sc"] = ""
		_refresh_item(cur_script_node)
		_script_open_part(cur_script_node, true)
		_status("Script silindi")
	elif cur_script_kind == "global":
		var i := _script_index(cur_script_id)
		if i >= 0:
			Game.scripts.remove_at(i)
		_script_show_none()
		_script_list_refresh()
		_status("Genel script silindi")


func _script_indent(dir: int) -> void:
	if cur_script_kind == "":
		return
	if dir > 0:
		code_edit.indent_lines()
	else:
		code_edit.unindent_lines()


func _script_insert_template() -> void:
	if cur_script_kind == "":
		_status("Önce bir script aç (parça seç ya da 'Genel Script' ekle)")
		return
	var t: Dictionary = SCRIPT_TEMPLATES[_tpl_idx]
	code_edit.insert_text_at_caret(str(t["c"]) + "\n")
	_tpl_idx = (_tpl_idx + 1) % SCRIPT_TEMPLATES.size()
	tpl_btn.caption = "Şablon: " + str(SCRIPT_TEMPLATES[_tpl_idx]["n"])
	_status("Şablon eklendi: " + str(t["n"]))


func _script_toggle_help() -> void:
	help_panel.visible = not help_panel.visible


# ------------------------------------------------------------------ Paylaş
## Oyunu paylaşılabilir metne çevirir. Metni GitHub'da games/ad.mbgame dosyasına yapıştırıp yeniden derlersen
## oyun herkese "yerleşik oyun" olarak görünür; ya da başkası "Oyun İçe Aktar" ile alır.
func _share() -> void:
	_commit()
	Game.save_world()
	var txt := Game.export_json(Game.current_id)
	if txt == "":
		_status("Paylaşma metni oluşturulamadı")
		return
	var layer := CanvasLayer.new()
	layer.layer = 50
	add_child(layer)
	var dim := ColorRect.new()
	dim.theme = UIKit.make_studio_theme()
	dim.color = Color(0, 0, 0, 0.75)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	dim.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	cc.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	panel.add_child(vb)
	var title := Label.new()
	title.text = "Oyunu Paylaş: " + Game.current_name()
	vb.add_child(title)
	var info := Label.new()
	info.text = "1) 'Panoya Kopyala'ya bas.\n2) GitHub'da  games/oyun-adi.mbgame  dosyası oluşturup yapıştır, derlemeyi yeniden çalıştır: oyunu indiren herkes görür.\n3) Ya da başkası bu metni More > Oyun İçe Aktar'a yapıştırır."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(700, 0)
	vb.add_child(info)
	var box := TextEdit.new()
	box.text = txt
	box.editable = false
	box.custom_minimum_size = Vector2(700, 200)
	vb.add_child(box)
	var msg := Label.new()
	vb.add_child(msg)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var copy := UIKit.btn("Panoya Kopyala", Vector2(220, 52))
	copy.pressed.connect(_share_copy.bind(txt, msg))
	row.add_child(copy)
	if OS.has_feature("web"):
		var dl := UIKit.btn("Dosya İndir", Vector2(180, 52))
		dl.pressed.connect(_share_download.bind(txt, msg))
		row.add_child(dl)
	var close := UIKit.btn("Kapat", Vector2(140, 52))
	close.pressed.connect(layer.queue_free)
	row.add_child(close)
	vb.add_child(row)


func _share_copy(txt: String, msg: Label) -> void:
	DisplayServer.clipboard_set(txt)
	msg.text = "Kopyalandı (%d karakter)" % txt.length()


func _share_download(txt: String, msg: Label) -> void:
	var fname := Game.current_name().to_lower().validate_filename().replace(" ", "-")
	JavaScriptBridge.download_buffer(txt.to_utf8_buffer(), fname + ".mbgame", "application/json")
	msg.text = "İndirildi: " + fname + ".mbgame"


# ------------------------------------------------------------------ Kaydet / Yükle / Geçiş
func _commit() -> void:
	Game.world_parts.clear()
	for n in parts_root.get_children():
		Game.world_parts.append(n.get_meta("data"))


func _save() -> void:
	_commit()
	if Game.save_world():
		_status("Kaydedildi: %d parça" % Game.world_parts.size())
	else:
		_status("Kayıt başarısız!")


func _load() -> void:
	if Game.load_world():
		_clear_history()
		_set_selection([])
		rebuild_parts()
		_explorer_rebuild()
		_gui_select(-1)
		_gui_rebuild()
		_script_show_none()
		_script_list_refresh()
		spawn_marker.position = Game.spawn_point
		_status("Yüklendi: %d parça" % Game.world_parts.size())
	else:
		_status("Kayıt bulunamadı")


func _play() -> void:
	_commit()
	Game.save_world()
	Game.goto("res://scenes/play.tscn")


func _go_menu() -> void:
	_commit()
	Game.save_world()
	Game.goto("res://scenes/main_menu.tscn")
