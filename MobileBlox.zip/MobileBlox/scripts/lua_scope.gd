class_name LuaScope
extends RefCounted
## Yerel değişken kapsamı (zincir).

var vars: Dictionary = {}
var parent: LuaScope = null
var varargs: Array = []


func _init(p: LuaScope = null) -> void:
	parent = p
	if p != null:
		varargs = p.varargs


func find(nm: String) -> LuaScope:
	var s: LuaScope = self
	while s != null:
		if s.vars.has(nm):
			return s
		s = s.parent
	return null
