class_name GuiItemView
extends Control
## StarterGui öğesi görünümü (Çerçeve / Etiket / Düğme). Hem Stüdyo editöründe hem Play'de kullanılır.
## data: {"id","t": 0 çerçeve | 1 etiket | 2 düğme, "n": ad, "tx": metin, "x","y","w","h": ekran oranı (0..1),
##        "c": renk, "fs": yazı boyutu, "ac": eylem (0 yok, 1 başa dön, 2 menüye dön)}
## Metinde {can} {ölüm} {fps} {oyun} yazılırsa Play'de canlı değerle değişir.

signal tapped_item(view: GuiItemView)
signal drag_started(view: GuiItemView)
signal dragged_item(view: GuiItemView, rel: Vector2)
signal drag_ended(view: GuiItemView)
signal action_requested(action: int)

var data: Dictionary = {}
var editable := false
var selected := false:
	set(v):
		selected = v
		queue_redraw()

var _body: Control
var _shown := "\u0001"  # son gösterilen metin (önbellek)
var _font_scale := 1.0
var _touch := -1
var _moved := 0.0
var _dragging := false


func setup(d: Dictionary, edit: bool) -> void:
	data = d
	editable = edit
	mouse_filter = Control.MOUSE_FILTER_STOP if edit else Control.MOUSE_FILTER_IGNORE
	rebuild()


## Türü/rengi değişince gövdeyi yeniden kurar.
func rebuild() -> void:
	if _body != null:
		remove_child(_body)
		_body.queue_free()
	var col: Color = data["c"]
	match int(data["t"]):
		1:
			var l := Label.new()
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			l.clip_text = true
			l.add_theme_color_override("font_color", col)
			l.add_theme_constant_override("outline_size", 4)
			l.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_body = l
		2:
			var b := Button.new()
			b.focus_mode = Control.FOCUS_NONE
			b.clip_text = true
			for state in ["normal", "hover", "pressed", "focus", "disabled"]:
				var sb := StyleBoxFlat.new()
				sb.set_corner_radius_all(12)
				sb.set_content_margin_all(6)
				var k := col
				if state == "hover":
					k = col.lightened(0.15)
				elif state == "pressed":
					k = col.darkened(0.25)
				sb.bg_color = k
				b.add_theme_stylebox_override(state, sb)
			if editable:
				b.mouse_filter = Control.MOUSE_FILTER_IGNORE
			else:
				b.mouse_filter = Control.MOUSE_FILTER_STOP
				b.pressed.connect(func() -> void: action_requested.emit(int(data.get("ac", 0))))
			_body = b
		_:
			var p := Panel.new()
			var sb2 := StyleBoxFlat.new()
			sb2.bg_color = col
			sb2.set_corner_radius_all(12)
			p.add_theme_stylebox_override("panel", sb2)
			p.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_body = p
	add_child(_body)
	_body.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_shown = "\u0001"
	refresh_text({})
	_apply_font()
	queue_redraw()


## Konum/boyut ekran oranlarından; yazı boyutu font_scale ile ölçeklenir.
func apply_layout(area: Vector2, font_scale: float) -> void:
	position = Vector2(float(data["x"]) * area.x, float(data["y"]) * area.y)
	size = Vector2(float(data["w"]) * area.x, float(data["h"]) * area.y)
	_font_scale = font_scale
	_apply_font()
	queue_redraw()


func _apply_font() -> void:
	if _body is Label or _body is Button:
		_body.add_theme_font_size_override("font_size", maxi(8, int(float(data.get("fs", 28)) * _font_scale)))


## tokens boşsa ham metin gösterilir (editör); Play'de {can} vb. değiştirilir.
func refresh_text(tokens: Dictionary) -> void:
	if not (_body is Label or _body is Button):
		return
	var t := str(data.get("tx", ""))
	for k in tokens:
		t = t.replace("{%s}" % str(k), str(tokens[k]))
	if t != _shown:
		_shown = t
		_body.set("text", t)


func _draw() -> void:
	if not editable:
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color(1, 1, 1, 0.25), false, 1.0)
	if selected:
		draw_rect(Rect2(Vector2.ZERO, size), Color(1.0, 0.9, 0.2), false, 3.0)


func _gui_input(event: InputEvent) -> void:
	if not editable:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed and _touch == -1:
			_touch = t.index
			_moved = 0.0
			_dragging = false
			tapped_item.emit(self)
		elif not t.pressed and t.index == _touch:
			_touch = -1
			if _dragging:
				_dragging = false
				drag_ended.emit(self)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index != _touch:
			return
		_moved += d.relative.length()
		if not _dragging and _moved > 6.0:
			_dragging = true
			drag_started.emit(self)
		if _dragging:
			dragged_item.emit(self, d.relative)
