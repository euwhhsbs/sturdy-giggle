class_name MBScript
extends RefCounted
## MobileBlox Script: girintiyle bloklanan, güvenli ve basit bir betik dili (dosya/sistem erişimi YOK).
##
##   onstart:            oyun başlayınca bir kez
##   ontouch:            karakter bu parçaya değince (yalnızca parça script'lerinde)
##   every 3:            her 3 saniyede bir
##
## Komutlar: say "metin" [sn] | set ad değer | add ad değer | wait sn | heal N | damage N | kill | respawn
##           teleport x y z | bounce N | move x y z [sn] | color kırmızı / color 255 128 0 | hide | show | destroy
## Akış:     if ad >= 5:  (ardından else:)   repeat N:
## Metinde {ad} yazılırsa değişkenin değeri yazılır. Yerleşik: {can} {ölüm} {zaman}. '#' yorum satırı.

# komut: [en az değer, en çok değer]
const CMDS := {
	"say": [1, 2], "set": [2, 2], "add": [2, 2], "wait": [1, 1],
	"heal": [1, 1], "damage": [1, 1], "kill": [0, 0], "respawn": [0, 0],
	"teleport": [3, 3], "bounce": [1, 1], "move": [3, 4], "color": [1, 3],
	"hide": [0, 0], "show": [0, 0], "destroy": [0, 0],
}
const CMP_OPS := ["==", "!=", "<", ">", "<=", ">="]
const COLORS := {
	"kırmızı": Color(0.90, 0.22, 0.21), "kirmizi": Color(0.90, 0.22, 0.21), "red": Color(0.90, 0.22, 0.21),
	"turuncu": Color(0.98, 0.55, 0.0), "orange": Color(0.98, 0.55, 0.0),
	"sarı": Color(0.99, 0.85, 0.21), "sari": Color(0.99, 0.85, 0.21), "yellow": Color(0.99, 0.85, 0.21),
	"yeşil": Color(0.26, 0.63, 0.28), "yesil": Color(0.26, 0.63, 0.28), "green": Color(0.26, 0.63, 0.28),
	"mavi": Color(0.12, 0.53, 0.90), "blue": Color(0.12, 0.53, 0.90),
	"mor": Color(0.56, 0.14, 0.67), "purple": Color(0.56, 0.14, 0.67),
	"beyaz": Color(0.96, 0.96, 0.96), "white": Color(0.96, 0.96, 0.96),
	"gri": Color(0.46, 0.46, 0.46), "gray": Color(0.46, 0.46, 0.46),
	"siyah": Color(0.13, 0.13, 0.13), "black": Color(0.13, 0.13, 0.13),
}


## Kaynak kodu derler: {"events": [...], "errors": ["Satır 3: ..."]}
static func compile(src: String) -> Dictionary:
	var errors: Array[String] = []
	var items: Array = []
	var lines := src.split("\n")
	for i in lines.size():
		var raw := lines[i].replace("\t", "    ").replace("\r", "")
		var t := _strip_comment(raw)
		var body := t.strip_edges()
		if body == "":
			continue
		items.append({"i": t.length() - t.lstrip(" ").length(), "t": body, "n": i + 1})

	var st := {"pos": 0}
	var events: Array = []
	while int(st["pos"]) < items.size():
		var it: Dictionary = items[int(st["pos"])]
		st["pos"] = int(st["pos"]) + 1
		var line := int(it["n"])
		if int(it["i"]) != 0:
			errors.append("Satır %d: beklenmeyen girinti" % line)
			continue
		var head := str(it["t"])
		if not head.ends_with(":"):
			errors.append("Satır %d: olay başlığı ':' ile bitmeli (onstart:  ontouch:  every 3:)" % line)
			continue
		var toks := _tokenize(head.trim_suffix(":"))
		var ev := {"type": "", "every": 0.0, "body": []}
		var valid := true
		if toks.is_empty() or str(toks[0]["t"]) != "id":
			errors.append("Satır %d: olay adı gerekli" % line)
			valid = false
		else:
			var name := str(toks[0]["v"])
			ev["type"] = name
			match name:
				"onstart", "ontouch":
					if toks.size() != 1:
						errors.append("Satır %d: '%s:' değer almaz" % [line, name])
						valid = false
				"every":
					if toks.size() != 2 or str(toks[1]["t"]) != "num" or float(toks[1]["v"]) <= 0.0:
						errors.append("Satır %d: 'every 3:' gibi pozitif saniye gerekli" % line)
						valid = false
					else:
						ev["every"] = float(toks[1]["v"])
				_:
					errors.append("Satır %d: bilinmeyen olay '%s' (onstart, ontouch, every)" % [line, name])
					valid = false
		var body_stmts := _parse_block(items, st, 0, errors)
		if body_stmts.is_empty() and valid:
			errors.append("Satır %d: olay gövdesi boş (girintili komut ekle)" % line)
			valid = false
		if valid:
			ev["body"] = body_stmts
			events.append(ev)
	return {"events": events, "errors": errors}


static func _strip_comment(line: String) -> String:
	var in_str := false
	for i in line.length():
		var ch := line[i]
		if ch == "\"":
			in_str = not in_str
		elif ch == "#" and not in_str:
			return line.substr(0, i)
	return line


static func _tokenize(text: String) -> Array:
	var out: Array = []
	var i := 0
	var n := text.length()
	while i < n:
		var ch := text[i]
		if ch == " ":
			i += 1
		elif ch == "\"":
			var close := text.find("\"", i + 1)
			if close == -1:
				return [{"t": "err", "v": "kapanmayan tırnak"}]
			out.append({"t": "str", "v": text.substr(i + 1, close - i - 1)})
			i = close + 1
		else:
			var j := i
			while j < n and text[j] != " ":
				j += 1
			var w := text.substr(i, j - i)
			if w.is_valid_float():
				out.append({"t": "num", "v": w.to_float()})
			else:
				out.append({"t": "id", "v": w})
			i = j
	return out


static func _parse_block(items: Array, st: Dictionary, parent_indent: int, errors: Array[String]) -> Array:
	var stmts: Array = []
	if int(st["pos"]) >= items.size() or int(items[int(st["pos"])]["i"]) <= parent_indent:
		return stmts
	var indent := int(items[int(st["pos"])]["i"])
	while int(st["pos"]) < items.size():
		var it: Dictionary = items[int(st["pos"])]
		var ind := int(it["i"])
		if ind < indent:
			break
		st["pos"] = int(st["pos"]) + 1
		var line := int(it["n"])
		if ind > indent:
			errors.append("Satır %d: beklenmeyen girinti" % line)
			continue
		var text := str(it["t"])
		var is_block := text.ends_with(":")
		var toks := _tokenize(text.trim_suffix(":") if is_block else text)
		if toks.is_empty():
			continue
		if str(toks[0]["t"]) == "err":
			errors.append("Satır %d: %s" % [line, toks[0]["v"]])
			if is_block:
				_parse_block(items, st, indent, errors)
			continue
		if str(toks[0]["t"]) != "id":
			errors.append("Satır %d: satır bir komutla başlamalı" % line)
			if is_block:
				_parse_block(items, st, indent, errors)
			continue
		var cmd := str(toks[0]["v"])
		var args: Array = toks.slice(1)
		if cmd == "if":
			var body := _parse_block(items, st, indent, errors) if is_block else []
			if not is_block or args.size() != 3 or str(args[1]["t"]) != "id" or not CMP_OPS.has(str(args[1]["v"])):
				errors.append("Satır %d: 'if ad >= 5:' biçiminde olmalı (== != < > <= >=)" % line)
				continue
			if body.is_empty():
				errors.append("Satır %d: if gövdesi boş" % line)
			var node := {"op": "if", "a": args[0], "cmp": str(args[1]["v"]), "b": args[2], "body": body, "else": [], "line": line}
			if int(st["pos"]) < items.size() and int(items[int(st["pos"])]["i"]) == indent and str(items[int(st["pos"])]["t"]) == "else:":
				st["pos"] = int(st["pos"]) + 1
				node["else"] = _parse_block(items, st, indent, errors)
			stmts.append(node)
		elif cmd == "repeat":
			var body2 := _parse_block(items, st, indent, errors) if is_block else []
			if not is_block or args.size() != 1:
				errors.append("Satır %d: 'repeat 5:' biçiminde olmalı" % line)
				continue
			if body2.is_empty():
				errors.append("Satır %d: repeat gövdesi boş" % line)
			stmts.append({"op": "repeat", "n": args[0], "body": body2, "line": line})
		elif cmd == "else":
			errors.append("Satır %d: 'else:' bir if bloğunun hemen ardından gelmeli" % line)
			if is_block:
				_parse_block(items, st, indent, errors)
		else:
			if is_block:
				errors.append("Satır %d: '%s' blok açamaz (sondaki ':' kaldır)" % [line, cmd])
				_parse_block(items, st, indent, errors)
				continue
			if not CMDS.has(cmd):
				errors.append("Satır %d: bilinmeyen komut '%s'" % [line, cmd])
				continue
			var lim: Array = CMDS[cmd]
			if args.size() < int(lim[0]) or args.size() > int(lim[1]):
				var need := str(lim[0]) if lim[0] == lim[1] else "%d-%d" % [lim[0], lim[1]]
				errors.append("Satır %d: '%s' için %s değer gerekir" % [line, cmd, need])
				continue
			if cmd == "color" and args.size() == 1:
				var cn := str(args[0]["v"]).to_lower()
				if str(args[0]["t"]) == "num" or (not COLORS.has(cn) and not cn.begins_with("#")):
					errors.append("Satır %d: bilinmeyen renk '%s' (kırmızı, mavi, ... ya da \"#ff8800\")" % [line, cn])
					continue
			stmts.append({"op": cmd, "args": args, "line": line})
	return stmts


## Çalışma zamanında değerlerden renk üretir (null = geçersiz).
static func make_color(vals: Array) -> Variant:
	if vals.size() == 3:
		return Color(clampf(float(vals[0]) / 255.0, 0.0, 1.0), clampf(float(vals[1]) / 255.0, 0.0, 1.0), clampf(float(vals[2]) / 255.0, 0.0, 1.0))
	if vals.size() == 1:
		var s := str(vals[0]).to_lower()
		if COLORS.has(s):
			return COLORS[s]
		if s.begins_with("#") and (s.length() == 7 or s.length() == 4):
			return Color(s)
	return null
