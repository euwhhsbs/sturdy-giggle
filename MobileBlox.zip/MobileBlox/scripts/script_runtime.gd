class_name ScriptRuntime
extends Node
## Play'de MobileBlox Script'lerini çalıştırır (parça + genel script'ler). Güvenli: yalnızca MBScript komutları.

signal message(text: String, secs: float)

const MAX_STEPS := 4000  # bir olay çalışmasında en fazla komut (sonsuz döngü koruması)

var player: Player
var vars: Dictionary = {}
var _entries: Array[Dictionary] = []
var _time := 0.0


static func fmt(v: Variant) -> String:
	if v is float and is_equal_approx(v, roundf(v)):
		return str(int(v))
	return str(v)


func setup(p_player: Player, parts_root: Node, global_scripts: Array) -> void:
	player = p_player
	for body in parts_root.get_children():
		var d: Dictionary = body.get_meta("data")
		var src := str(d.get("sc", ""))
		if src.strip_edges() != "":
			_register(src, body as Node3D, str(d.get("n", "parça")))
	for g in global_scripts:
		_register(str(g["src"]), null, str(g["n"]))
	player.part_touched.connect(_on_touch)
	for e in _entries:
		if str(e["ev"]["type"]) == "onstart":
			_run(e)


func _register(src: String, part: Node3D, label: String) -> void:
	if not LuauParser.is_legacy(src):
		return  # Luau script'lerini LuauRuntime çalıştırır
	var r := MBScript.compile(src)
	for err in r["errors"]:
		push_warning("[%s] %s" % [label, err])
	for ev in r["events"]:
		if str(ev["type"]) == "ontouch" and part == null:
			push_warning("[%s] ontouch yalnızca parça script'lerinde çalışır" % label)
			continue
		_entries.append({"ev": ev, "part": part, "busy": false, "acc": 0.0, "cool": 0})


func _process(delta: float) -> void:
	_time += delta
	for e in _entries:
		var ev: Dictionary = e["ev"]
		if str(ev["type"]) == "every":
			e["acc"] = float(e["acc"]) + delta
			if float(e["acc"]) >= float(ev["every"]):
				e["acc"] = 0.0
				_run(e)


func _on_touch(body: Node3D) -> void:
	var now := Time.get_ticks_msec()
	for e in _entries:
		if str(e["ev"]["type"]) == "ontouch" and e["part"] == body and now >= int(e["cool"]):
			e["cool"] = now + 500
			_run(e)


func _run(e: Dictionary) -> void:
	if e["busy"]:
		return
	e["busy"] = true
	var ctx := {"part": e["part"], "steps": 0}
	await _exec(e["ev"]["body"], ctx)
	e["busy"] = false


func _exec(stmts: Array, ctx: Dictionary) -> void:
	for s in stmts:
		if not is_inside_tree() or int(ctx["steps"]) > MAX_STEPS:
			return
		ctx["steps"] = int(ctx["steps"]) + 1
		await _stmt(s, ctx)


func _part_of(ctx: Dictionary) -> Node3D:
	var p: Variant = ctx["part"]
	if is_instance_valid(p):
		return p as Node3D
	return null


func _stmt(s: Dictionary, ctx: Dictionary) -> void:
	var a: Array = s.get("args", [])
	var part := _part_of(ctx)
	match str(s["op"]):
		"say":
			message.emit(fmt(_val(a[0])), _num(_val(a[1])) if a.size() > 1 else 3.0)
		"set":
			vars[str(a[0]["v"])] = _val(a[1])
		"add":
			var k := str(a[0]["v"])
			vars[k] = _num(vars.get(k, 0)) + _num(_val(a[1]))
		"wait":
			await get_tree().create_timer(maxf(0.0, _num(_val(a[0])))).timeout
		"heal":
			player.heal(_num(_val(a[0])))
		"damage":
			player.take_damage(_num(_val(a[0])))
		"kill":
			player.die()
		"respawn":
			player.respawn()
		"teleport":
			player.teleport(Vector3(_num(_val(a[0])), _num(_val(a[1])), _num(_val(a[2]))))
		"bounce":
			player.launch(_num(_val(a[0])))
		"move":
			if part != null:
				var off := Vector3(_num(_val(a[0])), _num(_val(a[1])), _num(_val(a[2])))
				var secs := _num(_val(a[3])) if a.size() > 3 else 0.0
				if secs <= 0.0:
					part.position += off
				else:
					var tw := create_tween()
					tw.tween_property(part, "position", part.position + off, secs)
					await tw.finished
		"color":
			if part != null:
				var vals: Array = []
				for t in a:
					vals.append(_val(t))
				var c: Variant = MBScript.make_color(vals)
				var mesh := part.get_node_or_null("Mesh") as MeshInstance3D
				if c != null and mesh != null:
					var pd: Dictionary = part.get_meta("data")
					mesh.material_override = PartFactory.material_for(c as Color, int(pd.get("x", 0)))
		"hide", "show":
			if part != null:
				var vis := str(s["op"]) == "show"
				part.visible = vis
				var shape := part.get_node_or_null("Shape") as CollisionShape3D
				if shape != null:
					shape.set_deferred("disabled", not vis)
		"destroy":
			if part != null:
				part.queue_free()
		"if":
			var cond := _cmp(_val(s["a"]), str(s["cmp"]), _val(s["b"]))
			await _exec(s["body"] if cond else s["else"], ctx)
		"repeat":
			for i in clampi(int(_num(_val(s["n"]))), 0, 1000):
				if int(ctx["steps"]) > MAX_STEPS:
					break
				await _exec(s["body"], ctx)


# ------------------------------------------------------------------ Değerler
func _builtin(nm: String) -> Variant:
	match nm:
		"can":
			return int(player.health)
		"ölüm", "olum":
			return player.deaths
		"zaman":
			return snappedf(_time, 0.1)
	return null


func _val(tok: Dictionary) -> Variant:
	match str(tok["t"]):
		"num":
			return tok["v"]
		"str":
			return _template(str(tok["v"]))
		_:
			var nm := str(tok["v"])
			var b: Variant = _builtin(nm)
			if b != null:
				return b
			return vars.get(nm, 0)


func _template(t: String) -> String:
	if not t.contains("{"):
		return t
	var out := t
	for k in vars:
		out = out.replace("{%s}" % str(k), fmt(vars[k]))
	for nm in ["can", "ölüm", "olum", "zaman"]:
		out = out.replace("{%s}" % nm, fmt(_builtin(nm)))
	return out


func _num(v: Variant) -> float:
	if v is int or v is float:
		return float(v)
	return str(v).to_float()


func _cmp(x: Variant, op: String, y: Variant) -> bool:
	if (x is int or x is float) and (y is int or y is float):
		var fx := float(x)
		var fy := float(y)
		match op:
			"==":
				return is_equal_approx(fx, fy)
			"!=":
				return not is_equal_approx(fx, fy)
			"<":
				return fx < fy
			">":
				return fx > fy
			"<=":
				return fx <= fy or is_equal_approx(fx, fy)
			">=":
				return fx >= fy or is_equal_approx(fx, fy)
	else:
		match op:
			"==":
				return str(x) == str(y)
			"!=":
				return str(x) != str(y)
	return false
