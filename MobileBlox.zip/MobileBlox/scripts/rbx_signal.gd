class_name RbxSignal
extends RefCounted
## Roblox olayı (RBXScriptSignal): handlers = [{"fn": LuaFunc, "conn": RbxConn, "once": bool}], waiters = [LuaWait]

var handlers: Array = []
var waiters: Array = []
