class_name LuaWait
extends RefCounted
## wait()/Wait() için bekleme nesnesi. done sinyali emit edilince bekleyen coroutine devam eder.

signal done(value: Variant)

var remaining := 0.0
var elapsed := 0.0
