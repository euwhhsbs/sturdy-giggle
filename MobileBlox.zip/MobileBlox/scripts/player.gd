class_name Player
extends CharacterBody3D
## Karakter + üçüncü şahıs orbit kamera + can sistemi.
## Girdi: move_input (joystick), jump_held (Zıpla düğmesi), rotate_cam / zoom_cam (sağ ekran).
## Klavye yedeği (masaüstü test): ok tuşları + Space.
## Tehlike parçaları (data["x"]): 1 = saniyede hasar, 2 = anında öldür.

signal died
signal health_changed(current: float, maximum: float)
signal checkpoint_reached
signal part_touched(body: Node3D)  # karakter bir parçaya yeni değdi (script'ler için)
signal part_untouched(body: Node3D)  # karakter parçadan ayrıldı

const SPEED := 8.0
const JUMP_VELOCITY := 11.0
const GRAVITY := 32.0
const LOOK_SENS := 0.005
const MAX_HEALTH := 100.0
const HAZARD_DPS := 45.0
const REGEN_DELAY_MSEC := 4000
const REGEN_PER_SEC := 5.0

var move_input := Vector2.ZERO
var jump_held := false

var cam_yaw := 0.0
var cam_pitch := -0.35
var cam_dist := 8.0

var deaths := 0
var health := MAX_HEALTH
var camera: Camera3D
var model: Node3D

var _query: PhysicsShapeQueryParameters3D
var _invuln_until := 0
var _last_damage_msec := 0
var checkpoint := Vector3.ZERO  # ölünce doğulan yer (varsayılan: oyunun spawn noktası)
var _pending_bounce := 0.0
var _touching := {}
var speed := SPEED  # Humanoid.WalkSpeed (Roblox 16 = bizde 8)
var jump_velocity := JUMP_VELOCITY  # Humanoid.JumpPower
var _bounce_until := 0


func _ready() -> void:
	floor_snap_length = 0.4

	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.45
	cap.height = 1.9
	cs.shape = cap
	cs.position = Vector3(0, 0.95, 0)
	add_child(cs)

	model = Node3D.new()
	add_child(model)
	var body_mesh := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.45
	cm.height = 1.9
	cm.radial_segments = 16
	cm.rings = 6
	body_mesh.mesh = cm
	body_mesh.position = Vector3(0, 0.95, 0)
	body_mesh.material_override = PartFactory.material_for(Color("ff7043"))
	model.add_child(body_mesh)

	var nose := MeshInstance3D.new()  # yön göstergesi (-Z ileri)
	var nm := BoxMesh.new()
	nm.size = Vector3(0.5, 0.2, 0.3)
	nose.mesh = nm
	nose.position = Vector3(0, 1.5, -0.42)
	nose.material_override = PartFactory.material_for(Color.WHITE)
	model.add_child(nose)

	# Temas sorgusu: kapsülden biraz büyük şekil. Area3D yerine shape query kullanılır,
	# çünkü Jolt fiziğinde Area3D varsayılan olarak StaticBody3D'leri algılamaz.
	var sc := CapsuleShape3D.new()
	sc.radius = 0.6
	sc.height = 2.1
	_query = PhysicsShapeQueryParameters3D.new()
	_query.shape = sc
	_query.collision_mask = 1
	var ex: Array[RID] = [get_rid()]
	_query.exclude = ex

	camera = Camera3D.new()
	camera.top_level = true
	camera.far = 300.0
	add_child(camera)
	camera.make_current()

	checkpoint = Game.spawn_point
	respawn()


func respawn() -> void:
	global_position = checkpoint + Vector3(0, 0.1, 0)
	velocity = Vector3.ZERO
	_invuln_until = Time.get_ticks_msec() + 700  # doğunca kısa dokunulmazlık


func take_damage(amount: float) -> void:
	if Time.get_ticks_msec() < _invuln_until:
		return
	health = maxf(0.0, health - amount)
	_last_damage_msec = Time.get_ticks_msec()
	health_changed.emit(health, MAX_HEALTH)
	if health <= 0.0:
		die()


func die() -> void:
	deaths += 1
	health = MAX_HEALTH
	respawn()
	health_changed.emit(health, MAX_HEALTH)
	died.emit()


func rotate_cam(rel: Vector2) -> void:
	cam_yaw -= rel.x * LOOK_SENS
	cam_pitch = clampf(cam_pitch - rel.y * LOOK_SENS, -1.3, 0.2)


func zoom_cam(factor: float) -> void:
	cam_dist = clampf(cam_dist * factor, 3.0, 20.0)


func _physics_process(delta: float) -> void:
	var v := move_input
	if v == Vector2.ZERO:
		v = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var jump := jump_held or Input.is_action_pressed("ui_accept")

	# Joystick yukarı (v.y < 0) = kameranın baktığı yöne ileri
	var dir := Basis(Vector3.UP, cam_yaw) * Vector3(v.x, 0.0, v.y)
	velocity.x = dir.x * speed
	velocity.z = dir.z * speed

	if is_on_floor():
		velocity.y = jump_velocity if jump else 0.0
	else:
		velocity.y -= GRAVITY * delta
	if _pending_bounce > 0.0:  # zıplatıcı: zemin sıfırlamasından sonra uygula
		velocity.y = _pending_bounce
		_pending_bounce = 0.0

	if dir.length() > 0.1:
		var target := atan2(-dir.x, -dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, target, minf(1.0, 12.0 * delta))

	move_and_slide()

	if global_position.y < -40.0:
		die()
	else:
		_check_hazards(delta)

	if health < MAX_HEALTH and Time.get_ticks_msec() - _last_damage_msec > REGEN_DELAY_MSEC:
		health = minf(MAX_HEALTH, health + REGEN_PER_SEC * delta)
		health_changed.emit(health, MAX_HEALTH)

	_update_camera()


## Dokunulan parçaların davranışlarını uygular:
##   1 hasar (saniyede), 2 öldür, 3 zıplatıcı (üstten basınca), 4 checkpoint
func _check_hazards(delta: float) -> void:
	_query.transform = Transform3D(Basis.IDENTITY, global_position + Vector3(0, 0.95, 0))
	var hits := get_world_3d().direct_space_state.intersect_shape(_query, 16)
	var worst := 0
	var bounce := 0.0
	var now_touch := {}
	for h in hits:
		var c := h["collider"] as Node3D
		if c == null or not c.has_meta("data"):
			continue
		now_touch[c] = true
		if not _touching.has(c):
			part_touched.emit(c)
		var d: Dictionary = c.get_meta("data")
		var kind := int(d.get("x", 0))
		var half_h := (d["s"] as Vector3).y * 0.5
		match kind:
			1, 2:
				worst = maxi(worst, kind)
			3:
				# yalnızca üstünden basılınca zıplat
				if global_position.y >= c.global_position.y + half_h - 0.4:
					bounce = maxf(bounce, float(d.get("a", 18.0)))
			4:
				var pos := c.global_position + Vector3(0, half_h, 0)
				if checkpoint.distance_to(pos) > 0.05:
					checkpoint = pos
					checkpoint_reached.emit()
	for k in _touching:
		if not now_touch.has(k) and is_instance_valid(k):
			part_untouched.emit(k)
	_touching = now_touch
	if worst == 2:
		take_damage(MAX_HEALTH)
	elif worst == 1:
		take_damage(HAZARD_DPS * delta)
	if bounce > 0.0 and Time.get_ticks_msec() >= _bounce_until:
		_pending_bounce = bounce
		_bounce_until = Time.get_ticks_msec() + 250


## Script API'si
func set_health(h: float) -> void:
	var lower := h < health
	health = clampf(h, 0.0, MAX_HEALTH)
	if lower:
		_last_damage_msec = Time.get_ticks_msec()
	health_changed.emit(health, MAX_HEALTH)
	if health <= 0.0:
		die()


func heal(amount: float) -> void:
	health = clampf(health + amount, 0.0, MAX_HEALTH)
	health_changed.emit(health, MAX_HEALTH)


func launch(v: float) -> void:
	_pending_bounce = maxf(v, 0.0)


func teleport(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO


func _update_camera() -> void:
	var target := global_position + Vector3(0, 1.4, 0)
	var want := target + Basis.from_euler(Vector3(cam_pitch, cam_yaw, 0.0)) * Vector3(0, 0, cam_dist)
	# Kamera duvarın içine girmesin: hedeften kameraya ışın at, çarparsa öne çek
	var excl: Array[RID] = [get_rid()]
	var q := PhysicsRayQueryParameters3D.create(target, want, 1, excl)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		var hp: Vector3 = hit["position"]
		want = hp + (target - want).normalized() * 0.25
	camera.global_position = want
	camera.look_at(target)
