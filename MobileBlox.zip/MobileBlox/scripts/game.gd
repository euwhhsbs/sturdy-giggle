extends Node
## Autoload "Game": oyun listesi + dünya verisi + kaydet/yükle + sahne geçişi.
## Her parça: {"k": tür, "p": Vector3, "s": Vector3, "c": Color, "r": dönüş, "n": ad,
##   "x": davranış (0 yok, 1 hasar, 2 öldür, 3 zıplatıcı, 4 checkpoint, 5 hareketli platform),
##   "a": davranış parametresi (zıplatıcı gücü / platform mesafesi), "b": platform ekseni (0 X, 1 Y, 2 Z)}

const LEGACY_PATH := "user://world.json"  # ilk oyunun dosyası (eski kayıtlarla uyumlu)
const INDEX_PATH := "user://games.json"
const SETTINGS_PATH := "user://settings.cfg"
const MAX_PARTS := 1500  # Mobil için güvenli üst sınır (draw call)

var games: Array[Dictionary] = []  # {"id": String, "name": String}
var current_id := "g1"

var world_parts: Array[Dictionary] = []
var spawn_point := Vector3(0, 1, 0)
var shadows_enabled := true
var version := "0.1.0"
var joystick_fixed := false  # false = yüzen, true = sabit

# StarterGui: oyun içi arayüz öğeleri (her oyunun dünya dosyasıyla birlikte kaydedilir)
var gui_items: Array[Dictionary] = []
var _gui_next := 1

# Genel (ServerScriptService) script'ler: {"id", "n", "src"}
var scripts: Array[Dictionary] = []
var _script_next := 1


func _ready() -> void:
	version = str(ProjectSettings.get_setting("application/config/version", "0.1.0"))
	_load_settings()
	_load_index()
	_load_bundled()
	if get_game(current_id).is_empty():
		current_id = str(games[0]["id"])
	select_game(current_id)


func goto(scene_path: String) -> void:
	get_tree().change_scene_to_file(scene_path)


# ---------------------------------------------------------------- Ayarlar
func _load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		joystick_fixed = bool(cf.get_value("controls", "joystick_fixed", false))
		shadows_enabled = bool(cf.get_value("graphics", "shadows", true))


func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("controls", "joystick_fixed", joystick_fixed)
	cf.set_value("graphics", "shadows", shadows_enabled)
	cf.save(SETTINGS_PATH)


# ---------------------------------------------------------------- Oyun listesi
func is_builtin(id: String) -> bool:
	return id.begins_with("b_")


func world_path(id: String) -> String:
	if is_builtin(id):
		return "res://games/%s.mbgame" % id.substr(2)  # oyuna gömülü (salt okunur)
	return LEGACY_PATH if id == "g1" else "user://world_%s.json" % id


func get_game(id: String) -> Dictionary:
	for g in games:
		if g["id"] == id:
			return g
	return {}


func current_name() -> String:
	var g := get_game(current_id)
	return str(g.get("name", "Oyun"))


func select_game(id: String) -> void:
	current_id = id
	if not load_world():
		if id == "g1":
			default_world()
		else:
			blank_world()
	_sync_meta()
	_save_index()


func create_game(game_name: String) -> String:
	var n := int(Time.get_unix_time_from_system())
	while not get_game("g%d" % n).is_empty():
		n += 1
	var id := "g%d" % n
	games.append({"id": id, "name": game_name, "plays": 0, "parts": 0})
	current_id = id
	blank_world()
	save_world()
	_save_index()
	return id


func _load_index() -> void:
	games.clear()
	if FileAccess.file_exists(INDEX_PATH):
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(INDEX_PATH))
		if parsed is Dictionary:
			var data: Dictionary = parsed
			for g in data.get("games", []):
				games.append({
					"id": str(g["id"]),
					"name": str(g["name"]),
					"plays": int(g.get("plays", 0)),
					"parts": int(g.get("parts", 0)),
				})
			current_id = str(data.get("current", "g1"))
	if games.is_empty():
		games.append({"id": "g1", "name": "Oyunum", "plays": 0, "parts": 0})
		current_id = "g1"
		_save_index()
	if get_game(current_id).is_empty():
		current_id = str(games[0]["id"])


func _save_index() -> void:
	var f := FileAccess.open(INDEX_PATH, FileAccess.WRITE)
	if f == null:
		return
	var saved: Array = []
	for g in games:
		if not bool(g.get("builtin", false)):  # yerleşik oyunlar her açılışta res://games'ten yüklenir
			saved.append(g)
	f.store_string(JSON.stringify({"current": current_id, "games": saved}))
	f.close()


## res://games/*.mbgame dosyalarını yerleşik oyun olarak listenin başına ekler.
## Bu dosyalar dışa aktarmaya dahil edilir; böylece oyunu indiren HERKES bu oyunları görür.
func _load_bundled() -> void:
	var keep: Array[Dictionary] = []
	for g in games:
		if not bool(g.get("builtin", false)):
			keep.append(g)
	var featured: Array[Dictionary] = []
	var dir := DirAccess.open("res://games")
	if dir != null:
		var files := dir.get_files()
		files.sort()
		for f in files:
			if not f.ends_with(".mbgame"):
				continue
			var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://games/" + f))
			if not (parsed is Dictionary):
				continue
			var d: Dictionary = parsed
			var w: Variant = d.get("world", d)
			if not (w is Dictionary):
				continue
			var stem := f.get_basename()
			var parts_n: int = (w as Dictionary).get("parts", []).size()
			featured.append({"id": "b_" + stem, "name": str(d.get("name", stem)), "plays": 0, "parts": parts_n, "builtin": true})
	featured.append_array(keep)
	games = featured


func _new_id() -> String:
	var n := int(Time.get_unix_time_from_system())
	while not get_game("g%d" % n).is_empty():
		n += 1
	return "g%d" % n


## Yerleşik oyunu düzenlenebilir yerel bir kopyaya çevirir ve onu seçer.
func fork_game(id: String) -> String:
	select_game(id)  # dünyayı belleğe yükler
	var nid := _new_id()
	var nm := str(get_game(id).get("name", "Oyun")) + " (kopya)"
	games.append({"id": nid, "name": nm, "plays": 0, "parts": world_parts.size()})
	current_id = nid
	save_world()
	_save_index()
	return nid


## Paylaşılabilir metin (JSON): bu metni GitHub'da games/ad.mbgame dosyasına koyarsan oyuna gömülür,
## ya da başka biri "Oyun İçe Aktar" ile yapıştırarak kendi cihazına alır.
func export_json(id: String) -> String:
	var g := get_game(id)
	if g.is_empty():
		return ""
	if id == current_id and not is_builtin(id):
		save_world()
	var path := world_path(id)
	if not FileAccess.file_exists(path):
		return ""
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not (parsed is Dictionary):
		return ""
	return JSON.stringify({"mobileblox": 1, "name": str(g["name"]), "world": parsed})


## Paylaşılan metinden yeni yerel oyun oluşturur; başarısızsa "" döner.
func import_json(text: String, new_name: String = "") -> String:
	var parsed: Variant = JSON.parse_string(text.strip_edges())
	if not (parsed is Dictionary):
		return ""
	var d: Dictionary = parsed
	var w: Variant = d.get("world", d)  # ham dünya JSON'u da kabul edilir
	if not (w is Dictionary) or not (w as Dictionary).has("parts"):
		return ""
	var nm := new_name.strip_edges()
	if nm == "":
		nm = str(d.get("name", "İçe aktarılan oyun"))
	var id := _new_id()
	var f := FileAccess.open(world_path(id), FileAccess.WRITE)
	if f == null:
		return ""
	f.store_string(JSON.stringify(w))
	f.close()
	games.append({"id": id, "name": nm, "plays": 0, "parts": (w as Dictionary)["parts"].size()})
	_save_index()
	return id


## Menüde gösterilen parça sayısını güncel tutar.
func _sync_meta() -> void:
	var g := get_game(current_id)
	if not g.is_empty():
		g["parts"] = world_parts.size()


## Oyuna girildiğinde "popüler" sıralaması için sayaç.
func record_play() -> void:
	var g := get_game(current_id)
	if not g.is_empty():
		g["plays"] = int(g.get("plays", 0)) + 1
		_save_index()


# ---------------------------------------------------------------- Genel script'ler
func next_script_id() -> int:
	var m := 0
	for g in scripts:
		m = maxi(m, int(g["id"]))
	_script_next = maxi(_script_next, m + 1)
	var id := _script_next
	_script_next += 1
	return id


func _scripts_to_json() -> Array:
	var out: Array = []
	for g in scripts:
		out.append({"id": int(g["id"]), "n": str(g["n"]), "src": str(g["src"])})
	return out


func _scripts_from_json(arr: Array) -> void:
	scripts.clear()
	for e in arr:
		scripts.append({"id": int(e.get("id", 0)), "n": str(e.get("n", "Script")), "src": str(e.get("src", ""))})


# ---------------------------------------------------------------- StarterGui
func next_gui_id() -> int:
	var m := 0
	for g in gui_items:
		m = maxi(m, int(g["id"]))
	_gui_next = maxi(_gui_next, m + 1)
	var id := _gui_next
	_gui_next += 1
	return id


func _gui_to_json() -> Array:
	var out: Array = []
	for g in gui_items:
		var c: Color = g["c"]
		out.append({
			"id": int(g["id"]), "t": int(g["t"]), "n": str(g["n"]), "tx": str(g["tx"]),
			"x": float(g["x"]), "y": float(g["y"]), "w": float(g["w"]), "h": float(g["h"]),
			"c": c.to_html(true), "fs": int(g["fs"]), "ac": int(g["ac"]),
		})
	return out


func _gui_from_json(arr: Array) -> void:
	gui_items.clear()
	for e in arr:
		gui_items.append({
			"id": int(e.get("id", 0)), "t": int(e.get("t", 0)), "n": str(e.get("n", "")), "tx": str(e.get("tx", "")),
			"x": float(e.get("x", 0.4)), "y": float(e.get("y", 0.4)),
			"w": float(e.get("w", 0.2)), "h": float(e.get("h", 0.1)),
			"c": Color.html(str(e.get("c", "ffffffff"))), "fs": int(e.get("fs", 28)), "ac": int(e.get("ac", 0)),
		})


# ---------------------------------------------------------------- Hazır dünyalar
func _add(kind: int, p: Vector3, s: Vector3, c: Color, hazard: int = 0) -> void:
	world_parts.append({"k": kind, "p": p, "s": s, "c": c, "x": hazard})


func blank_world() -> void:
	gui_items.clear()
	scripts.clear()
	world_parts.clear()
	spawn_point = Vector3(0, 1.1, 0)
	_add(0, Vector3(0, 0.5, 0), Vector3(8, 1, 8), Color("f5f5f5"))


func default_world() -> void:
	gui_items.clear()
	scripts.clear()
	world_parts.clear()
	spawn_point = Vector3(0, 1, 0)
	var cols: Array[Color] = [
		Color("e53935"), Color("fb8c00"), Color("fdd835"), Color("43a047"), Color("1e88e5")
	]
	for i in 5:  # merdiven
		_add(0, Vector3(6 + i * 3, 0.5 + i, 0), Vector3(3, 1, 6), cols[i])
	_add(0, Vector3(21, 5.5, 0), Vector3(8, 1, 8), Color("8e24aa"))
	_add(1, Vector3(-6, 2, -4), Vector3(2, 4, 2), Color("757575"))
	_add(2, Vector3(-6, 5, -4), Vector3(2, 2, 2), Color("f5f5f5"))
	_add(0, Vector3(0, 0.5, -10), Vector3(10, 1, 2), Color("e53935"), 2)  # öldürücü


# ---------------------------------------------------------------- Kaydet / Yükle
func _hazard(v: Variant) -> int:
	if v is bool:
		return 2 if v else 0
	return clampi(int(v), 0, 5)


func save_world() -> bool:
	if is_builtin(current_id):
		return false  # yerleşik oyun salt okunur; düzenlemek için önce kopyalanır (fork_game)
	var out: Array = []
	for d in world_parts:
		var p: Vector3 = d["p"]
		var s: Vector3 = d["s"]
		var c: Color = d["c"]
		out.append({
			"k": int(d["k"]),
			"p": [p.x, p.y, p.z],
			"s": [s.x, s.y, s.z],
			"c": c.to_html(false),
			"x": _hazard(d.get("x", 0)),
			"r": float(d.get("r", 0.0)),
			"n": str(d.get("n", "")),
			"a": float(d.get("a", 0.0)),
			"b": int(d.get("b", 0)),
			"sc": str(d.get("sc", "")),
		})
	var data := {
		"version": 2,
		"spawn": [spawn_point.x, spawn_point.y, spawn_point.z],
		"parts": out,
		"gui": _gui_to_json(),
		"scripts": _scripts_to_json(),
	}
	var f := FileAccess.open(world_path(current_id), FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(data))
	f.close()
	_sync_meta()
	_save_index()
	return true


func load_world() -> bool:
	var path := world_path(current_id)
	if not FileAccess.file_exists(path):
		return false
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not (parsed is Dictionary):
		return false
	var data: Dictionary = parsed
	world_parts.clear()
	var sp: Array = data.get("spawn", [0, 1, 0])
	spawn_point = Vector3(sp[0], sp[1], sp[2])
	for e in data.get("parts", []):
		var p: Array = e["p"]
		var s: Array = e["s"]
		world_parts.append({
			"k": int(e["k"]),
			"p": Vector3(p[0], p[1], p[2]),
			"s": Vector3(s[0], s[1], s[2]),
			"c": Color.html(str(e["c"])),
			"x": _hazard(e.get("x", 0)),
			"r": float(e.get("r", 0.0)),
			"n": str(e.get("n", "")),
			"a": float(e.get("a", 0.0)),
			"b": int(e.get("b", 0)),
			"sc": str(e.get("sc", "")),
		})
	_gui_from_json(data.get("gui", []))
	_scripts_from_json(data.get("scripts", []))
	return true
