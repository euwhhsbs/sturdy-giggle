class_name RibbonButton
extends Button
## Roblox Studio şeridi düğmesi: üstte büyük ikon, altta küçük yazı, zeminde çerçeve yok.
## BaseButton özellikleri (toggle_mode, button_group, disabled, pressed/toggled) aynen çalışır.
## Yazıyı değiştirmek için `text` yerine `caption` kullan.

var icon_name := "":
	set(v):
		icon_name = v
		queue_redraw()
var caption := "":
	set(v):
		caption = v
		queue_redraw()
var icon_color := Color(0.30, 0.65, 1.0):
	set(v):
		icon_color = v
		queue_redraw()


static func make(icon: String, cap: String, width: float = 72.0) -> RibbonButton:
	var b := RibbonButton.new()
	b.icon_name = icon
	b.caption = cap
	b.icon_color = StudioIcon.default_color(icon)
	b.custom_minimum_size = Vector2(width, 72)
	return b


func _init() -> void:
	focus_mode = Control.FOCUS_NONE
	text = ""
	var n := UIKit.flat_box(Color(0, 0, 0, 0), 3, Color(0, 0, 0, 0), 0, 0)
	var h := UIKit.flat_box(Color(1, 1, 1, 0.09), 3, Color(1, 1, 1, 0.10), 1, 0)
	var p := UIKit.flat_box(Color(0.05, 0.45, 0.85, 0.30), 3, Color(0.30, 0.70, 1.0, 0.90), 1, 0)
	add_theme_stylebox_override("normal", n)
	add_theme_stylebox_override("hover", h)
	add_theme_stylebox_override("pressed", p)
	add_theme_stylebox_override("hover_pressed", p)
	add_theme_stylebox_override("disabled", n)
	add_theme_stylebox_override("focus", StyleBoxEmpty.new())


func _draw() -> void:
	var a := 0.35 if disabled else 1.0
	var ic := Color(icon_color.r, icon_color.g, icon_color.b, a)
	var box := 34.0
	StudioIcon.draw_icon(self, icon_name, Rect2(Vector2((size.x - box) * 0.5, 6.0), Vector2(box, box)), ic)
	var font := get_theme_default_font()
	draw_string(font, Vector2(0.0, size.y - 9.0), caption, HORIZONTAL_ALIGNMENT_CENTER, size.x, 16,
		Color(0.86, 0.86, 0.86, a))
