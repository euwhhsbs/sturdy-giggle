class_name TouchButton
extends Control
## Godot'nun Button'ı yalnızca ilk parmağı (emüle fare) görür. Joystick basılıyken
## zıplamak için ScreenTouch'ı doğrudan dinleyen bu düğme gerekir.

signal pressed
signal released

@export var label := ""

var _touch := -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed and _touch == -1:
			_touch = t.index
			pressed.emit()
			queue_redraw()
		elif not t.pressed and t.index == _touch:
			_touch = -1
			released.emit()
			queue_redraw()


func _draw() -> void:
	var c := size * 0.5
	var r := minf(size.x, size.y) * 0.5
	var down := _touch != -1
	draw_circle(c, r, Color(1, 1, 1, 0.45 if down else 0.22))
	draw_arc(c, r - 2.0, 0.0, TAU, 48, Color(1, 1, 1, 0.6), 3.0)
	var font := get_theme_default_font()
	var fs := get_theme_default_font_size()
	draw_string(font, Vector2(0, c.y + fs * 0.35), label, HORIZONTAL_ALIGNMENT_CENTER, size.x, fs)
