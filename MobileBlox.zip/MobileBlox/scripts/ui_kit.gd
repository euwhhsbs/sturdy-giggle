class_name UIKit
extends RefCounted
## Kod ile UI kurmak için küçük yardımcılar (mobil: büyük dokunma hedefleri).

const ACCENT := Color(0.23, 0.51, 0.96)


static func _flat(c: Color, r: int = 14, border: Color = Color(1, 1, 1, 0.14), bw: int = 2, shadow: bool = false) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(r)
	s.set_content_margin_all(10)
	s.set_border_width_all(bw)
	s.border_color = border
	if shadow:
		s.shadow_color = Color(0, 0, 0, 0.35)
		s.shadow_size = 6
	return s


static func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 26
	t.set_stylebox("normal", "Button", _flat(Color(0.14, 0.18, 0.28, 0.92)))
	t.set_stylebox("hover", "Button", _flat(Color(0.20, 0.25, 0.38, 0.95)))
	t.set_stylebox("pressed", "Button", _flat(ACCENT, 14, Color(1, 1, 1, 0.7)))
	t.set_stylebox("hover_pressed", "Button", _flat(ACCENT.lightened(0.1), 14, Color(1, 1, 1, 0.8)))
	t.set_stylebox("disabled", "Button", _flat(Color(0.1, 0.1, 0.1, 0.5)))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_stylebox("panel", "PanelContainer", _flat(Color(0.05, 0.07, 0.13, 0.86), 18, Color(1, 1, 1, 0.10), 2, true))
	t.set_stylebox("panel", "ItemList", _flat(Color(0.03, 0.05, 0.10, 0.90), 10))
	t.set_stylebox("focus", "ItemList", StyleBoxEmpty.new())
	t.set_stylebox("selected", "ItemList", _flat(ACCENT, 8, Color(1, 1, 1, 0.5)))
	t.set_stylebox("selected_focus", "ItemList", _flat(ACCENT, 8, Color(1, 1, 1, 0.5)))
	t.set_constant("v_separation", "ItemList", 10)
	t.set_stylebox("normal", "LineEdit", _flat(Color(0.08, 0.10, 0.18, 0.95)))
	t.set_stylebox("focus", "LineEdit", _flat(Color(0.08, 0.10, 0.18, 0.95), 14, ACCENT, 3))
	t.set_color("font_outline_color", "Label", Color(0, 0, 0, 0.9))
	t.set_constant("outline_size", "Label", 6)
	return t


## Düz (flat) stil kutusu: Studio arayüzünde kullanılır.
static func flat_box(c: Color, r: int = 0, border: Color = Color(0, 0, 0, 0), bw: int = 0, margin: int = 6) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(r)
	s.set_border_width_all(bw)
	s.border_color = border
	s.set_content_margin_all(margin)
	return s


## Roblox Studio'nun koyu gri, düz ve mavi vurgulu teması.
static func make_studio_theme() -> Theme:
	var t := Theme.new()
	var accent := Color(0.05, 0.60, 1.0)
	var txt := Color(0.86, 0.86, 0.86)
	t.default_font_size = 22
	t.set_color("font_color", "Label", txt)
	t.set_constant("outline_size", "Label", 0)
	t.set_color("font_color", "Button", txt)
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", Color.WHITE)
	t.set_color("font_hover_pressed_color", "Button", Color.WHITE)
	t.set_color("font_disabled_color", "Button", Color(0.5, 0.5, 0.5))
	t.set_stylebox("normal", "Button", flat_box(Color(0.27, 0.27, 0.27), 3, Color(0.11, 0.11, 0.11), 1, 8))
	t.set_stylebox("hover", "Button", flat_box(Color(0.33, 0.33, 0.33), 3, Color(0.11, 0.11, 0.11), 1, 8))
	t.set_stylebox("pressed", "Button", flat_box(Color(0.05, 0.45, 0.85), 3, Color(0.30, 0.70, 1.0), 1, 8))
	t.set_stylebox("hover_pressed", "Button", flat_box(Color(0.10, 0.50, 0.90), 3, Color(0.30, 0.70, 1.0), 1, 8))
	t.set_stylebox("disabled", "Button", flat_box(Color(0.20, 0.20, 0.20, 0.6), 3, Color(0.11, 0.11, 0.11), 1, 8))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_stylebox("panel", "PanelContainer", flat_box(Color(0.17, 0.17, 0.17), 0, Color(0.09, 0.09, 0.09), 1, 6))
	t.set_stylebox("normal", "LineEdit", flat_box(Color(0.10, 0.10, 0.10), 2, Color(0.30, 0.30, 0.30), 1, 6))
	t.set_stylebox("focus", "LineEdit", flat_box(Color(0.10, 0.10, 0.10), 2, accent, 1, 6))
	t.set_color("font_color", "LineEdit", txt)
	t.set_color("font_placeholder_color", "LineEdit", Color(0.5, 0.5, 0.5))
	t.set_stylebox("panel", "ItemList", flat_box(Color(0.12, 0.12, 0.12), 0, Color(0.09, 0.09, 0.09), 1, 4))
	t.set_stylebox("focus", "ItemList", StyleBoxEmpty.new())
	t.set_stylebox("selected", "ItemList", flat_box(Color(0.05, 0.45, 0.85), 0, Color(0, 0, 0, 0), 0, 4))
	t.set_stylebox("selected_focus", "ItemList", flat_box(Color(0.05, 0.45, 0.85), 0, Color(0, 0, 0, 0), 0, 4))
	t.set_color("font_color", "ItemList", txt)
	t.set_color("font_selected_color", "ItemList", Color.WHITE)
	t.set_constant("v_separation", "ItemList", 6)
	return t


## Sekme şeridi düğmesi: seçiliyken şerit rengine karışır, altında mavi çizgi.
static func style_tab(b: Button) -> void:
	var accent := Color(0.05, 0.60, 1.0)
	var n := flat_box(Color(0, 0, 0, 0), 0, Color(0, 0, 0, 0), 0, 12)
	var h := flat_box(Color(1, 1, 1, 0.07), 0, Color(0, 0, 0, 0), 0, 12)
	var p := flat_box(Color(0.20, 0.20, 0.20), 0, accent, 0, 12)
	p.border_width_bottom = 3
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("hover_pressed", p)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())


static func btn(text: String, min_size: Vector2 = Vector2(110, 64), toggle: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.toggle_mode = toggle
	b.focus_mode = Control.FOCUS_NONE
	return b


## Renk örneği (toggle). Seçiliyken kalın beyaz çerçeve.
static func swatch(c: Color) -> Button:
	var b := btn("", Vector2(60, 60), true)
	for state in ["normal", "hover", "pressed", "hover_pressed"]:
		var sb := StyleBoxFlat.new()
		sb.bg_color = c
		sb.set_corner_radius_all(30)
		sb.set_border_width_all(3)
		sb.border_color = Color(0, 0, 0, 0.35)
		if str(state).contains("pressed"):
			sb.set_border_width_all(6)
			sb.border_color = Color.WHITE
		b.add_theme_stylebox_override(state, sb)
	return b


## Bir kontrolü yarı saydam panelin içine sarar.
static func panel_wrap(child: Control) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_child(child)
	return p


## Konteyneri ekranın bir köşesine/kenarına yerleştirir (büyüme yönü dahil).
static func place(c: Control, preset: Control.LayoutPreset, margin: int = 12) -> void:
	c.set_anchors_and_offsets_preset(preset, Control.PRESET_MODE_MINSIZE, margin)
	match preset:
		Control.PRESET_TOP_RIGHT, Control.PRESET_CENTER_RIGHT, Control.PRESET_BOTTOM_RIGHT:
			c.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		Control.PRESET_CENTER_TOP, Control.PRESET_CENTER_BOTTOM:
			c.grow_horizontal = Control.GROW_DIRECTION_BOTH
	match preset:
		Control.PRESET_BOTTOM_LEFT, Control.PRESET_BOTTOM_RIGHT, Control.PRESET_CENTER_BOTTOM:
			c.grow_vertical = Control.GROW_DIRECTION_BEGIN
		Control.PRESET_CENTER_LEFT, Control.PRESET_CENTER_RIGHT:
			c.grow_vertical = Control.GROW_DIRECTION_BOTH


## Yüzde (0..1) tabanlı dikdörtgen bölge.
static func anchor_rect(c: Control, l: float, t: float, r: float, b: float) -> void:
	c.anchor_left = l
	c.anchor_top = t
	c.anchor_right = r
	c.anchor_bottom = b
	c.offset_left = 0
	c.offset_top = 0
	c.offset_right = 0
	c.offset_bottom = 0
