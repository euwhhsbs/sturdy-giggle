class_name PartFactory
extends RefCounted
## Parça verisinden (Dictionary) StaticBody3D üretir. Materyaller renge göre paylaşılır.

enum Kind { BOX, CYLINDER, SPHERE }

static var _mats: Dictionary = {}


static func material_for(c: Color, hazard: int = 0) -> StandardMaterial3D:
	var key := c.to_html(false) + "_h%d" % hazard
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.roughness = 0.85
	if hazard > 0:
		# Davranışlı parça rengine davranışın rengi karışır + parlar:
		# 1 hasar turuncu, 2 öldür kırmızı, 3 zıplatıcı yeşil, 4 checkpoint sarı, 5 platform mavi
		var tints: Array[Color] = [
			Color.WHITE, Color(1.0, 0.55, 0.05), Color(1.0, 0.12, 0.05),
			Color(0.2, 1.0, 0.4), Color(1.0, 0.9, 0.2), Color(0.3, 0.7, 1.0),
		]
		var tint := tints[clampi(hazard, 0, 5)]
		var hot := c.lerp(tint, 0.6)
		m.albedo_color = hot
		m.emission_enabled = true
		m.emission = hot
		m.emission_energy_multiplier = 0.7
	else:
		m.albedo_color = c
	_mats[key] = m
	return m


## animated = true ise "Hareketli Platform" davranışlı parçalar AnimatableBody3D olur
## (üstündeki karakteri taşır). Stüdyoda hep StaticBody3D kullanılır.
static func build(data: Dictionary, animated: bool = false) -> StaticBody3D:
	var body: StaticBody3D
	if animated and int(data.get("x", 0)) == 5:
		var ab := AnimatableBody3D.new()
		ab.sync_to_physics = true
		body = ab
	else:
		body = StaticBody3D.new()
	body.add_to_group("parts")
	var mesh := MeshInstance3D.new()
	mesh.name = "Mesh"
	var col := CollisionShape3D.new()
	col.name = "Shape"
	body.add_child(mesh)
	body.add_child(col)
	body.set_meta("data", data)
	refresh(body)
	return body


## Verisi değişen parçanın mesh/çarpışma/konum/rengini yeniler.
static func refresh(body: StaticBody3D) -> void:
	var d: Dictionary = body.get_meta("data")
	var size: Vector3 = d["s"]
	var mesh_inst := body.get_node("Mesh") as MeshInstance3D
	var col := body.get_node("Shape") as CollisionShape3D
	match int(d["k"]):
		Kind.CYLINDER:
			var cm := CylinderMesh.new()
			cm.top_radius = size.x * 0.5
			cm.bottom_radius = size.x * 0.5
			cm.height = size.y
			cm.radial_segments = 20
			cm.rings = 1
			mesh_inst.mesh = cm
			var cs := CylinderShape3D.new()
			cs.radius = size.x * 0.5
			cs.height = size.y
			col.shape = cs
		Kind.SPHERE:
			var sm := SphereMesh.new()
			sm.radius = size.x * 0.5
			sm.height = size.x
			sm.radial_segments = 20
			sm.rings = 10
			mesh_inst.mesh = sm
			var ss := SphereShape3D.new()
			ss.radius = size.x * 0.5
			col.shape = ss
		_:
			var bm := BoxMesh.new()
			bm.size = size
			mesh_inst.mesh = bm
			var bs := BoxShape3D.new()
			bs.size = size
			col.shape = bs
	mesh_inst.material_override = material_for(d["c"], int(d.get("x", 0)))
	body.position = d["p"]
	body.rotation_degrees = Vector3(0.0, float(d.get("r", 0.0)), 0.0)
