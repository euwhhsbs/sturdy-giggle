class_name TouchJoystick
extends Control
## Yüzen joystick: bölgeye dokunulan yerde belirir. Kendi parmağını (index) takip
## eder, bu yüzden aynı anda başka parmakla kamera/zıplama çalışır (multitouch).

signal stick_moved(vec: Vector2)

@export var radius := 110.0
@export var deadzone := 0.12

## false = yüzen (dokunulan yerde belirir), true = sabit (hep aynı yerde)
var fixed := false:
	set(v):
		fixed = v
		queue_redraw()

var value := Vector2.ZERO
var _touch := -1
var _origin := Vector2.ZERO
var _pos := Vector2.ZERO
var _thumb := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	resized.connect(queue_redraw)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t: InputEventScreenTouch = event
		if t.pressed and _touch == -1:
			_touch = t.index
			_origin = _center() if fixed else t.position
			_pos = t.position
			_apply()
		elif not t.pressed and t.index == _touch:
			_touch = -1
			_thumb = Vector2.ZERO
			value = Vector2.ZERO
			stick_moved.emit(value)
			queue_redraw()
	elif event is InputEventScreenDrag:
		var d: InputEventScreenDrag = event
		if d.index == _touch:
			_pos = d.position
			_apply()


func _center() -> Vector2:
	if fixed:
		return size * 0.5
	return Vector2(minf(size.x * 0.5, 200.0), size.y - 170.0)


func _apply() -> void:
	_thumb = ((_pos - _origin) / radius).limit_length(1.0)
	value = _thumb if _thumb.length() > deadzone else Vector2.ZERO
	stick_moved.emit(value)
	queue_redraw()


func _draw() -> void:
	var active := _touch != -1
	var o := _origin if active else _center()
	var a := 0.35 if active else 0.15
	draw_circle(o, radius, Color(1, 1, 1, a * 0.6))
	draw_arc(o, radius, 0.0, TAU, 48, Color(1, 1, 1, a + 0.2), 3.0)
	draw_circle(o + _thumb * radius, 48.0, Color(1, 1, 1, a + 0.25))
