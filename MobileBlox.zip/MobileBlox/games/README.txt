Bu klasördeki *.mbgame dosyaları oyuna gömülür; oyunu indiren HERKES "Oyunlar" listesinde görür.
Dosya içeriği: Stüdyo > Dosya > Paylaş > "Panoya Kopyala" ile aldığın metin. Dosya adı: oyun-adi.mbgame
