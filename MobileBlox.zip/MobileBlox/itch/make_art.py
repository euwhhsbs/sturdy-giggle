"""İkon, açılış ekranı ve itch.io kapak görsellerini üretir (Pillow gerekir):  python3 itch/make_art.py"""
from PIL import Image, ImageDraw, ImageFont


def cube(d, cx, cy, s):
    top = [(cx, cy - s), (cx + s * 0.87, cy - s * 0.5), (cx, cy), (cx - s * 0.87, cy - s * 0.5)]
    left = [(cx - s * 0.87, cy - s * 0.5), (cx, cy), (cx, cy + s), (cx - s * 0.87, cy + s * 0.5)]
    right = [(cx, cy), (cx + s * 0.87, cy - s * 0.5), (cx + s * 0.87, cy + s * 0.5), (cx, cy + s)]
    d.polygon(top, fill=(108, 192, 255))
    d.polygon(left, fill=(47, 139, 224))
    d.polygon(right, fill=(27, 98, 173))


def gradient(w, h, c1, c2):
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        t = y / max(h - 1, 1)
        col = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
        for x in range(w):
            px[x, y] = col
    return img


def font(size):
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def centered(d, text, y, f, fill, w):
    box = d.textbbox((0, 0), text, font=f)
    d.text(((w - (box[2] - box[0])) / 2, y), text, font=f, fill=fill)


# 512x512 ikon
icon = gradient(512, 512, (27, 58, 115), (13, 31, 63))
d = ImageDraw.Draw(icon)
cube(d, 256, 250, 170)
icon.save("itch/icon_512.png")
icon.resize((192, 192)).save("icon_192.png")

# Açılış ekranı 1280x720
sp = gradient(1280, 720, (14, 27, 51), (14, 27, 51))
d = ImageDraw.Draw(sp)
cube(d, 640, 300, 110)
centered(d, "MobileBlox", 440, font(84), (235, 240, 250), 1280)
centered(d, "Oyna  -  Tasarla  -  Script Yaz", 545, font(34), (140, 170, 215), 1280)
sp.save("splash.png")

# itch.io kapak 630x500
cv = gradient(630, 500, (27, 58, 115), (10, 22, 44))
d = ImageDraw.Draw(cv)
# yer karosu
for gx in range(-8, 9):
    for gy in range(-4, 5):
        x = 315 + (gx - gy) * 44
        y = 400 + (gx + gy) * 22
        shade = 52 if (gx + gy) % 2 == 0 else 60
        d.polygon([(x, y - 22), (x + 44, y), (x, y + 22), (x - 44, y)], fill=(shade, shade + 40, shade))
cube(d, 315, 215, 95)
centered(d, "MobileBlox", 340, font(60), (255, 255, 255), 630)
centered(d, "Mobilde Roblox tarzi: oyna, tasarla, Luau ile kodla", 415, font(22), (190, 210, 240), 630)
cv.save("itch/cover.png")
print("görseller üretildi")
