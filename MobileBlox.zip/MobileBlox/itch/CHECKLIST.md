# Yayın öncesi kontrol listesi

Bu projedeki kodun büyük kısmı bir Godot editöründe çalıştırılmadan yazıldı. **Yayından önce mutlaka aşağıdakileri yap.**

## 1) Editörde aç
- [ ] Godot 4.7 ile `project.godot`'u aç. İlk içe aktarma bitsin.
- [ ] Alttaki **Output / Debugger > Errors** boş olmalı. Kırmızı hata varsa bana yapıştır, düzeltelim.
- [ ] F5: ana menü açılıyor, "Oyunlar" kartı görünüyor.

## 2) Elle test (masaüstünde fare = dokunuş)
- [ ] Oyunlar > karta dokun: oyun açılıyor, yürüme (oklar) / zıplama (Space) çalışıyor.
- [ ] Menü düğmesi ana menüye dönüyor.
- [ ] More > Build > karta dokun: Stüdyo açılıyor.
- [ ] Parça ekle (Kutu), sürükle, boyutlandır, boya, sil, Geri Al/Yinele.
- [ ] Davranış: Öldür / Hasar / Zıplatıcı / Checkpoint / Hareketli Platform Play'de çalışıyor.
- [ ] Arayüz sekmesi: Etiket + Düğme ekle; Play'de görünüyor.
- [ ] Script sekmesi: "Dokun: hasar" şablonu → Play'de parçaya değince can düşüyor.
- [ ] Kaydet → oyunu kapat/aç → dünya geri geliyor.

## 3) Web dışa aktarma testi
- [ ] `./build/export.sh web` → `build/web/`.
- [ ] Yerelde sun (file:// ÇALIŞMAZ):  `cd build/web && python3 -m http.server 8000`  → http://localhost:8000
- [ ] Telefonda aynı ağdan aç (http://BILGISAYAR_IP:8000), yatay çevir, joystick/kamera/Zıpla çalışıyor mu?
- [ ] Tam ekran düğmesi (More > Ayarlar) çalışıyor mu?

## 4) Android
- [ ] Editor Settings > Export > Android: JDK ve Android SDK yollarını ver.
- [ ] `export_presets.cfg` içinde `package/unique_name` değerini kendi alan adına çevir (örn. `com.kullanici.mobileblox`).
- [ ] `./build/export.sh android` → `MobileBlox-debug.apk`; telefona kur, dene.
- [ ] (Play Store düşünüyorsan release keystore + AAB ayrı konu.)

## 5) itch.io
- [ ] Taslak (Draft) sayfa oluştur, dosyaları yükle, **"Run game"** ile test et.
- [ ] `itch/PAGE.md`'deki ayarları uygula (1280x720, Mobile friendly, SharedArrayBuffer kapalı).
- [ ] Kapak, 3+ ekran görüntüsü, açıklama, etiketler.
- [ ] "Visibility & access" > Public.

## Örnek script'ler (açıklamaya ya da devlog'a)
```lua
-- Kırmızı tuzak: değince can azalır
local part = script.Parent
part.Touched:Connect(function(hit)
    local humanoid = hit.Parent:FindFirstChild("Humanoid")
    if humanoid then humanoid:TakeDamage(25) end
end)
```
```lua
-- Genel script: puan tablosu
game.Players.PlayerAdded:Connect(function(player)
    local stats = Instance.new("Folder")
    stats.Name = "leaderstats"
    stats.Parent = player
    local puan = Instance.new("IntValue")
    puan.Name = "Puan"
    puan.Parent = stats
end)
```
