# itch.io sayfa rehberi (kopyala-yapıştır)

## Temel ayarlar
- **Title:** MobileBlox  *(başlıkta "Roblox" geçirme: marka sorunu çıkabilir)*
- **Short description / tagline:** Mobilde oyna, dünya tasarla, Luau ile script yaz.
- **Classification:** Games
- **Kind of project:** HTML  (Android APK'yı ayrıca dosya olarak yükle)
- **Release status:** Prototype / In development
- **Genre:** Simulation  (ikinci: Platformer)
- **Tags:** sandbox, building, 3d, mobile, level-editor, scripting, luau, godot
- **Pricing:** No payments (ücretsiz) — istersen "Pay what you want"
- **Cover image:** `itch/cover.png` (630x500)  ·  **Ikon:** `itch/icon_512.png`
- **Screenshots:** en az 3 adet yükle (Play ekranı, Stüdyo, Script editörü). Telefonda ekran görüntüsü al.

## Yüklenecek dosyalar
| Dosya | Nasıl oluşur | itch.io'da işaretle |
|---|---|---|
| `build/MobileBlox-web.zip` | `./build/export.sh web` | **This file will be played in the browser** |
| `build/android/MobileBlox-debug.apk` | `./build/export.sh android` | **Android** platformu |
| `build/MobileBlox-windows.zip` | `./build/export.sh windows` (isteğe bağlı) | Windows |

## Embed (tarayıcıda oynatma) ayarları
- Viewport dimensions: **1280 x 720**
- **Mobile friendly:** açık  *(telefonda yatay çevirmesi gerekir; oyun bunu söyler)*
- **Fullscreen button:** açık
- **Automatically start on page load:** kapalı (ilk dokunuşla başlasın)
- **Enable scrollbars:** kapalı
- **SharedArrayBuffer support:** kapalı  *(export tek iş parçacıklı: `thread_support=false`)*
- Orientation: Landscape

## Açıklama metni (Türkçe)
**MobileBlox** — telefonunda hem oyun oynayabildiğin hem kendi dünyanı tasarlayabildiğin küçük bir "oyun yapma" kutusu.

**Oyna:** sanal joystick ile yürü, zıpla, parkur ve tuzaklardan geç.
**Tasarla (More > Build):** parça ekle, sürükle, boyutlandır, boya; birden çok parçayı seç; geri al / yinele.
**Davranışlar:** hasar, öldürücü, zıplatıcı, checkpoint, hareketli platform.
**Arayüz:** oyun içi etiket, düğme ve çerçeveler tasarla.
**Script:** Roblox'un kullandığı **Luau** dili ile kod yaz (`Touched`, `Humanoid`, `TweenService`, `leaderstats` ve daha fazlası).

Kontroller: sol yarı = yürü · sağ yarı = kamera · Zıpla düğmesi.
Oyunların cihazında saklanır (tarayıcı verisini silersen dünyalar silinir).

## Description (English)
**MobileBlox** is a tiny mobile-first "game maker": play levels with a virtual joystick, build your own worlds with touch, design in-game UI, and script with **Luau** (the Roblox scripting language).
Controls: left half = move · right half = camera · Jump button. Worlds are stored locally in your browser/device.

## Bilinen sınırlar (dürüstçe yaz)
- Tek oyunculu. Çevrimiçi paylaşım yok.
- Luau yorumlayıcısı bu oyuna özeldir; her Roblox script'i çalışmaz (GUI/Sound/DataStore/Raycast yok).
- Tarayıcı sürümünde telefon sanal klavyesi script yazarken sorun çıkarabilir; APK daha rahattır.

## Önerilen ilk devlog
"v0.1: oyna + stüdyo + Luau script editörü." Ekran görüntüleri ve 1-2 örnek script ekle (itch/CHECKLIST.md içinde örnekler var).

## Marka / lisans notları
- "Roblox" adı ve logosu Roblox Corporation'a aittir. Başlıkta, kapakta ve ikonda kullanma; açıklamada yalnızca "Luau dili" ya da "Roblox'tan esinlenen" gibi nötr ifade kullan.
- Godot Engine MIT lisanslıdır; oyun içinde "Hakkında" ekranında belirtilir.

## Dünyaları paylaşma (önemli)
Dünyalar oyuncunun kendi cihazında saklanır. Senin yaptığın oyunun herkese görünmesi için `games/*.mbgame` dosyası olarak pakete gömmelisin (README'deki "Oyunlarını herkesle paylaş"). Oyuncular da kendi oyunlarını "Paylaş" ile metin olarak gönderebilir ve başkaları "Oyun İçe Aktar" ile alabilir (yorumlarda paylaşım yapılabilir).
