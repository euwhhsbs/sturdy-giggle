# MobileBlox (Godot 4.2+ / GL Compatibility)

## Kurulum
1. Zip'i aç, Godot 4.2+ ile `project.godot` dosyasını içe aktar.
2. Editörde bir kez aç (class_name önbelleği oluşsun), sonra F5.
3. Masaüstü testi: fare = dokunuş (touch emulation açık). Oyunda ok tuşları + Space çalışır.

## Android export
- Proje > Export > Android. Renderer zaten `gl_compatibility` (OpenGL ES 3.0).
- Android build template + JDK/SDK yolları Editor Settings'ten ayarlanmalı.
- iOS için Xcode gerekir (macOS).

## Sahne ağacı
MainMenu (Control)
 - ColorRect, CenterContainer > VBox > Title, [Oyna], [Stüdyo]

Studio (Node3D, studio.gd)
 - WorldEnvironment, DirectionalLight3D, Ground (StaticBody3D)
 - Parts (Node3D) > her parça: StaticBody3D > Mesh, Shape
 - Camera3D, SelectionBox, SpawnMarker
 - CanvasLayer > UIRoot > TouchLayer (arkada), Üst bar, Sol araçlar, Alt palet, Sağ panel

Play (Node3D, play.gd)
 - WorldEnvironment, DirectionalLight3D, Ground, Parts
 - Player (CharacterBody3D) > CollisionShape3D, Model, Camera3D (top_level)
 - CanvasLayer > UIRoot > TouchLayer (kamera), TouchJoystick, TouchButton (Zıpla), Stüdyo, FPS

## Kayıt
`user://world.json` (Studio'da Kaydet / Yükle; Oyna'ya basınca otomatik kaydeder).

## Güncelleme: öldürücü parçalar + yeni arayüz
- Studio > parça seç > "Öldürücü" düğmesi: parça kırmızımsı parlar, oyunda dokunan ölür ve spawn'a döner.
- Kayıt dosyasına parça başına "x" (öldürücü) alanı eklendi; eski kayıtlar sorunsuz yüklenir.
- Play: ölüm sayacı, kırmızı flaş, "Öldün!" yazısı. Doğunca 0.7 sn dokunulmazlık.
- Arayüz: paneller, yuvarlak renk kutuları, seçili parça bilgisi.

## Güncelleme 3: can sistemi + çoklu oyun
- Can 100. Tehlike: Yok / Hasar (saniyede 45) / Öldür (anında). 4 sn hasarsız kalınca can yenilenir.
- Temas, Area3D yerine shape query ile ölçülür (Jolt'ta Area3D statik cisimleri görmez).
- Ana menüde oyun listesi: seç, "Yeni Oyun" ile yeni dünya oluştur. İlk oyun eski world.json'u kullanır.

## Güncelleme 4: joystick modu
- Play'de sağ üstteki "Joystick: Yüzen/Sabit" düğmesi modu değiştirir; seçim `user://settings.cfg` içinde saklanır.
- Yüzen: sol yarıda her yere dokun, joystick orada belirir. Sabit: sol alttaki kutuda hep aynı yerde durur.
- Sabit modda sol yarının geri kalanı kamera bakışı için serbest kalır.

## Güncelleme 5: Roblox Studio tarzı arayüz
- Üstte sekmeli şerit: Ana Sayfa (Dosya, Araçlar, Ekle, Renk, Düzenle, Test), Model, Test, Görünüm. "Gizle" şeridi kapatır.
- Solda Gezgin (parça listesi, dokununca seçer ve kamerayı odaklar), sağda Özellikler (Konum/Boyut -/+ , renk, tehlike).
- Ortada dinamik joystick (kamerayı yerde gezdirir) + "Yük."/"Aşa." düğmeleri; altta Çıktı (son 3 mesaj).
- Görünüm sekmesinden paneller açılıp kapanır, joystick Yüzen/Sabit değişir, kamera sıfırlanır.

## Güncelleme 6: Roblox "Games" tarzı ana menü
- Üst çubuk: Oyunlar | More v. More > Build, Ayarlar.
- Oyunlar: kart ızgarası (sayfa başına 8), Popüler/Yeni/A-Z sıralama, arama, sayfa okları. Karta dokun = oyunu başlat.
- Build: aynı ızgara + "Yeni Oyun" kartı. Karta dokun = o oyunu Stüdyo'da aç.
- Oyun (Play) içinden Stüdyo'ya doğrudan geçiş kaldırıldı: sağ üstteki düğme artık "Menü".
- Ayarlar: Joystick yüzen/sabit, Gölgeler açık/kapalı (kalıcı).

## Güncelleme 7: Stüdyo geliştirmeleri
- Geri Al / Yinele (Ana Sayfa > Geçmiş): ekleme, silme, kopyalama, taşıma, boyut, dönüş, boya, tehlike. 100 adım.
  Peş peşe aynı düzenleme (basılı tutma) tek adımda birleşir.
- Dönüş (Y ekseni): Özellikler > Dönüş. Adım 15° / 45° / 90° (Model > Adım düğmesiyle birlikte değişir). Kayıtta "r" alanı.
- +/- düğmeleri basılı tutulunca tekrar eder.
- Model > Odakla: kamerayı seçili parçaya getirir.

## Güncelleme 8: sürükleyerek taşıma, çoklu seçim, parça adı
- Sürükle-taşı: "Seç" aracında bir parçanın üstünden başlayan tek parmak sürüklemesi parçayı (tüm seçimi) zeminle
  paralel düzlemde taşır, Adım değerine yapışır. Boş yerden sürükleme kamerayı döndürür. Her sürükleme tek geri alma adımı.
- Çoklu seçim: Ana Sayfa > Seçim > "Çoklu" açıkken dokunarak ekle/çıkar (Gezgin'den de). "Tümü" hepsini seçer.
  Taşı/boyut/dönüş/renk/tehlike/kopyala/sil tüm seçime uygulanır. Seçili parçalar Gezgin'de "* " ile işaretlenir.
- Ad değiştirme: Özellikler panelindeki ad kutusu. Boş bırakırsan otomatik ada döner. Adlar kayıtta saklanır ("n").

## Güncelleme 9: hazır davranışlar
Özellikler > Davranış (açılır liste), seçili tüm parçalara uygulanır:
- Hasar (saniyede 45), Öldür (anında)
- Zıplatıcı: üstten basınca fırlatır. Güç ayarlanır (6-40). Yeşil parlar.
- Checkpoint: dokununca ölünce doğulan yer olur ("Checkpoint!" yazısı). Sarı parlar.
- Hareketli Platform: başlangıç konumu çevresinde mesafe (2-30) kadar gidip gelir, üstündeki karakteri taşır. Eksen X/Y/Z seçilir. Mavi parlar. Yalnızca Play'de hareket eder; Stüdyoda sabit görünür.
Kayıtta "x" davranış, "a" parametre, "b" eksen.

## Güncelleme 10: StarterGui (oyun içi arayüz)
- Stüdyo > "Arayüz" sekmesi: Çerçeve, Etiket, Düğme ekle. Gezgin yerine StarterGui listesi görünür.
- Önizleme çerçevesi oyun ekranının en-boy oranındadır; öğeler ekran oranıyla (%) saklanır. Sürükleyerek yerleştir,
  Özellikler'den X/Y/En/Boy, yazı boyutu, renk, ad, metin ve (düğme için) eylem ayarla.
- Metinde {can} {ölüm} {fps} {oyun} yazarsan Play'de canlı değer gösterilir.
- Düğme eylemleri: Yok, Başa dön, Menüye dön. Tümü Geri Al/Yinele ile çalışır; oyun dosyasıyla birlikte kaydedilir ("gui").

## Güncelleme 11: Roblox Studio görünümü
- Koyu gri, düz tema (mavi vurgu). Üstte başlık "Oyun - MobileBlox Studio", sekme şeridi, ikonlu şerit (ikon üstte, yazı altta, grup adları altta).
- İkonlar kodla çizilir (studio_icon.gd); ribbon_button.gd şerit düğmesi, tree_header.gd açılır başlık.
- Gezgin ağaç gibi: Workspace ve StarterGui başlıkları açılır/kapanır. Özellikler kategorili: Veri, Dönüşüm, Görünüm, Davranış.
- Ortada belge sekmeleri (oyun / StarterGui), altta zaman damgalı Çıktı paneli.

## Güncelleme 12: Script editörü (MobileBlox Script)
- Stüdyo > "Script" sekmesi (ya da belge sekmesi "Script"): CodeEdit ile sözdizimi renklendirme, satır numarası, otomatik girinti.
- Parça script'i: Gezgin'den parça seç > "Parçaya Ekle". Parçalar Gezgin'de "[S]" ile işaretlenir.
- Genel script: "Genel Script" > Gezgin'de "Scripts" bölümünde listelenir (onstart / every).
- "Denetle" hataları Çıktı'ya yazar; alttaki çubuk canlı hata gösterir. "Şablon" hazır örnek ekler, "Komutlar" yardımı açar.
- Dil (mb_script.gd, güvenli - dosya/sistem erişimi yok): onstart / ontouch / every N; say, set, add, wait, heal, damage, kill,
  respawn, teleport, bounce, move, color, hide, show, destroy; if/else, repeat. Metinde {değişken}, {can} {ölüm} {zaman}.
- Play'de script_runtime.gd çalıştırır; "say" mesajı ekranda gösterir; değişkenler StarterGui metinlerinde {ad} olarak kullanılabilir.
- Script'ler oyun dosyasına kaydedilir ("sc" parça başına, "scripts" genel). Script düzenlemeleri Geri Al'a dahil değildir (editörün kendi geri alması vardır).

## Güncelleme 13: Luau (Roblox'un dili)
- Script editörü artık Roblox'un dili Luau/Lua ile çalışır. Parça script'inde `script.Parent` parçadır.
- Eski MobileBlox Script (onstart:/ontouch:/every N:) hâlâ çalışır; otomatik algılanır.
- Dosyalar: luau_lexer.gd, luau_parser.gd, luau_interp.gd (yorumlayıcı + coroutine), rbx_bridge.gd (Roblox API),
  luau_runtime.gd (Play'de çalıştırıcı), lua_*.gd / rbx_*.gd (veri tipleri).
- Desteklenen dil: local, function, closure, if/while/for/repeat/pairs/ipairs, tablolar, metatable (__index/__newindex/__call),
  string/math/table/os kütüphaneleri (Lua desenleri alt küme), pcall, wait/task.wait/spawn/delay, +=, continue, if-ifadesi.
- Roblox API: game, workspace, script, Instance.new, Players (LocalPlayer, PlayerAdded), Character/Humanoid (Health, WalkSpeed,
  JumpPower, TakeDamage, Died), part özellikleri (Position, Size, Color, BrickColor, Transparency, CanCollide, CFrame), Touched/TouchEnded,
  Destroy/Clone, TweenService, RunService.Heartbeat, Debris, Vector3, Color3, CFrame, BrickColor, Enum, leaderstats (ekranda gösterilir).
- Yok: GUI (UDim2), Sound, Raycast, DataStore, RemoteEvent, tür kontrolü. Çıktı/hatalar Play'de sol üstte görünür.

## Yayınlama (itch.io)
Ayrıntılı rehber: `itch/PAGE.md` (sayfa ayarları, metinler) ve `itch/CHECKLIST.md` (yayın öncesi test).
1. Godot 4.7 + Export Templates kur, projeyi bir kez editörde aç.
2. `./build/export.sh web` (Windows: `build\export.bat web`) → `build/MobileBlox-web.zip`
3. itch.io'da yeni proje: Kind = HTML, zip'i yükle, "played in the browser" işaretle, 1280x720, Mobile friendly.
4. Android: `./build/export.sh android` → APK'yı aynı sayfaya ayrı dosya olarak yükle.
5. İsteğe bağlı: `.github/workflows/itch.yml` ile etiket basınca otomatik yayın (butler).
Görselleri yenilemek için: `python3 itch/make_art.py`.

## Telefondan yayınlama (bilgisayarsız)
Godot'un Android editörü APK/Web dışa aktaramaz; derlemeyi GitHub Actions bulutta yapar.
`.github/workflows/web.yml` (Web) ve `android.yml` (APK): repoya `MobileBlox.zip` yükle, Actions > iş akışını çalıştır, bitince
"Artifacts" bölümünden indir, itch.io'ya yükle.

## Oyunlarını herkesle paylaş (itch.io'da başkaları da görsün)
Oyunlar cihazda/tarayıcıda saklanır; bu yüzden yayınladığın sürümde başkaları SENİN dünyalarını görmez.
Çözüm: oyunu yerleşik oyun olarak pakete göm.
1. Stüdyo > Dosya > **Paylaş** > Panoya Kopyala.
2. GitHub repo'nda `games/oyun-adi.mbgame` dosyası oluştur, metni yapıştır, Commit.
3. Actions > Web build > Run workflow (iş akışı `games/` klasörünü otomatik alır), çıkan zip'i itch.io'ya yükle.
Başkasının oyununu almak için: More > **Oyun İçe Aktar** > metni yapıştır.
